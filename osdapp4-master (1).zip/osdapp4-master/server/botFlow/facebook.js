const axios = require("axios")
require("dotenv").config()
const key = require("../config")

module.exports = {
  passHuman: (PSID) =>
    axios
      .post(
        `https://graph.facebook.com/v6.0/me/messages?access_token=${key.PAGE_ACCESS_TOKEN}`,
        {
          recipient: {
            id: PSID,
          },
          messaging_type: "response",
          message: {
            text: "Do you want to speak with who?:",
            quick_replies: [
              {
                content_type: "text",
                title: "speak with bot",
                payload: `{"type": "speakToBot"}`,
                image_url:
                  "https://st4.depositphotos.com/1000507/23601/v/450/depositphotos_236010996-stock-illustration-robocop-icon-simple-vector-illustration.jpg",
              },
              {
                content_type: "text",
                title: "speak with human",
                payload: `{"type": "passToHuman"}`,
                image_url:
                  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtaokg09fSBvQXo2325BDJTtfXg4x2To2WKADfp2WJmuDEOBlkCw&s",
              },
            ],
          },
        }
      )
      .then(function (response) {
        console.log("send txt success ")
      })
      .catch(function (error) {
        console.log("error txt")
      }),

  whatSkill: (PSID) =>
    axios
      .post(
        `https://graph.facebook.com/v6.0/me/messages?access_token=${key.PAGE_ACCESS_TOKEN}`,
        {
          recipient: {
            id: PSID,
          },
          messaging_type: "response",
          message: {
            text: "Do you want to speak with which skill?:",
            quick_replies: [
              {
                content_type: "text",
                title: "skill1",
                payload: `{"type": "skill", "skill":"skill1"}`,
              },
              {
                content_type: "text",
                title: "skill2",
                payload: `{"type": "skill", "skill":"skill2"}`,
              },
              {
                content_type: "text",
                title: "skill3",
                payload: `{"type": "skill", "skill":"skill3"}`,
              },
            ],
          },
        }
      )
      .then(function (response) {
        console.log("send txt success ")
      })
      .catch(function (error) {
        console.log("error txt")
      }),

  humanHandover: (PSID, skill) => {
    axios
      .post(
        `https://graph.facebook.com/v6.0/me/messages?access_token=${key.PAGE_ACCESS_TOKEN}`,
        {
          recipient: {
            id: PSID,
          },
          messaging_type: "response",
          message: {
            text: `Ok, we will forward you to an agent with ${skill}:`,
          },
        }
      )
      .then(() =>
        axios
          .get(
            `https://dchat.osd.co.th/backend/api/testqueue/add/${skill.trim()}/${PSID}/facebook`
          )
          .catch((e) => console.log(e))
      )
      .catch((e) => console.log("error webhhok: ", e))
  },
}
