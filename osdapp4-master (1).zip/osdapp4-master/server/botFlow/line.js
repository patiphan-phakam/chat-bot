const axios = require("axios")
const key = require("../config")

module.exports = {
  passHuman: (PSID) =>
    axios
      .post(
        `https://api.line.me/v2/bot/message/push`,
        {
          to: PSID,
          messages: [
            {
              type: "text",
              text: "Do you want to speak with who?:",
              quickReply: {
                items: [
                  {
                    type: "action",
                    imageUrl:
                      "https://st4.depositphotos.com/1000507/23601/v/450/depositphotos_236010996-stock-illustration-robocop-icon-simple-vector-illustration.jpg",
                    action: {
                      type: "message",
                      label: "speak with bot",
                      text: "speak with bot",
                    },
                  },
                  {
                    type: "action",
                    imageUrl:
                      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtaokg09fSBvQXo2325BDJTtfXg4x2To2WKADfp2WJmuDEOBlkCw&s",
                    action: {
                      type: "message",
                      label: "speak with human",
                      text: "speak with human",
                    },
                  },
                ],
              },
            },
          ],
        },
        {
          headers: {
            Authorization: `Bearer ${key.CHANNEL_ACCESS_TOKEN}`,
          },
        }
      )
      .then(function (response) {
        console.log("send txt success ")
      })
      .catch(function (error) {
        console.log("error txt")
      }),

  whatSkill: (PSID) =>
    axios
      .post(
        `https://api.line.me/v2/bot/message/push`,
        {
          to: PSID,
          messages: [
            {
              type: "sticker",
              packageId: "11538",
              stickerId: "51626532",
            },
            {
              type: "text",
              text: "Do you want to speak with which skill?:",
              quickReply: {
                items: [
                  {
                    type: "action",
                    action: {
                      type: "message",
                      label: "skill1",
                      text: "skill1",
                    },
                  },
                  {
                    type: "action",
                    action: {
                      type: "message",
                      label: "skill2",
                      text: "skill2",
                    },
                  },
                  {
                    type: "action",
                    action: {
                      type: "message",
                      label: "skill3",
                      text: "skill3",
                    },
                  },
                ],
              },
            },
          ],
        },
        {
          headers: {
            Authorization: `Bearer ${key.CHANNEL_ACCESS_TOKEN}`,
          },
        }
      )
      .then(function (response) {
        console.log("send txt success ")
      })
      .catch(function (error) {
        console.log("error txt")
      }),

  humanHandover: (PSID, skill) => {
    axios
      .post(
        `https://api.line.me/v2/bot/message/push`,
        {
          to: PSID,
          messages: [
            {
              type: "sticker",
              packageId: "11539",
              stickerId: "52114117",
            },
            {
              type: "text",
              text: `Ok, we will forward you to an agent with ${skill}:`,
            },
          ],
        },
        {
          headers: {
            Authorization: `Bearer ${key.CHANNEL_ACCESS_TOKEN}`,
          },
        }
      )
      .then(() =>
        axios
          .get(
            `https://dchat.osd.co.th/backend/api/testqueue/add/${skill.trim()}/${PSID}/line`
          )
          .catch((e) => console.log(e))
      )
      .catch(function (error) {
        console.log("error txt")
      })
  },
}
