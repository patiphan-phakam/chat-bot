const router = require("express").Router()

module.exports = function (redisClient, io, NamespaceSupervisor) {
  router.post("/suptoagent", function (req, res) {
    const { msg, agentId } = req.body
    io.to(agentId).emit(`msg supervisor -> agent`, { msg, date: new Date() })

    res.send("msg send success")
  })

  router.post("/agenttosup", function (req, res) {
    const { msg, supervisorGroup, agentId, supervisorId } = req.body

    io.to(agentId).emit(`msg agent -> supervisor`, {
      msg,
      agentId,
      supervisorId,
      date: new Date(),
    })
    res.send({
      status: "msg agent -> supervisor success",
      data: {
        msg,
        agentId,
        supervisorId,
        date: new Date(),
      },
    })
  })

  return router
}
