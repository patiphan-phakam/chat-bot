const router = require("express").Router()
const settings = require("../../services/settings")

router.get("/", (req, res) => {
  settings
    .read()
    .then(data => res.send(data))
    .catch(err => {
      console.log(err)
      res.status(500).send(err)
    })
})

module.exports = router
