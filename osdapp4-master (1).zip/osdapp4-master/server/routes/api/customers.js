const router = require("express").Router()
const ModelCustomer = require("../../models/ModelCustomer")

router.post("/", (req, res) => {
  const {
    _id,
    channel,
    chat,
    firstname,
    lastname,
    address,
    email,
    mobile,
    notes,
    gender,
    skill,
  } = req.body
  const newCustomer = new ModelCustomer({
    _id,
    channel,
    chat,
    firstname,
    lastname,
    address,
    email,
    mobile,
    notes,
    gender,
    skill,
  })
  newCustomer.save((err, data) => {
    console.log(err, "err newcustomer save")
    if (err) return res.status(404).end()
    return res.json(data)
  })
})

router.get("/", (req, res) => {
  ModelCustomer.find({}, function (err, data) {
    if (err) return res.status(404).end()
    return res.json(data)
  })
})

router.get("/:id", (req, res) => {
  const { id } = req.params
  ModelCustomer.findOne({ _id: id }, function (err, data) {
    if (err) return res.status(404).send("not found")
    return res.json(data)
  })
})

// AGENT EDIT CUSTOMER PROFILE
router.put("/:id", (req, res) => {
  const { id } = req.params
  const { firstname, lastname, address, email, mobile, notes, chat } = req.body

  if (firstname) {
    ModelCustomer.updateOne(
      { _id: id },
      {
        firstname,
        lastname,
        address,
        email,
        mobile,
        notes,
        chat,
      },
      { upsert: true, new: true, setDefaultsOnInsert: true },
      (err, data) => {
        if (err) return res.status(500).send(err)
        return res.send(data)
      }
    )
  } else {
    ModelCustomer.updateOne(
      { _id: id },
      {
        chat,
      },
      { upsert: true, new: true, setDefaultsOnInsert: true },
      (err, data) => {
        if (err) return res.status(500).send(err)
        return res.send(data)
      }
    )
  }
})

module.exports = router
