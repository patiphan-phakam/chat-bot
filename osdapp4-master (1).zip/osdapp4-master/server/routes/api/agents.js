const router = require("express").Router()
const agentService = require("../../services/agents")
const alertsService = require("../../services/alerts")
const ModelAgent = require("../../models/ModelAgent")
const ModelCustomer = require("../../models/ModelCustomer")

module.exports = (redisClient, io) => {
  router.put("/skills/add", (req, res) => {
    const { agents, skill } = req.body
    //  agents = ["5df19bbda116c95b5b8c142e", "5df19bd3a116c95b5b8c169c"]
    // skill = 'skill1'
    agentService
      .addSkills(agents, skill)
      .then((data) => res.send(data))
      .catch((err) => {
        console.log(err)
        res.status(500).send(err)
      })
  })

  router.put("/skills/del", (req, res) => {
    const { agents, skill } = req.body
    agentService
      .delSkills(agents, skill)
      .then((data) => res.send(data))
      .catch((err) => {
        console.log(err)
        res.status(500).send(err)
      })
  })

  router.put("/:id", (req, res) => {
    const { id } = req.params
    const { skills } = req.query

    agentService
      .update(id, { skills: skills.split(",") })
      .then((data) => res.send(data))
      .catch((err) => {
        console.log(err)
        res.status(500).send(err)
      })
  })

  router.get("/:id", (req, res) => {
    const { id } = req.params

    agentService
      .read(id)
      .then((data) => res.send(data))
      .catch((err) => {
        console.log(err)
        res.status(500).send(err)
      })
  })

  router.put("/customers/:_id", (req, res) => {
    const { _id } = req.params
    const { customerId } = req.body

    ModelAgent.findById(_id, (err, doc) => {
      if (err) return res.status(500).send(err)
      if (doc.customers.filter((x) => x === customerId).length === 0) {
        doc.customers.push(customerId)
        doc.save("done")
        return res.send(doc)
      }
      return res.send(doc)
    })
  })

  router.get("/", (req, res) => {
    agentService
      .readAll(req.query)
      .then((data) => res.send(data))
      .catch((err) => {
        console.log(err)
        res.status(500).send(err)
      })
  })

  router.get("/status/:agentId", (req, res) => {
    const { agentId } = req.params
    redisClient.GET(`statusAgent:${agentId}`, function (err, replyStats) {
      console.log(replyStats)
      const parsedReply = JSON.parse(replyStats)
      res.send(parsedReply)
    })
  })

  router.delete("/status/:agentId", (req, res) => {
    const { agentId } = req.params
    redisClient.del(`statusAgent:${agentId}`)
    res.send("delete")
  })

  router.get("/rating/:agentId", (req, res) => {
    const { agentId } = req.params
    redisClient.GET(`ratingsAgent:${agentId}`, function (err, reply) {
      if (err) return res.status(500).send("err")
      console.log(reply)
      return res.send(JSON.parse(reply))
    })
  })

  router.delete("/rating/:agentId", (req, res) => {
    const { agentId } = req.params
    redisClient.del(`ratingsAgent:${agentId}`)
    res.send("delete")
  })

  router.get("/allchats/:_id", (req, res) => {
    const { _id } = req.params

    ModelAgent.findById(_id)
      .select("customers updatedAt")
      .lean()
      .exec(function (err, data) {
        if (err) return res.status(500).send(err)

        ModelCustomer.find({ _id: { $in: data.customers } })
          .sort({ updatedAt: -1 })
          .select("chat")
          .lean()
          .exec(function (err2, docs) {
            if (err2) return res.status(500).send(err2)
            return res.send(docs)
          })
      })
  })

  return router
}
