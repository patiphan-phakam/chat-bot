const router = require("express").Router()
const ModelSupervisor = require("../../models/ModelSupervisor")

module.exports = function(redisClient) {
  router.get("/", (req, res) => {
    ModelSupervisor.find({}, function(err, data) {
      if (err) return res.status(404).end()
      return res.json(data)
    })
  })

  router.get("/:id", (req, res) => {
    const { id } = req.params
    ModelSupervisor.findById(id)
      // .populate("agents", "skills email")
      .exec(function(err, data) {
        if (err) return res.status(404).end()
        console.log("supervisor: ", data)
        return res.json(data)
      })
  })

  return router
}
