const router = require("express").Router()
const axios = require("axios")
const textBlock = require("../../messagesComponents/facebook/textBlock")
const callBlock = require("../../messagesComponents/facebook/callBlock")
const carouselBlock = require("../../messagesComponents/facebook/carouselBlock")
const receipeBlock = require("../../messagesComponents/facebook/receipeBlock")
const closeBlock = require("../../messagesComponents/facebook/closeBlock")

const textBlockLine = require("../../messagesComponents/line/textBlock")
const callBlockLine = require("../../messagesComponents/line/callBlock")
const carouselBlockLine = require("../../messagesComponents/line/carouselBlock")
const receipeBlockLine = require("../../messagesComponents/line/receipeBlock")
const closeBlockBlockLine = require("../../messagesComponents/line/closeBlock")

const key = require("../../config")

module.exports = function (redisClient, io) {
  router.post("/", function (req, res) {
    const { channel, PSID, text, type, agentId, date } = req.body

    io.to(agentId).emit("agent -> customer", {
      msg: text,
      type,
      date: new Date(),
    })

    if (channel == "facebook") {
      if (type === "text") {
        return axios
          .post(
            `https://graph.facebook.com/v6.0/me/messages?access_token=${key.PAGE_ACCESS_TOKEN}`,
            textBlock(text, PSID)
          )
          .then(({ data }) => {
            if (agentId) {
              redisClient.lpush(
                `currentmsg${agentId}`,
                JSON.stringify({
                  author: "agent",
                  message: text,
                  date,
                })
              )
            }
            return res.send(data)
          })
          .catch((e) => res.status(500).send(`error api`))
      }
      if (type === "call") {
        return axios
          .post(
            `https://graph.facebook.com/v6.0/me/messages?access_token=${key.PAGE_ACCESS_TOKEN}`,
            callBlock(PSID)
          )
          .then(({ data }) => res.send(data))
          .catch((e) => res.status(500).send(`error api`))
      }
      if (type === "carousel") {
        return axios
          .post(
            `https://graph.facebook.com/v6.0/me/messages?access_token=${key.PAGE_ACCESS_TOKEN}`,
            carouselBlock(PSID)
          )
          .then(({ data }) => res.send(data))
          .catch((e) => res.status(500).send(`error api`))
      }
      if (type === "receipe") {
        return axios
          .post(
            `https://graph.facebook.com/v6.0/me/messages?access_token=${key.PAGE_ACCESS_TOKEN}`,
            receipeBlock(PSID)
          )
          .then(({ data }) => res.send(data))
          .catch((e) => res.status(500).send(`error api`))
      }
      if (type === "close") {
        console.log("-- type close --", PSID, agentId)
        return axios
          .post(
            `https://graph.facebook.com/v6.0/me/messages?access_token=${key.PAGE_ACCESS_TOKEN}`,
            closeBlock(PSID, agentId)
          )
          .then(({ data }) => res.send(data))
          .catch((e) => res.status(500).send(`error api`))
      }
      return res.status(500).send(`type not found: ${type}`)
    }

    if (channel == "line") {
      if (type === "text") {
        return axios
          .post(
            `https://api.line.me/v2/bot/message/push`,
            textBlockLine(text, PSID),
            {
              headers: {
                Authorization: `Bearer ${key.CHANNEL_ACCESS_TOKEN}`,
              },
            }
          )
          .then(({ data }) => {
            if (agentId) {
              redisClient.lpush(
                `currentmsg${agentId}`,
                JSON.stringify({ message: text, time: new Date() })
              )
            }
            return res.send(data)
          })
          .catch((e) => res.status(500).send(`error api`))
      }
      if (type === "call") {
        return axios
          .post(
            `https://api.line.me/v2/bot/message/push`,
            callBlockLine(PSID),
            {
              headers: {
                Authorization: `Bearer ${key.CHANNEL_ACCESS_TOKEN}`,
              },
            }
          )
          .then(({ data }) => res.send(data))
          .catch((e) => res.status(500).send(`error api`))
      }
      if (type === "carousel") {
        return axios
          .post(
            `https://api.line.me/v2/bot/message/push`,
            carouselBlockLine(PSID),
            {
              headers: {
                Authorization: `Bearer ${key.CHANNEL_ACCESS_TOKEN}`,
              },
            }
          )
          .then(({ data }) => res.send(data))
          .catch((e) => res.status(500).send(`error api`))
      }
      if (type === "receipe") {
        return axios
          .post(
            `https://api.line.me/v2/bot/message/push`,
            receipeBlockLine(PSID),
            {
              headers: {
                Authorization: `Bearer ${key.CHANNEL_ACCESS_TOKEN}`,
              },
            }
          )
          .then(({ data }) => res.send(data))
          .catch((e) => res.status(500).send(`error api`))
      }
      if (type === "close") {
        return axios
          .post(
            `https://api.line.me/v2/bot/message/push`,
            closeBlockBlockLine(PSID, agentId),
            {
              headers: {
                Authorization: `Bearer ${key.CHANNEL_ACCESS_TOKEN}`,
              },
            }
          )
          .then(({ data }) => res.send(data))
          .catch((e) => res.status(500).send(`error api`))
      }
      return res.status(500).send(`type not found: ${type}`)
    }

    return res.status(500).send(`not found your channel ${channel}`)
  })

  return router
}
