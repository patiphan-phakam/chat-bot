const router = require("express").Router()
const SetInterval = require("set-interval")
const axios = require("axios")
const key = require("../../config")
const textBlock = require("../../messagesComponents/facebook/textBlock")
const textBlockLine = require("../../messagesComponents/line/textBlock")
const delAgentQueue = require("../../services/delAgentQueue")
const match = require("../../services/match")
const statsWaiting = require("../../services/statsWaiting")

const delnClear = async (redisClient, queue, data) => {
  await redisClient.LREM(
    `customerqueue${queue}`,
    0,
    JSON.stringify(data),
    function (err, object) {
      if (err) return console.log(err)
      console.log(
        `customer ${JSON.stringify(data)} deleted from queue ${queue}`
      )
    }
  )
  // maybe del this block i corrected to customerqueue${queue}
  await redisClient.LLEN(`customerqueue${queue}`, (err, reply) => {
    if (reply == 0) {
      console.log("interval off")
      SetInterval.clear(`customerqueue${queue}`)
    }
  })
}

const addQueue = (redisClient, io, queue, data) => {
  const { userId, channel, skill } = data
  let timedOut
  let startChronoWaiting

  function timeoutStart() {
    timedOut = setTimeout(() => {
      console.log("timed out")
      io.of("/supervisor").emit("global", {
        type: "queue_customer_leave",
        userId,
        skill,
      })
      timeoutCloseMsg(userId, channel)
      redisClient.GET(`customerTimeOut`, function (err, reply) {
        const parsedReply = JSON.parse(reply)
        if (parsedReply) {
          redisClient.SET(
            `customerTimeOut`,
            JSON.stringify({
              ...parsedReply,
              [skill]: parsedReply[skill] ? parsedReply[skill] + 1 : 1,
            })
          )
          io.of("/supervisor").emit("global", {
            type: "timeout_customer",
            data: {
              ...parsedReply,
              [skill]: parsedReply[skill] ? parsedReply[skill] + 1 : 1,
            },
          })
        } else {
          redisClient.SET(
            `customerTimeOut`,
            JSON.stringify({
              [skill]: 1,
            })
          )
          io.of("/supervisor").emit("global", {
            type: "timeout_customer",
            data: { [skill]: 1 },
          })
        }
      })
      delnClear(redisClient, queue, data)
    }, 20000)
  }

  function timeoutStop() {
    clearTimeout(timedOut)
  }

  console.log("addQueue", queue, data)

  const add = async () => {
    startChronoWaiting = new Date()
    console.log("add ", data)
    timeoutStart()
    redisClient.rpush(`customerqueue${queue}`, JSON.stringify(data))
    io.of("/supervisor").emit("global", {
      type: "queue_customer_join",
      data,
    })
  }
  return add().then(() => {
    const startCustomerInQueue = new Date()
    console.log("interval on")

    SetInterval.start(
      () => {
        // if more than 1 agent in queue
        redisClient.LLEN(`agentqueue${queue}`, (err, reply) => {
          if (reply === 0) {
            console.log("--- waiting, no agent available ---")
            redisClient.LLEN(
              `customerqueue${queue}`,
              (err, customersNumber) => {
                if (customersNumber === 0) {
                  SetInterval.clear(`interval${queue}`)
                }
              }
            )
          }
          if (reply > 0) {
            // MATCH // delete customer from queue
            statsWaiting.add(startChronoWaiting, data, redisClient, io)
            timeoutStop()
            SetInterval.clear(`interval${queue}`)
            redisClient.lpop(`customerqueue${queue}`, function (err, object) {
              if (err) res.send("error")
              console.log(object)
              io.of("/supervisor").emit("global", {
                type: "queue_customer_leave",
                userId,
                skill: queue,
              })

              // selected agent
              redisClient.lrange(`agentqueue${queue}`, 0, -1, function (
                err,
                object
              ) {
                const selectedAgent = object[object.length - 1]
                if (err) return console.log("!-- err --!")
                if (selectedAgent) {
                  welcomeMsg(userId, channel, skill, selectedAgent)
                  // redis --> [userId]: {skill, userId, agentId, channel}   for query by customer webhooks
                  redisClient.hmset(userId, {
                    skill,
                    userId,
                    agentId: selectedAgent,
                    channel,
                  })

                  // redis --> [agentId]: {skill, userId, agentId, channel}   for query by agents
                  redisClient.hmset(selectedAgent, {
                    skill,
                    userId,
                    agentId: selectedAgent,
                    channel,
                  })

                  match(io, selectedAgent, {
                    skill,
                    userId,
                    agentId: selectedAgent,
                    channel,
                  })
                  // del agent from queue
                  delAgentQueue(
                    redisClient,
                    io,
                    ["skill1", "skill2", "skill3"],
                    selectedAgent,
                    "busy",
                    skill,
                    new Date() - startCustomerInQueue
                  )

                  // io.of("/supervisor").emit("global", {
                  //   type: "queue_customer_leave",
                  //   userId,
                  //   skill: queue
                  // })
                }

                if (!selectedAgent) {
                  console.log("--- agent not selected error ---")
                }
              })
            })
          }
        })
      },
      1000,
      `interval${queue}`
    )
  })
}

module.exports = function (redisClient, io) {
  router.get("/add/:queue/:PSID/:channel", (req, res) => {
    const { PSID, queue, channel } = req.params
    const data = { PSID }

    //enter queue
    addQueue(redisClient, io, queue, { userId: PSID, channel, skill: queue })

    //timeout go out queue

    // read queue array
    redisClient.lrange(queue, 0, -1, function (err, object) {
      if (err) res.send("error")
      console.log(object)
      return res.send(object)
    })
  })

  router.get("/takejob/:queue", (req, res) => {
    const { queue } = req.params
    redisClient.lpop(queue, function (err, object) {
      if (err) res.send("error")
      console.log(object)
      return res.send(object)
    })
  })

  router.get("/resetredis", (req, res) => {
    const delAllKeys = async () => {
      await redisClient.flushall()
      res.send(`delete all keys`)
    }
    return delAllKeys()
  })

  return router
}

function timeoutCloseMsg(PSID, channel) {
  if (channel === "facebook") {
    return axios
      .post(
        `https://graph.facebook.com/v6.0/me/messages?access_token=${key.PAGE_ACCESS_TOKEN}`,
        textBlock("Sorry nobody!", PSID)
      )
      .then(() => console.log("|=> timeout success"))
      .catch((e) => res.status(500).send(`error api`))
  }
  if (channel === "line") {
    return axios
      .post(
        `https://api.line.me/v2/bot/message/push`,
        textBlockLine("Sorry nobody!", PSID),
        {
          headers: {
            Authorization: `Bearer ${key.CHANNEL_ACCESS_TOKEN}`,
          },
        }
      )
      .then(() => console.log("|=> timeout success"))
      .catch((e) => res.status(500).send(`error api`))
  }
}

function welcomeMsg(PSID, channel, skill, agentId) {
  if (channel === "facebook") {
    return axios
      .post(
        `https://graph.facebook.com/v6.0/me/messages?access_token=${key.PAGE_ACCESS_TOKEN}`,
        textBlock(
          `We found an available agent specialize in ${skill}: ${agentId}`,
          PSID
        )
      )
      .then(() => console.log("|=> welcome message matching success"))
      .catch((e) => res.status(500).send(`error api`))
  }
  if (channel === "line") {
    return axios
      .post(
        `https://api.line.me/v2/bot/message/push`,
        textBlockLine(
          `We found an available agent specialize in ${skill}: ${agentId}`,
          PSID
        ),
        {
          headers: {
            Authorization: `Bearer ${key.CHANNEL_ACCESS_TOKEN}`,
          },
        }
      )
      .then(() => console.log("|=> welcome message matching success"))
      .catch((e) => {
        console.log("-- error -- :", e)
        return res.status(500).send(`error api`)
      })
  }
}
