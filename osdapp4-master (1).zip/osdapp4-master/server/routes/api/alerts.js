const router = require("express").Router()
const alertsService = require("../../services/alerts")

module.exports = (redisClient, io) => {
  router.post("/", (req, res) => {
    const { agentId, skill } = req.body
    alertsService
      .write(redisClient, io, agentId, skill)
      .then(data => res.send(data))
      .catch(err => {
        console.log(err)
        res.status(500).send(err)
      })
  })

  router.get("/", (req, res) => {
    alertsService
      .read(redisClient)
      .then(data => res.send(data))
      .catch(err => {
        console.log(err)
        res.status(500).send(err)
      })
  })

  router.post("/solve", (req, res) => {
    const { alertId } = req.body
    alertsService
      .solving(redisClient, io, alertId)
      .then(data => res.send(data))
      .catch(err => {
        console.log(err)
        res.status(500).send(err)
      })
  })

  return router
}
