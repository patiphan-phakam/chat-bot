const router = require("express").Router()
const statsWaiting = require("../../services/statsWaiting")
const statsService = require("../../services/stats")
const queryString = require("query-string")

module.exports = (redisClient) => {
  router.post("/redistomongoskillstats", (req, res) => {
    const { agents } = req.body

    statsService
      .cronJobStatsSkills(redisClient, agents)
      .then((data) => res.send(data))
      .catch((err) => {
        console.log(err)
        res.status(500).send(err)
      })
  })

  router.post("/redistomongo", (req, res) => {
    const { agents } = req.body

    statsService
      .cronjobRedisToMongo(redisClient, agents)
      .then((data) => res.send(data))
      .catch((err) => {
        console.log(err)
        res.status(500).send(err)
      })
  })

  router.get("/reportoneagent/:_id/:startDate/:endDate", (req, res) => {
    const { _id, startDate, endDate } = req.params
    statsService
      .readReportOneAgent(_id, startDate, endDate)
      .then((data) => res.send(data))
      .catch((err) => {
        console.log(err)
        res.status(500).send(err)
      })
  })

  router.get("/reportagent/:startDate/:endDate", (req, res) => {
    const { startDate, endDate } = req.params
    statsService
      .readReportAllAgents(startDate, endDate)
      .then((data) => res.send(data))
      .catch((err) => {
        console.log(err)
        res.status(500).send(err)
      })
  })

  router.get("/reportskill/:startDate/:endDate", (req, res) => {
    const { startDate, endDate } = req.params
    statsService
      .readReportSkill(startDate, endDate)
      .then((data) => res.send(data))
      .catch((err) => {
        console.log(err)
        res.status(500).send(err)
      })
  })

  router.get("/reportchat/:startDate/:endDate", (req, res) => {
    const { startDate, endDate } = req.params
    const {
      skill,
      source,
      agent,
      customerid,
      customername,
      chatid,
      status,
      duration,
    } = req.query

    statsService
      .readReportChat({
        startDate,
        endDate,
        skill,
        source,
        agent,
        customerid,
        customername,
        chatid,
        status,
        duration,
      })
      .then((data) => res.send(data))
      .catch((err) => {
        console.log(err)
        res.status(500).send(err)
      })
  })

  router.get("/todaywaiting", (req, res) => {
    statsWaiting.get(redisClient)

    res.json(statsWaiting.get(redisClient))
  })

  router.get("/days/:startDate/:endDate", (req, res) => {
    const { startDate, endDate } = req.params
    statsService
      .read(startDate, endDate)
      .then((data) => res.send(data))
      .catch((err) => {
        console.log(err)
        res.status(500).send(err)
      })
  })

  router.get("/customerstimeout", (req, res) => {
    redisClient.GET(`customerTimeOut`, function (err, reply) {
      const parsedReply = JSON.parse(reply)
      if (err) return res.status(500).send(err)
      res.send(parsedReply)
    })
  })

  router.get("/totalsessions", (req, res) => {
    statsService
      .totalSessionsRead(redisClient)
      .then((data) => res.send(data))
      .catch((err) => {
        console.log(err)
        res.status(500).send(err)
      })
  })

  router.get("/totalduration", (req, res) => {
    statsService
      .totalCustomerWaitingRead(redisClient)
      .then((data) => res.send(data))
      .catch((err) => {
        console.log(err)
        res.status(500).send(err)
      })
  })

  return router
}
