const router = require("express").Router()
const ModelAgent = require("../../models/ModelAgent")
const ModelSupervisor = require("../../models/ModelSupervisor")
const ModelAdmin = require("../../models/ModelAdmin")
const ModelCustomer = require("../../models/ModelCustomer")
const bcrypt = require("bcrypt")
const jwt = require("jsonwebtoken")
const secret = "kapao"
const saltRounds = 10

router.get("/bcrypt/:password", function (req, res) {
  const { password } = req.params
  bcrypt.genSalt(saltRounds, function (err, salt) {
    if (err) return res.status(404).end()
    bcrypt.hash(password, salt, function (err, hash) {
      if (err) return res.status(404).end()
      return res.send(hash)
    })
  })
})

router.post("/login", function (req, res) {
  const { email, password } = req.body
  ModelAgent.findOne({ email }, function (err, agent) {
    if (err || !agent)
      return res
        .status(500)
        .send({ type: "email", message: `wrong email ${email}` })
    bcrypt.compare(password, agent.password, function (err2, res2) {
      console.log("res2: ", res2)
      if (!res2 || err2)
        return res
          .status(500)
          .json({ type: "password", message: `wrong password` })
      const token = jwt.sign({ agent }, secret)
      return res.json({ message: "succes", token, agent })
    })
  })
})

router.post("/token", function (req, res) {
  const token = req.get("Authorization")
  jwt.verify(token, secret, function (err, decoded) {
    if (err) return res.status(500).send({ message: err })
    return res.send(decoded)
  })
})

router.post("/loginsupervisor", function (req, res) {
  const { email, password } = req.body
  ModelSupervisor.findOne({ email }, function (err, supervisor) {
    if (err || !supervisor)
      return res
        .status(500)
        .send({ type: "email", message: `wrong email ${email}` })
    bcrypt.compare(password, supervisor.password, function (err2, res2) {
      console.log("res2: ", res2)
      if (!res2 || err2)
        return res
          .status(500)
          .json({ type: "password", message: `wrong password` })
      const token = jwt.sign({ supervisor }, secret)
      return res.json({ message: "succes", token, supervisor })
    })
  })
})

router.post("/loginadmin", function (req, res) {
  const { email, password } = req.body
  ModelAdmin.findOne({ email }, function (err, admin) {
    if (err || !admin)
      return res
        .status(500)
        .send({ type: "email", message: `wrong email ${email}` })
    bcrypt.compare(password, admin.password, function (err2, res2) {
      console.log("res2: ", res2)
      if (!res2 || err2)
        return res
          .status(500)
          .json({ type: "password", message: `wrong password` })
      const token = jwt.sign({ admin }, secret)
      return res.json({ message: "succes", token, admin })
    })
  })
})

module.exports = router

// router.post("/token", function (req, res) {
//   const token = req.get("Authorization")
//   jwt.verify(token, secret, function (err, decoded) {
//     ModelCustomer.find(
//       {
//         _id: {
//           $in: decoded.agent.customers,
//         },
//       },
//       (err, docs) => {
//         console.log("docsss", decoded)
//         if (err) return res.status(500).send({ message: err })
//         return res.json({
//           message: "succes",
//           token,
//           agent: {
//             skills: decoded.agent.skills,
//             customers: docs,
//             _id: decoded.agent._id,
//             email: decoded.agent.email,
//             password: decoded.agent.password,
//           },
//         })
//       }
//     )
//   })
// })
