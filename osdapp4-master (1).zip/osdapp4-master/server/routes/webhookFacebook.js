const webhookFacebook = require("express").Router()
const botFlow = require("../botFlow/facebook")
const agentRatingsService = require("../services/agentRatings")

module.exports = function(redisClient, io) {
  webhookFacebook.post("/", (req, res) => {
    const { body } = req

    if (body.object === "page") {
      body.entry.forEach(entry => {
        entry.messaging.forEach(event => {
          if (event.message && event.message.text) {
            const PSID = event.sender.id
            const { message } = entry.messaging[0]
            console.log("PSID:", PSID)
            console.log("msg:", message)
            // console.log(message)

            redisClient.type(PSID.toString(), (err, res) => {
              if (err) return console.log("Error: %s", err)
              console.log('type: "%s"', res)
            })

            redisClient.hgetall(PSID.toString(), function(err, reply) {
              if (err) return console.log("redis webhook error: ", err)
              if (!reply) {
                if (message.text.toLowerCase() === "start") {
                  return botFlow.passHuman(PSID)
                }
                if (message.text.toLowerCase().includes("skill")) {
                  return botFlow.humanHandover(PSID, message.text.toLowerCase())
                }

                if (message.quick_reply) {
                  if (message.quick_reply.payload) {
                    const { payload } = message.quick_reply
                    if (JSON.parse(payload)) {
                      const payloadParsd = JSON.parse(payload)
                      const { type } = payloadParsd
                      if (type === "rating") {
                        agentRatingsService.write(
                          redisClient,
                          io,
                          payloadParsd.agentId,
                          payloadParsd.rating
                        )
                      }
                      if (type === "passToHuman") {
                        return botFlow.whatSkill(PSID)
                      }
                    }
                  }
                }
              }
              if (reply) {
                const payload = {
                  author: "customer",
                  message: message.text,
                  date: new Date()
                }
                io.in(reply.agentId).emit(`webhook msg`, payload)
                console.log("success --- -- - - ", reply.toString())
                redisClient.lpush(
                  `currentmsg${reply.agentId}`,
                  JSON.stringify(payload)
                )
              }
            })
          }
        })
      })
      res.status(200).send("EVENT_RECEIVED")
    } else {
      res.sendStatus(404)
    }
  })

  webhookFacebook.get("/", (req, res) => {
    const VERIFY_TOKEN = "a"
    const mode = req.query["hub.mode"]
    const token = req.query["hub.verify_token"]
    const challenge = req.query["hub.challenge"]

    if (mode && token) {
      if (mode === "subscribe" && token === VERIFY_TOKEN) {
        console.log("WEBHOOK_VERIFIED")
        res.status(200).send(challenge)
      } else {
        console.log("error webhook")
        res.sendStatus(403)
      }
    }
  })

  return webhookFacebook
}
