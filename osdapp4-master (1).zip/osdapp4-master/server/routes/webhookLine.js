const router = require("express").Router()
const middleware = require("@line/bot-sdk").middleware
const JSONParseError = require("@line/bot-sdk").JSONParseError
const SignatureValidationFailed = require("@line/bot-sdk")
  .SignatureValidationFailed
const botFlow = require("../botFlow/line")
const key = require("../config")
const agentRatingsService = require("../services/agentRatings")

module.exports = function (redisClient, io) {
  router.post(
    "/",
    middleware({
      channelAccessToken: key.CHANNEL_ACCESS_TOKEN,
      channelSecret: key.CHANNEL_SECRET,
    }),
    (req, res) => {
      const PSID = req.body.events[0].source.userId
      console.log("-------- LINE: -----------------", req.body.events[0])

      if (req.body.events[0].type && req.body.events[0].type === "postback") {
        const payloadParsd = JSON.parse(req.body.events[0].postback.data)
        console.log("second gros test: ", payloadParsd)

        if (payloadParsd.type === "rating") {
          agentRatingsService.write(
            redisClient,
            io,
            payloadParsd.agentId,
            payloadParsd.rating
          )
        }
      }

      redisClient.type(PSID.toString(), (err, res) => {
        if (err) return console.log("Error: %s", err)
        console.log('type: "%s"', res)
      })

      redisClient.hgetall(PSID.toString(), function (err, reply) {
        const { message } = req.body.events[0]
        if (err) return console.log("redis webhook error: ", err)

        if (!reply && message) {
          if (message.text.toLowerCase().toLowerCase() === "start") {
            return botFlow.passHuman(PSID)
          }
          if (message.text === "speak with human") {
            return botFlow.whatSkill(PSID)
          }
          if (message.text.toLowerCase().includes("skill")) {
            return botFlow.humanHandover(PSID, message.text.toLowerCase())
          }
        }

        if (reply) {
          const payload = {
            message: message.text,
            time: new Date(),
          }

          io.in(reply.agentId).emit(`webhook msg`, payload)
          console.log("success --- -- - - ", reply.toString())
          redisClient.lpush(
            `currentmsg${reply.agentId}`,
            JSON.stringify(payload)
          )
        }
      })

      res.json(req.body.events)
    }
  )

  router.use((err, req, res, next) => {
    if (err instanceof SignatureValidationFailed) {
      console.log("error signature")
      res.status(401).send(err.signature)
      return
    } else if (err instanceof JSONParseError) {
      console.log("JSONParseError")
      res.status(400).send(err.raw)
      return
    }
    next(err)
  })
  return router
}
