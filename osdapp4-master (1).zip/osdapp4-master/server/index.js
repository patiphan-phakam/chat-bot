require("dotenv").config()
const app = require("express")()
const mongoose = require("mongoose")
const morgan = require("morgan")
const cors = require("cors")
const bodyParser = require("body-parser")
app.use(cors())

app.use(morgan("tiny"))
const http = require("http").createServer(app)
const io = require("socket.io")(http, { path: "/socket/socket.io" })
const redisClient = require("./config/redisClient")
const webhookfacebook = require("./routes/webhookFacebook")
const webhookLine = require("./routes/webhookLine")
const sendMessage = require("./routes/api/sendMessage")
const ModelAgent = require("./models/ModelAgent")
const { DB_URI_PROD } = require("./config")
const addAgentQueue = require("./services/addAgentQueue")
const delAgentQueue = require("./services/delAgentQueue")
const timedOutWarning = require("./services/timedOutWarning")
const agentStatus = require("./services/agentStatus")
const match = require("./services/match")
const cronJob = require("./services/cronJob")
const queryString = require("query-string")
// const ioAgentStats = io.of("/agentsstats")
const NamespaceSupervisor = io.of("/supervisor")
const axios = require("axios")

// const io = require("socket.io")(http)

// cron job every midnight
cronJob()

const {
  PORT = process.env.PORT || 5000,
  NODE_ENV,
  MONGO_URI,
  MONGO_USER,
  MONGO_PSW,
} = process.env

mongoose.connect(
  NODE_ENV === "production" ? DB_URI_PROD : DB_URI_PROD,
  { useUnifiedTopology: true, useNewUrlParser: true, useCreateIndex: true },
  () => console.log("mongo connected")
)

// mongoose.connect(
//   MONGO_URI,
//   {
//     useUnifiedTopology: true,
//     useNewUrlParser: true,
//     useCreateIndex: true,
//   },
//   () => console.log("mongo connected")
// )

io.on("connect", onConnect)
// ioAgentStats.on("connect", onConnectAgentStats)
NamespaceSupervisor.on("connection", function (socket) {
  socket.on("supervisor join room", (supervisorGroup) => {
    socket.join(supervisorGroup)
  })
})

function onConnect(socket) {
  console.log(
    "---------------------------------------------------------------------- connected -----------------------------------------------"
  )
  socket.on("agent join room", ({ agentId, skills }) => {
    socket.join(agentId)
    io.to(agentId).emit("roomjoined", agentId)

    redisClient.hgetall(agentId, function (err, reply) {
      // if discussion agent/customer exists, -- reconnect situation -- resend info
      if (reply) {
        match(io, agentId, reply)
        agentStatus.write(redisClient, io, agentId, "busy", reply.skill)
      } else {
        // if discussion agent/customer not exists add agent in array skills
        axios
          .get(`https://dchat.osd.co.th/backend/api/agents/status/${agentId}`)
          .then(({ data }) => {
            if (data.status === "wrapup" || data.status === "break") {
              // agentStatus.write(redisClient, io, agentId, "wrapup")
            } else {
              addAgentQueue(redisClient, io, skills, agentId)
            }
          })
      }
    })
  })

  socket.on("supervisor join agent room", (agentId) => {
    socket.join(agentId)
    io.to(agentId).emit("supervisor roomjoined", agentId)
  })

  let agentInfo = {}
  let userInfo = { userId: null }
  socket.on("storeagentId", (info) => (agentInfo = info))
  socket.on("storeUserId", (info) => (userInfo = info))

  socket.on("disconnect", () => {
    const { agentId, skills } = agentInfo

    if (Object.entries(agentInfo).length !== 0) {
      console.log("disconnect => agentInfo: ", agentInfo)
      console.log("disconnect => userInfo: ", userInfo)
      delAgentQueue(redisClient, io, skills, agentId, "disconnect")
      agentStatus.write(redisClient, io, agentId, "disconnect")
    }
  })
}

app.delete("/backend/all", (req, res) => {
  redisClient.flushall()
  res.send("del")
})

//get currentmsg agent memory - saved in webhookfacebook/line
app.get("/backend/currentmsg/:agentId", function (req, res) {
  const { agentId } = req.params
  redisClient.lrange(`currentmsg${agentId}`, 0, -1, function (err, object) {
    if (err) return console.log(err)
    res.send(object)
  })
})

app.get("/backend/stateagent/:agentId", (req, res) => {
  const { agentId } = req.params

  redisClient.GET(`statusAgent:${agentId}`, function (err, reply) {
    console.log(reply)
    return res.send(JSON.parse(reply))
  })
})

app.delete("/backend/agentsqueue/:agentId", function (req, res) {
  const { agentId } = req.params
  const skills = ["skill1", "skill2", "skill3"]

  const deleteAgent = async () => {
    await skills.map((skill) =>
      redisClient.LREM(skill, 0, agentId, function (err, object) {
        if (err) return console.log(err)
        console.log("agent queue redis: ", object)
      })
    )
    return "done"
  }

  return deleteAgent()
    .then(() => res.send(`agent ${agentId} deleted from memory`))
    .catch((e) => console.log("error: ", e))
})

app.delete("/backend/delkey/:agentId", function (req, res) {
  const { agentId } = req.params
  redisClient.del(agentId)
  res.send(`${agentId} deleted  `)
})

app.get("/backend/resetredis", (req, res) => {
  const delAllKeys = async () => await redisClient.flushall()
  delAllKeys().then(() => res.send(`delete all keys`))
})

app.use("/backend/webhookline", webhookLine(redisClient, io))
app.use(bodyParser.json())

app.post("/backend/closechat", (req, res) => {
  const { userId, agentId, wrapupType, skill, channel } = req.body

  agentStatus.write(redisClient, io, agentId, "wrapup", {
    wrapupType,
    skill,
    channel,
  })
  timedOutWarning() // send warning if wrapup is too long
  // del current chat
  redisClient.del(`currentmsg${agentId}`)
  // del match agent -> customer
  redisClient.del(agentId)
  // del match customer -> agent
  redisClient.del(userId)

  return res.send(`--- ${agentId} close chat with ${userId} ---`)
})

app.get("/backend/queuecustomers/:queue", (req, res) => {
  const { queue } = req.params
  redisClient.lrange(`customerqueue${queue}`, 0, -1, function (err, object) {
    console.log(object)
    return res.json(object)
  })
})

app.get("/backend/queueagents/:queue", (req, res) => {
  const { queue } = req.params
  redisClient.lrange(`agentqueue${queue}`, 0, -1, function (err, object) {
    console.log(object)
    return res.json(object)
  })
})

app.post("/backend/break", (req, res) => {
  const { agentId, closing } = req.body

  agentStatus.write(redisClient, io, agentId, "break")

  // if (closing) {
  //   redisClient.set(`askBreak${agentId}`, 0)
  // } else {
  //   agentStatus.write(redisClient, io, agentId, "break")
  // }

  res.send(`pause ${agentId}`)
})

app.post("/backend/resume", (req, res) => {
  const { agentId, skills } = req.body

  // redisClient.del(`askBreak${agentId}`)

  const addAgent = async (queue) => {
    await redisClient.lpush(`agentqueue${queue}`, agentId)
    await redisClient.lrange(`agentqueue${queue}`, 0, -1, function (
      err,
      object
    ) {
      if (err) return console.log(err)
      console.log(
        `new agent on ${`agentqueue${queue}`} - id availibity redis: `,
        object
      )
    })
    return "done"
  }
  skills.map((queue) => addAgent(queue))
  agentStatus.write(redisClient, io, agentId, "available")
  // io.of("/queueagents").emit("queue agent join", { agentId, skills })
  io.of("/supervisor").emit("global", {
    type: "queue_agent_join",
    agentId,
    skills,
  })

  res.send(`resume ${agentId}`)
})

//TODO backend routes

app.use("/backend/webhookfacebook", webhookfacebook(redisClient, io))
app.use(
  "/backend/api/chat",
  require("./routes/api/chat")(redisClient, io, NamespaceSupervisor)
)

app.use("/backend/sendmessage", sendMessage(redisClient, io))
app.use("/backend/auth", require("./routes/api/auth"))
app.use("/backend/api/agents", require("./routes/api/agents")(redisClient, io))
app.use("/backend/api/alerts", require("./routes/api/alerts")(redisClient, io))
app.use("/backend/api/settings", require("./routes/api/settings"))
app.use("/backend/api/stats", require("./routes/api/stats")(redisClient))
app.use("/backend/api/customers", require("./routes/api/customers"))
app.use(
  "/backend/api/supervisors",
  require("./routes/api/supervisors")(redisClient)
)
app.use(
  "/backend/api/testqueue",
  require("./routes/api/testqueue")(redisClient, io)
)

// //test
// app.get("/backend/test/time", (req, res) => {
//   const today = new Date()
//   const time =
//     today.getHours() + 7 + ":" + today.getMinutes() + ":" + today.getSeconds()
//   res.send(time)
// })

// //test len
// app.get("/backend/test/set/:agentId", (req, res) => {
//   const { agentId } = req.params
//   const item = JSON.stringify({
//     status: "available",
//   })
//   redisClient.lpush(`testdelme${agentId}`, item)

//   res.send("ok")
// })

// app.get("/backend/test/get/:agentId", (req, res) => {
//   const { agentId } = req.params
//   redisClient.lrange(`testdelme${agentId}`, 0, -1, function (err, object) {
//     console.log("array: ", object)
//     console.log(JSON.parse(object[0]))

//     if (err) return console.log(err)
//     res.send(object.map((x) => JSON.parse(x)))
//   })
// })

// app.delete("/backend/test/get/:agentId", (req, res) => {
//   const { agentId } = req.params
//   redisClient.del(`testdelme${agentId}`)
//   res.send("deleted")
// })

// app.get("/backend/testrating/:agentId", (req, res) => {
//   const { agentId } = req.params
//   redisClient.GET(`ratingsAgent:${agentId}`, function (err, reply) {
//     if (err) return res.status(500).send("err")
//     console.log(reply)
//     return res.send(JSON.parse(reply))
//   })
// })

// app.delete("/backend/testrating/:agentId", (req, res) => {
//   const { agentId } = req.params
//   redisClient.del(`ratingsAgent:${agentId}`)
//   return "yolo"
// })

http.listen(PORT, () => console.log(`listening ${PORT}`))
