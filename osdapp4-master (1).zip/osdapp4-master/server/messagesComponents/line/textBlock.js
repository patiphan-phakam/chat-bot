module.exports = (text, PSID) => ({
  to: PSID,
  messages: [
    {
      type: "text",
      text
    }
  ]
})
