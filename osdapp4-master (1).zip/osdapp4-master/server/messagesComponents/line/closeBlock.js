module.exports = (PSID, agentId) => ({
  to: PSID,
  messages: [
    {
      type: "text",
      text: "It was a pleasure helping you, please rate me:",
      quickReply: {
        items: [
          {
            type: "action",
            action: {
              type: "postback",
              label: "1 star",
              data: `{"rating":1,"agentId":"${agentId}", "type": "rating"}`,
              displayText: "1 star",
            },
          },
          {
            type: "action",
            action: {
              type: "postback",
              label: "2 stars",
              data: `{"rating":2,"agentId":"${agentId}", "type": "rating"}`,
              displayText: "2 stars",
            },
          },
          {
            type: "action",
            action: {
              type: "postback",
              label: "3 stars",
              data: `{"rating":3,"agentId":"${agentId}", "type": "rating"}`,
              displayText: "3 stars",
            },
          },
          {
            type: "action",
            action: {
              type: "postback",
              label: "4 stars",
              data: `{"rating":4,"agentId":"${agentId}", "type": "rating"}`,
              displayText: "4 stars",
            },
          },
          {
            type: "action",
            action: {
              type: "postback",
              label: "5 stars",
              data: `{"rating":5,"agentId":"${agentId}", "type": "rating"}`,
              displayText: "5 stars",
            },
          },
        ],
      },
    },
  ],
})

// module.exports = (PSID, agentId) => ({
//   to: PSID,
//   messages: [
//     {
//       type: "text",
//       text: "It was a pleasure helping you, please rate me:",
//       quickReply: {
//         items: [
//           {
//             type: "postback",
//             label: "1 star",
//             data: `{"rating":1,"agentId":"${agentId}", "type": "rating"}`,
//             text: "1 star",
//           },
//           {
//             type: "postback",
//             label: "2 stars",
//             data: `{"rating":2,"agentId":"${agentId}", "type": "rating"}`,
//             text: "2 stars",
//           },
//           {
//             type: "postback",
//             label: "3 stars",
//             data: `{"rating":3,"agentId":"${agentId}", "type": "rating"}`,
//             text: "3 stars",
//           },
//           {
//             type: "postback",
//             label: "4 stars",
//             data: `{"rating":4,"agentId":"${agentId}", "type": "rating"}`,
//             text: "4 stars",
//           },
//           {
//             type: "postback",
//             label: "5 stars",
//             data: `{"rating":5,"agentId":"${agentId}", "type": "rating"}`,
//             text: "5 stars",
//           },
//         ],
//       },
//     },
//   ],
// })
