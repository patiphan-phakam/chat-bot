module.exports = (PSID, agentId) => {
  console.log("AGENT ID", agentId)
  return {
    messaging_type: "response",
    recipient: {
      id: PSID,
    },
    message: {
      text: "It was a pleasure helping you, please rate me:",
      quick_replies: [
        {
          content_type: "text",
          title: "1 star",
          payload: `{"rating":1,"agentId":"${agentId}", "type": "rating"}`,
        },
        {
          content_type: "text",
          title: "2 stars",
          payload: `{"rating":2,"agentId":"${agentId}", "type": "rating"}`,
        },
        {
          content_type: "text",
          title: "3 stars",
          payload: `{"rating":3,"agentId":"${agentId}", "type": "rating"}`,
        },
        {
          content_type: "text",
          title: "4 stars",
          payload: `{"rating":4,"agentId":"${agentId}", "type": "rating"}`,
        },
        {
          content_type: "text",
          title: "5 stars",
          payload: `{"rating":5,"agentId":"${agentId}", "type": "rating"}`,
        },
      ],
    },
  }
}
