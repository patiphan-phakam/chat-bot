module.exports = PSID => ({
  messaging_type: "response",
  recipient: {
    id: PSID
  },
  message: {
    attachment: {
      type: "template",
      payload: {
        template_type: "button",
        text: "please call me!!",
        buttons: [
          {
            type: "phone_number",
            title: "Call Agent",
            payload: "+66982534532"
          }
        ]
      }
    }
  }
})
