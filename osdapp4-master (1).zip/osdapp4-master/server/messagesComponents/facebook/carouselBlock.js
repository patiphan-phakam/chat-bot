module.exports = PSID => ({
  messaging_type: "response",
  recipient: {
    id: PSID
  },
  message: {
    attachment: {
      type: "template",
      payload: {
        template_type: "generic",
        elements: [
          {
            title: "Product 1",
            image_url: "https://picsum.photos/id/866/200/200",
            subtitle: "nice product",
            default_action: {
              type: "web_url",
              url: "https://www.lazada.co.th/",
              webview_height_ratio: "tall"
            },
            buttons: [
              {
                type: "web_url",
                url: "https://www.lazada.co.th/",
                title: "View Website"
              }
            ]
          },
          {
            title: "product 2",
            image_url: "https://picsum.photos/id/866/200/200",
            subtitle: "best product",
            default_action: {
              type: "web_url",
              url: "https://www.lazada.co.th/",
              webview_height_ratio: "tall"
            },
            buttons: [
              {
                type: "web_url",
                url: "https://www.lazada.co.th/",
                title: "View Website"
              }
            ]
          },
          {
            title: "product 3",
            image_url: "https://picsum.photos/id/866/200/200",
            subtitle: "best product in the world",
            default_action: {
              type: "web_url",
              url: "https://www.lazada.co.th/",
              webview_height_ratio: "tall"
            },
            buttons: [
              {
                type: "web_url",
                url: "https://www.lazada.co.th/",
                title: "View Website"
              }
            ]
          }
        ]
      }
    }
  }
})
