module.exports = (text, PSID) => ({
  messaging_type: "response",
  recipient: {
    id: PSID
  },
  message: {
    text
  }
})
