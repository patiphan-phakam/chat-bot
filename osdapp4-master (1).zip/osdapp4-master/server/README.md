# osdserver

me link: m.me/110615557039260

redis keys:

`agentqueue${queue}`: [agentId, agentId]
agentId: userId

`statusAgent:${agentId}`

api
stats
api/stats/todaywaiting

--

//

{
"\_id" : ObjectId("5ddc93d61c9d440000e2c6ba"),
"email" : "agentskill1skill2@gmail.com",
"password" : "$2b$10\$rm.8acpwBIt3/ahykFIKx.XcaMyV5G9WZUofkcaQT0V5pAuD3q0oe",
"skills" : [
"skill1",
"skill2"
],
"customers" : [
{
"id" : "2807938259293308",
"channel" : "facebook",
"chat" : [
{
"author" : "user",
"msg" : "I have error problem!",
"type" : "text",
"date" : ISODate("2020-03-20T04:07:24.000Z")
},
{
"author" : "me",
"msg" : "Hello, welcome!",
"type" : "text",
"date" : ISODate("2020-03-20T07:27:25.202Z")
},
{
"author" : "me",
"msg" : "Sure.",
"type" : "text",
"date" : ISODate("2020-03-20T07:27:25.222Z")
},
{
"author" : "me",
"msg" : "Please wait a moment, I am asking IT team.",
"type" : "text",
"date" : ISODate("2020-03-20T07:27:25.232Z")
},
{
"author" : "me",
"msg" : "Server is updating.",
"type" : "text",
"date" : ISODate("2020-03-20T07:27:25.232Z")
},
{
"author" : "me",
"msg" : "Any other question?",
"type" : "text",
"date" : ISODate("2020-03-20T07:27:25.252Z")
}
],
"firstname" : "Francois",
"lastname" : "Pierre",
"gender" : "male",
"date" : ISODate("2020-03-20T07:27:24.202Z"),
"address" : "hi",
"email" : null,
"mobile" : "4324234",
"notes" : "hdghgfh"
},
{
"id" : "1807938259293308",
"channel" : "facebook",
"chat" : [
{
"author" : "user",
"msg" : "Hello, I need help",
"type" : "text",
"date" : ISODate("2020-03-20T04:07:24.000Z")
},
{
"author" : "me",
"msg" : "Sure, how can I help?",
"type" : "text",
"date" : ISODate("2020-03-20T07:27:25.202Z")
}
],
"firstname" : "George",
"lastname" : "Psartek",
"gender" : "male",
"date" : ISODate("2020-03-20T04:07:24.514Z"),
"address" : "hi",
"email" : null,
"mobile" : "4324234",
"notes" : "hdghgfh"
},
{
"id" : "3807938259293308",
"channel" : "facebook",
"chat" : [
{
"author" : "user",
"msg" : "Hello, I need help",
"type" : "text",
"date" : ISODate("2020-03-20T04:07:24.000Z")
},
{
"author" : "me",
"msg" : "Sure, how can I help?",
"type" : "text",
"date" : ISODate("2020-03-20T07:27:25.202Z")
},
{
"author" : "user",
"msg" : "I did not get invoice",
"type" : "text",
"date" : ISODate("2020-03-20T07:27:25.202Z")
},
{
"author" : "me",
"msg" : "Ok, could you tell me the order id please? thank you.",
"type" : "text",
"date" : ISODate("2020-03-20T04:09:25.514Z")
}
],
"firstname" : "Philipe",
"lastname" : "Claude",
"gender" : "male",
"date" : ISODate("2020-03-20T04:07:24.514Z"),
"address" : "hi",
"email" : null,
"mobile" : "4324234",
"notes" : "hdghgfh"
},
{
"id" : "4807938259293308",
"channel" : "facebook",
"chat" : [
{
"author" : "user",
"msg" : "Hello, I need help",
"type" : "text",
"date" : ISODate("2020-03-20T04:07:24.000Z")
},
{
"author" : "me",
"msg" : "Sure, how can I help?",
"type" : "text",
"date" : ISODate("2020-03-20T07:27:25.202Z")
},
{
"author" : "user",
"msg" : "I did not get invoice",
"type" : "text",
"date" : ISODate("2020-03-20T07:27:25.202Z")
},
{
"author" : "me",
"msg" : "Ok, could you tell me the order id please? thank you.",
"type" : "text",
"date" : ISODate("2020-03-20T04:10:25.514Z")
}
],
"firstname" : "Jean",
"lastname" : "Edouard",
"gender" : "male",
"date" : ISODate("2020-03-20T04:07:24.514Z"),
"address" : "hi",
"email" : null,
"mobile" : "4324234",
"notes" : "hdghgfh"
}
],
"breaks" : [
{
"start" : "2019-11-25T17:12:00.000Z",
"end" : "2019-11-25T17:15:00.000Z",
"type" : "break"
},
{
"start" : "2019-11-25T20:15:00.000Z",
"end" : "2019-11-25T20:46:00.000Z",
"type" : "edithistory"
}
],
"mytodos" : [
"my todo1",
"my todo2"
],
"myComponents" : [
{
"title" : "Component 1",
"type" : "text",
"content" : "text component 1"
},
{
"title" : "Component 2",
"type" : "text",
"content" : "text component 2"
},
{
"title" : "Component 3",
"type" : "text",
"content" : "text component 3"
}
],
"updatedAt" : ISODate("2020-03-30T11:11:05.486Z")
}

[
{_id: ObjectId("5ddc93d61c9d440000e2c6ba"), userId: "2807938259293308"},
{_id: ObjectId("6ddc93d61c9d440000e2c6ba"), userId: "1807938259293308"},
{_id: ObjectId("7ddc93d61c9d440000e2c6ba"), userId: "4807938259293308"},
{_id: ObjectId("8ddc93d61c9d440000e2c6ba"), userId: "3807938259293308"},
{_id: ObjectId("9ddc93d61c9d440000e2c6ba"), userId: "2807938259293310"}
]

"2807938259293308",
"1807938259293308",
"4807938259293308",
"3807938259293308",
"2807938259293310"
