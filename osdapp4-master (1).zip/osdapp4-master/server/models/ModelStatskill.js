const mongoose = require("mongoose")

const Schema = mongoose.Schema(
  {
    date: { type: Date, required: true },
    messenger: mongoose.Schema.Types.Mixed,
    line: mongoose.Schema.Types.Mixed,
  },
  { timestamps: true }
)

module.exports = mongoose.model("Statsskill", Schema)
