const mongoose = require("mongoose")

const Schema = mongoose.Schema({
  date: { type: Date, required: true },
  skill: String,
  source: String,
  agentid: String,
  customerid: String,
  customername: String,
  chatid: String,
  status: String,
  duration: Number,
})

module.exports = mongoose.model("Statschat", Schema)
