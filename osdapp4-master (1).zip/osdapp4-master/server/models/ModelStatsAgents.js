const mongoose = require("mongoose")

const Schema = mongoose.Schema({
  date: { type: Date, required: true },
  agents: mongoose.Schema.Types.Mixed,
})

module.exports = mongoose.model("Statsagent", Schema)
