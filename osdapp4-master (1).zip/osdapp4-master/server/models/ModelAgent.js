const mongoose = require("mongoose")

const Schema = mongoose.Schema(
  {
    email: { type: String, required: true },
    name: { type: String, required: true },
    password: { type: String, required: true },
    skills: [String],
    customers: [String],
  },
  { timestamps: true }
)

module.exports = mongoose.model("Agent", Schema)
