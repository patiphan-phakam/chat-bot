const mongoose = require("mongoose")

const Schema = mongoose.Schema(
  {
    _id: String,
    channel: String,
    firstname: String,
    lastname: String,
    address: String,
    email: String,
    mobile: String,
    gender: String,
    notes: String,
    skill: String,
    chat: [
      {
        author: String,
        msg: String,
        date: Date,
      },
    ],
  },
  { timestamps: true }
)

module.exports = mongoose.model("Customer", Schema)

// const mongoose = require("mongoose")

// const Schema = mongoose.Schema(
//   {
//     _id: String,
//     channel: String,
//     firstname: String,
//     lastname: String,
//     address: String,
//     email: String,
//     mobile: String,
//     gender: String,
//     notes: String,
//     skill: String,
//     chat: [
//       {
//         agent: { type: mongoose.Schema.ObjectId, ref: "Agent" },
//         rating: Number,
//         durationSec: Number,
//         todoAchieved: Number,
//         interested: String,
//         timeEditProfileSec: Number,
//         notes: String,
//         messages: [
//           {
//             _id: {
//               type: mongoose.Schema.Types.ObjectId,
//               index: true,
//               auto: true,
//             },
//             author: String,
//             date: Date,
//             text: String,
//           },
//         ],
//       },
//     ],
//   },
//   { timestamps: true }
// )

// module.exports = mongoose.model("Customer", Schema)
