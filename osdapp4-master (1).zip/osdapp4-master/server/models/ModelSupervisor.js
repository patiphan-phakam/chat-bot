const mongoose = require("mongoose")

const Schema = mongoose.Schema(
  {
    email: { type: String, required: true },
    superadmin: Boolean,
    password: { type: String, required: true },
    skills: [String]
    // agents: [{ type: mongoose.Schema.ObjectId, ref: "Agent" }]
  },
  { timestamps: true }
)

module.exports = mongoose.model("Supervisor", Schema)
