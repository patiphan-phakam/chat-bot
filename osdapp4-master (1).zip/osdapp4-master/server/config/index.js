const PAGE_ACCESS_TOKEN =
  "EAAHQZCaznRV4BAF7bYgwkthLHd2WZCaXtMUQDXEv31USrn0Rix10m516zbZAHetyrkaNHT2Dy9ZBmSzLhcsKPZCj7rAq2pY19aCLIZCXZBZAAlDE0uPZCJDGNxl9hd4YlvlmR4zwOrNEnhPHSDxZC8RmYN7BUacmLh7DWJtkqrerxqiQZDZD"

const CHANNEL_ACCESS_TOKEN =
  "+BUzkYravdxlS3ia79w7W+OseLc7Xrzc8w+9rpE0vtLyA52r3m2Cqc0XZy+UdCVzawfZkbSGy/SFE/P8jK07afs3HI5KilRVDHKU9dAH/0hdWmJ4aFN7vegL0pesCQEC7DMclz5DFMQag0cRQbDBwAdB04t89/1O/w1cDnyilFU="
const CHANNEL_SECRET = "b636e26a3af07a362991059da641f178"
const DB_URI_DEV = "mongodb://localhost:27017/osd-omni"
const DB_URI_PROD =
  "mongodb+srv://admin123:SnTzhoBddDWyiTnC@cluster0-4xhbj.mongodb.net/osd-omni?retryWrites=true&w=majority"

module.exports = {
  CHANNEL_SECRET,
  PAGE_ACCESS_TOKEN,
  CHANNEL_ACCESS_TOKEN,
  DB_URI_DEV,
  DB_URI_PROD,
}
