const redisClient = require("redis").createClient(process.env.REDIS_URL ? process.env.REDIS_URL : '')

// const redisClient = require("redis").createClient()

// const redisClient = require("redis").createClient({
//   url:
//     "redis://redistogo:038e3b3610034a78005ff1dbd4b582e7@spinyfin.redistogo.com:11035",
// })

module.exports = redisClient