const ModelSettings = require("../models/ModelSettings")

module.exports = {
  read: () => {
    return new Promise((resolve, reject) => {
      ModelSettings.findOne({}, (err, docs) => {
        if (err) return reject(err)
        resolve(docs)
      })
    })
  }
}
