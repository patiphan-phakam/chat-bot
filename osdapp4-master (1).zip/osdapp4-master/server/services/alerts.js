const uniqid = require("uniqid")

module.exports = {
  read: (redisClient) => {
    return new Promise((resolve, reject) => {
      redisClient.GET(`alerts`, function (err, reply) {
        const parsedReply = JSON.parse(reply)

        if (err) return reject(err)
        resolve(parsedReply)
      })
    })
  },
  write: (redisClient, io, agentId, skill) => {
    const date = new Date().toLocaleString("en-US", {
      timeZone: "Asia/Bangkok",
    })
    const stamp = new Date(date).getTime()
    const alertId = uniqid()
    return new Promise((resolve, reject) => {
      redisClient.GET(`alerts`, function (err, reply) {
        if (err) return reject(err)
        const parsedReply = JSON.parse(reply)

        if (parsedReply) {
          const data1 = {
            ...parsedReply,
            [alertId]: {
              date,
              agentId,
              skill,
              solved: false,
              stamp,
            },
          }
          redisClient.SET(`alerts`, JSON.stringify(data1))
          resolve(data1)
        } else {
          const data2 = {
            [alertId]: { date, agentId, skill, solved: false, stamp },
          }
          redisClient.SET(`alerts`, JSON.stringify(data2))
          resolve(data2)
        }
        io.of("/supervisor").in(skill).emit("global", {
          type: "newalert",
          date,
          agentId,
          solved: false,
          alertId,
          skill,
          stamp,
        })
      })
    })
  },
  solving: (redisClient, io, alertId) => {
    console.log("------------- SOLVING")
    return new Promise((resolve, reject) => {
      redisClient.GET(`alerts`, function (err, reply) {
        if (err) return reject(err)
        const parsedReply = JSON.parse(reply)
        const memData = parsedReply[alertId]

        const data = {
          ...parsedReply,
          [alertId]: { ...memData, solved: memData.agentId },
        }

        redisClient.SET(`alerts`, JSON.stringify(data))
        io.in(`supervisor:${memData.skill}`).emit("alert", {
          type: "solvingalert",
          [alertId]: { ...memData, solved: memData.agentId },
        })
        resolve(parsedReply)
      })
    })
  },
}
