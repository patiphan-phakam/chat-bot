const ModelAgent = require("../models/ModelAgent")
const ModelCustomer = require("../models/ModelCustomer")

module.exports = {
  readAll: (queries) => {
    const query = queries.skills
      ? { skills: { $in: queries.skills.split(",") } }
      : {}
    return new Promise((resolve, reject) => {
      ModelAgent.find(query, (err, docs) => {
        if (err) return reject(err)
        resolve(docs)
      })
    })
  },
  read: (_id) => {
    return new Promise((resolve, reject) => {
      ModelAgent.findById(_id, (err, doc) => {
        if (err) return reject(err)
        return doc
      }).then((data) => {
        ModelCustomer.find(
          {
            _id: {
              $in: data.customers,
            },
          },
          (err, docs) => {
            if (err) return reject(err)
            return docs
          }
        ).then((dati) => {
          return resolve({
            skills: data.skills,
            customers: dati,
            _id: data._id,
            email: data.email,
            password: data.password,
          })
        })
      })
    })
  },
  delSkills: (agents, skill) => {
    return new Promise((resolve, reject) => {
      ModelAgent.updateMany(
        { _id: { $in: agents } },
        {
          $pull: {
            skills: skill,
          },
        },
        (err, doc) => {
          if (err) return reject(err)
          if (doc) {
            console.log(doc)
          }
          resolve(doc)
        }
      )
    })
  },
  addSkills: (agents, skill) => {
    return new Promise((resolve, reject) => {
      ModelAgent.updateMany(
        { _id: { $in: agents } },
        {
          $push: {
            skills: skill,
          },
        },
        (err, doc) => {
          if (err) return reject(err)
          if (doc) {
            console.log(doc)
          }
          resolve(doc)
        }
      )
    })
  },
  update: (_id, queries) => {
    console.log("queries", queries)
    return new Promise((resolve, reject) => {
      ModelAgent.findOneAndUpdate(
        { _id },
        queries,
        {
          upsert: true,
          setDefaultsOnInsert: true,
          new: true,
          useFindAndModify: false,
        },
        (err, doc) => {
          if (err) return reject(err)
          if (doc) {
            console.log(doc)
          }
          resolve(doc)
          doc.save("done")
        }
      )
    })
  },
}
