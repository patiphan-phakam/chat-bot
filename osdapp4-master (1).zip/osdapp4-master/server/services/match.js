module.exports = (io, agentId, reply) => {
  const { skill, userId, channel } = reply

  io.in(agentId).emit(`match user/agent`, {
    skill,
    userId,
    agentId,
    channel,
  })
}
