const cron = require("cron").CronJob
const axios = require("axios")

module.exports = () => {
  return new cron(
    "00 00 00 * * *",
    function () {
      axios
        .get(`https://dchat.osd.co.th/backend/api/agents`)
        .then(({ data }) => {
          const agentList = data.map((x) => x._id)
          axios
            .post(`https://dchat.osd.co.th/backend/api/stats/redistomongo`, {
              agents: agentList,
            })
            .then(() => console.log("agents added"))
            .catch((e) => console.log("could not add agents"))

          axios
            .post(
              `https://dchat.osd.co.th/backend/api/stats/redistomongoskillstats`,
              {
                agents: agentList,
              }
            )
            .then(() => console.log("skills stats added"))
            .catch((e) => console.log("could not add skills stats"))
        })
        .catch((e) => console.log(e))
    },
    null,
    true,
    "Asia/Bangkok"
  ).start()
}
