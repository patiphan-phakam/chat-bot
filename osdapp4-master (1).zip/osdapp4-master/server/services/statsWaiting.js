const dateFormat = require("dateformat")

module.exports = {
  add: (start, data, redisClient, io) => {
    const { userId, channel, skill } = data
    const end = new Date()
    const duration = (end.getTime() - start.getTime()) / 1000
    console.log("duration sec: ", duration)

    redisClient.lpush(
      `statsTodayWaiting`,
      JSON.stringify({
        userId,
        channel,
        skill,
        duration,
        start,
        end,
      })
    )
  },
  get: (redisClient) => {
    const data = async () => {
      await redisClient.lrange(`statsTodayWaiting`, 0, -1, function (
        err,
        reply
      ) {
        const parsed = reply.map((x) => JSON.parse(x))
        if (err) return console.log("error lrange `statsTodayWaiting` ", err)
        return reply.map((x) => JSON.parse(x))
      })
    }
    return data().then((res) => res)
  },
}
