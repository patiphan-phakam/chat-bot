const agentStatus = require("./agentStatus")

module.exports = (redisClient, io, skills, agentId) => {
  const addAgent = async queue => {
    await redisClient.lpush(`agentqueue${queue}`, agentId)
    await redisClient.lrange(`agentqueue${queue}`, 0, -1, function(
      err,
      object
    ) {
      if (err) return console.log(err)
      console.log(
        `new agent on ${`agentqueue${queue}`} - id availibity redis: `,
        object
      )
    })
    return "done"
  }
  skills.map(queue => addAgent(queue))
  agentStatus.write(redisClient, io, agentId, "available")
  // io.of("/queueagents").emit("queue agent join", { agentId, skills })
  io.of("/supervisor").emit("global", {
    type: "queue_agent_join",
    agentId,
    skills
  })
}
