module.exports = {
  write: (redisClient, io, agentId, rating) => {
    const dateNow = new Date(
      new Date().toLocaleString("en-US", { timeZone: "Asia/Bangkok" })
    )
    // const dateH = dateFormat("hh", dateNow)
    const dateH = dateNow.getHours().toString()
    console.log("dateH", dateH)
    redisClient.GET(`ratingsAgent:${agentId}`, function(err, reply) {
      const parsedReply = JSON.parse(reply)

      if (parsedReply) {
        const addValue =
          parsedReply[dateH] && parsedReply[dateH][`stars${rating}`]
            ? parsedReply[dateH][`stars${rating}`] + 1
            : 1

        redisClient.SET(
          `ratingsAgent:${agentId}`,
          JSON.stringify({
            ...parsedReply,
            [dateH]: {
              ...parsedReply[dateH],
              [`stars${rating}`]: addValue
            }
          })
        )

        console.log(
          "---- parsed: ",
          JSON.stringify({
            ...parsedReply,
            [dateH]: {
              [`stars${rating}`]: addValue
            }
          })
        )
        io.in(agentId).emit("agent ws", {
          type: "rating",
          rating: {
            ...parsedReply,
            [dateH]: {
              ...parsedReply[dateH],
              [`stars${rating}`]: addValue
            }
          }
        })
        io.of("/supervisor").emit("global", {
          type: "rating",
          agentId,
          data: {
            ...parsedReply,
            [dateH]: {
              [`stars${rating}`]: addValue
            }
          }
        })
      } else {
        redisClient.SET(
          `ratingsAgent:${agentId}`,
          JSON.stringify({
            [dateH]: {
              [`stars${rating}`]: 1
            }
          })
        )
        io.in(agentId).emit("agent ws", {
          type: "rating",
          rating: {
            [dateH]: {
              [`stars${rating}`]: 1
            }
          }
        })
        io.of("/supervisor").emit("global", {
          type: "rating",
          agentId,
          data: {
            [dateH]: {
              [`stars${rating}`]: 1
            }
          }
        })

        console.log(
          "---- NOT parsed: ",
          JSON.stringify({
            [dateH]: {
              name: `${dateH}h`,
              [`stars${rating}`]: 1
            }
          })
        )
      }
    })
  }
}
