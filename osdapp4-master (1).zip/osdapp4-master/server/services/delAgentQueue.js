const agentStatus = require("./agentStatus")

module.exports = (
  redisClient,
  io,
  skills,
  agentId,
  status,
  skill,
  waitingTime
) => {
  // io.of("/queueagents").emit("queue agent leave", { agentId: agentId, skills })
  io.of("/supervisor").emit("global", {
    type: "queue_agent_leave",
    agentId,
    skills,
    skill
  })
  skills.map(queue =>
    redisClient.LREM(`agentqueue${queue}`, 0, agentId, function(err, object) {
      if (err) return console.log(err)
      console.log(`agentId: ${agentId} skill: ${queue} deleted`)
    })
  )
  agentStatus.write(redisClient, io, agentId, status, skill, waitingTime)
}
