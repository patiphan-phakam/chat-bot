module.exports = async () => {
  await new Promise(resolve => setTimeout(resolve, 10000))
  await console.log(
    "--------------- TIMEDDDDD OUUUUTTTTTTTT WARNING ----------------"
  )
}
