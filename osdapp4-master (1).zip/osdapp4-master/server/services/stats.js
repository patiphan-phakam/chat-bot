const ModelStatskill = require("../models/ModelStatskill")
const ModelStatsAgents = require("../models/ModelStatsAgents")
const ModelStatsChat = require("../models/ModelStatsChat")
const axios = require("axios")

const dateTomorrow = (endDate) => {
  let tomorrow = new Date(endDate)
  tomorrow.setDate(tomorrow.getDate() + 1)
  return tomorrow
}
module.exports = {
  cronJobStatsSkills: (redisClient, agents) => {
    return new Promise((resolve, reject) => {
      const resu = {
        messenger: {},
        line: {},
      }

      let accumulateChatTime = 0
      agents.map((y, i) => {
        axios
          .get(`https://dchat.osd.co.th/backend/api/agents/status/${y}`)
          .then(({ data }) => {
            data.statusHistory.map((x) => {
              const selectChannel =
                x.channel === "facebook" ? "messenger" : x.channel
              if (x.status === "busy") {
                accumulateChatTime = x.duration + accumulateChatTime
              } else if (x.status === "wrapup") {
                if (resu[selectChannel][x.skill]) {
                  resu[selectChannel][x.skill] = {
                    totalAnswers: resu[selectChannel][x.skill].totalAnswers + 1,
                    abandonCustomers: 0,
                    waitingTime:
                      resu[selectChannel][x.skill].waitingTime +
                      accumulateChatTime,
                  }
                } else {
                  resu[selectChannel][x.skill] = {
                    totalAnswers: 1,
                    abandonCustomers: 0,
                    waitingTime: accumulateChatTime,
                  }
                }
                accumulateChatTime = 0
                prevI = true
              }
            })
          })
          .then(() => {
            if (i === agents.length - 1) {
              const newStatsSkills = ModelStatskill({
                date: new Date(),
                ...resu,
              })

              newStatsSkills.save((err, data) => {
                console.log(err, "err ModelStatskill save")
                if (err) return res.status(404).end()
                return resolve("success")
              })
            }
          })
          .catch((e) => reject(e))
      })
    })
  },
  cronjobRedisToMongo: (redisClient, agents) => {
    return new Promise((resolve, reject) => {
      const normalize = (agentData) => {
        const result = {
          line: {
            chatTime: 0,
            answer: 0,
            notAnswer: 0,
          },
          messenger: {
            chatTime: 0,
            answer: 0,
            notAnswer: 0,
          },
        }
        let accumulateChatTime = 0
        agentData.map((x) => {
          if (x.status === "busy") {
            accumulateChatTime = x.duration + accumulateChatTime
          } else if (x.status === "wrapup") {
            result[
              x.channel === "facebook" ? "messenger" : x.channel
            ].chatTime =
              result[x.channel === "facebook" ? "messenger" : x.channel]
                .chatTime + accumulateChatTime
            result[x.channel === "facebook" ? "messenger" : x.channel].answer =
              result[x.channel === "facebook" ? "messenger" : x.channel]
                .answer + 1
            accumulateChatTime = 0
          }
        })
        return result
      }

      const dataAllAgents = {
        // fdskfjdsklfdsf: {}
        //fdwfsdljfsdf: {}
      }

      agents.map((x, i) => {
        redisClient.GET(`statusAgent:${x}`, function (err, replyStats) {
          const parsedReply = JSON.parse(replyStats)
          if (!parsedReply || !parsedReply.statusHistory) {
            dataAllAgents[x] = {
              line: {
                chatTime: 0,
                answer: 0,
                notAnswer: 0,
              },
              messenger: {
                chatTime: 0,
                answer: 0,
                notAnswer: 0,
              },
            }
          }
          if (parsedReply && parsedReply.statusHistory) {
            dataAllAgents[x] = normalize(parsedReply.statusHistory)
          }
          if (i === agents.length - 1) {
            const newStatsAgents = ModelStatsAgents({
              date: new Date(),
              agents: dataAllAgents,
            })

            newStatsAgents.save((err, data) => {
              console.log(err, "err newStatsAgents save")
              if (err) return res.status(404).end()
              return resolve("success")
            })
          }
        })
      })
    })
  },
  readReportChat: ({
    startDate,
    endDate,
    skill,
    source,
    agent,
    customerid,
    customername,
    chatid,
    status,
    duration = 0,
  }) => {
    return new Promise((resolve, reject) => {
      const query = () => {
        const allKeys = {
          skill,
          source,
          agent,
          customerid,
          customername,
          chatid,
          status,
          duration,
        }
        Object.entries(allKeys).map((x) => {
          if (!x[1]) {
            delete allKeys[x[0]]
          }
        })
        return {
          date: {
            $gte: new Date(startDate),
            $lte: dateTomorrow(endDate),
          },
          ...allKeys,
          duration: {
            $gte: duration,
          },
        }
      }
      ModelStatsChat.find(query()).exec((err, docs) => {
        if (err) return reject(err)
        return resolve(docs)
      })
    })
  },
  readReportOneAgent: (_id, startDate, endDate) => {
    return new Promise((resolve, reject) => {
      ModelStatsAgents.find({
        date: {
          $gte: new Date(startDate),
          $lte: dateTomorrow(endDate),
        },
      })
        .select(`date agents.${_id}`)
        .exec((err, docs) => {
          if (err) return reject(err)
          return resolve(
            docs.map((x) => ({
              date: x.date,
              line: x.agents[_id].line,
              messenger: x.agents[_id].messenger,
              total: {
                answered:
                  x.agents[_id].line.answered +
                  x.agents[_id].messenger.answered,
                notAnswered:
                  x.agents[_id].line.notAnswered +
                  x.agents[_id].messenger.notAnswered,
                chatTime:
                  x.agents[_id].line.chatTime +
                  x.agents[_id].messenger.chatTime,
              },
            }))
          )
        })
    })
  },
  readReportAllAgents: (startDate, endDate) => {
    // new Date("2020-06-04"),
    // new Date("2020-06-08"),
    return new Promise((resolve, reject) => {
      // let tomorrow = new Date(endDate)
      // tomorrow.setDate(tomorrow.getDate() + 1)
      ModelStatsAgents.find({
        date: {
          $gte: new Date(startDate),
          $lte: dateTomorrow(endDate),
        },
      }).exec((err, docs) => {
        if (err) return reject(err)
        return resolve(docs)
      })
    })
  },
  readReportSkill: (startDate, endDate, skills = ["skill1", "skill2"]) => {
    // new Date("2020-06-04"),
    // new Date("2020-06-08"),
    return new Promise((resolve, reject) => {
      // let tomorrow = new Date(endDate)
      // tomorrow.setDate(tomorrow.getDate() + 1)
      ModelStatskill.find({
        date: {
          $gte: new Date(startDate),
          $lte: dateTomorrow(endDate),
        },
      }).exec((err, docs) => {
        if (err) return reject(err)
        return resolve(docs)
      })
    })
  },
  // read: (startDate, endDate) => {
  //   return new Promise((resolve, reject) => {
  //     ModelStats.find(
  //       { day: { $gte: startDate, $lte: endDate } },
  //       (err, docs) => {
  //         if (err) return reject(err)
  //         resolve(docs)
  //       }
  //     )
  //   })
  // },
  totalSessionsWrite: (redisClient, io, skill) => {
    redisClient.GET(`totalSessions`, function (err, reply) {
      const parsedReply = JSON.parse(reply)
      if (parsedReply) {
        redisClient.SET(
          `totalSessions`,
          JSON.stringify({
            ...parsedReply,
            [skill]: parsedReply[skill] ? parsedReply[skill] + 1 : 1,
          })
        )
        io.of("/supervisor").emit("global", {
          type: "total_sessions",
          data: {
            ...parsedReply,
            [skill]: parsedReply[skill] ? parsedReply[skill] + 1 : 1,
          },
        })
      } else {
        redisClient.SET(
          `totalSessions`,
          JSON.stringify({
            [skill]: 1,
          })
        )
        io.of("/supervisor").emit("global", {
          type: "total_sessions",
          data: { [skill]: 1 },
        })
      }
    })
  },
  totalSessionsRead: (redisClient) => {
    return new Promise((resolve, reject) => {
      redisClient.GET(`totalSessions`, function (err, reply) {
        const parsedReply = JSON.parse(reply)

        if (err) return reject(err)
        return resolve(parsedReply)
      })
    })
  },
  totalCustomerWaitingWrite: (redisClient, io, skill, duration) => {
    redisClient.GET(`totalDurationWaiting`, function (err, reply) {
      const parsedReply = JSON.parse(reply)
      if (parsedReply) {
        redisClient.SET(
          `totalDurationWaiting`,
          JSON.stringify({
            ...parsedReply,
            [skill]: parsedReply[skill]
              ? parsedReply[skill] + duration
              : duration,
          })
        )
        io.of("/supervisor").emit("global", {
          type: "total_duration_waiting",
          data: {
            ...parsedReply,
            [skill]: parsedReply[skill]
              ? parsedReply[skill] + duration
              : duration,
          },
        })
      } else {
        redisClient.SET(
          `totalDurationWaiting`,
          JSON.stringify({
            [skill]: duration,
          })
        )
        io.of("/supervisor").emit("global", {
          type: "total_duration_waiting",
          data: { [skill]: duration },
        })
      }
    })
  },
  totalCustomerWaitingRead: (redisClient) => {
    return new Promise((resolve, reject) => {
      redisClient.GET(`totalDurationWaiting`, function (err, reply) {
        const parsedReply = JSON.parse(reply)
        if (err) return reject(err)
        return resolve(parsedReply)
      })
    })
  },
}

// module.exports = {
//     read: (startDate, endDate) => {
//       return new Promise((resolve, reject) => {
//         ModelStats.find(
//           { date: { $gte: startDate, $lte: endDate } },
//           (err, docs) => {
//             if (err) return reject(err)
//             resolve(docs)
//           }
//         )
//       })
//     }
//   }

// return new Promise((resolve, reject) => {
//   ModelStatskill.aggregate([
//     {
//       $match: {
//         date: {
//           $gte: new Date(startDate),
//           $lte: new Date(endDate),
//         },
//       },
//     },
//     {
//       $group: {
//         _id: null,
//         skill1_totalAnswers: { $sum: "$skills.skill1.totalAnswers" },
//       },
//     },
//   ]).exec((err, docs) => {
//     if (err) return reject(err)
//     return resolve(docs)
//   })
// })
