module.exports = (redisClient, io, chatGroupId, senderId) => ({
  sendMsg: () => {
    console.log("uo")
  }
})
