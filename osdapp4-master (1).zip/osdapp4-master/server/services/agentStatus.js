const statsService = require("./stats")

module.exports = {
  write: (redisClient, io, agentId, status, option, waitingTime) => {
    const dateNow = new Date()
    redisClient.GET(`statusAgent:${agentId}`, function (err, reply) {
      const parsedReply = JSON.parse(reply)


      if (parsedReply) {
        if (status !== parsedReply.status) {
          // calculate duration to previous value
          parsedReply.statusHistory[
            parsedReply.statusHistory.length - 1
          ].duration =
            dateNow -
            new Date(
              parsedReply.statusHistory[
                parsedReply.statusHistory.length - 1
              ].start
            )

          if (status === "busy") {
            redisClient.SET(
              `statusAgent:${agentId}`,
              JSON.stringify({
                ...parsedReply,
                status,
                statusHistory: [
                  ...parsedReply.statusHistory,
                  {
                    status,
                    duration: null,
                    start: dateNow,
                    skill: option,
                    waitingTime,
                  },
                ],
              })
            )
            io.in(agentId).emit("agent ws", {
              type: "status",
              status,
              start: dateNow,
              skill: option,
              waitingTime,
            })

            io.of("/supervisor").emit("global", {
              type: "status",
              agentId,
              status,
              start: dateNow,
              skill: option,
              waitingTime,
            })
            statsService.totalSessionsWrite(redisClient, io, option)
            statsService.totalCustomerWaitingWrite(
              redisClient,
              io,
              option,
              waitingTime
            )
          }

          if (status === "disconnect") {
            redisClient.SET(
              `statusAgent:${agentId}`,
              JSON.stringify({
                ...parsedReply,
                status,
                statusHistory: [
                  ...parsedReply.statusHistory,
                  {
                    status,
                    duration: null,
                    start: dateNow,
                  },
                ],
              })
            )
            io.in(agentId).emit("agent ws", {
              type: "status",
              status,
              start: dateNow,
            })

            io.of("/supervisor").emit("global", {
              type: "status",
              agentId,
              status,
              start: dateNow,
            })
          }
          if (status === "wrapup") {
            redisClient.SET(
              `statusAgent:${agentId}`,
              JSON.stringify({
                ...parsedReply,
                status,
                statusHistory: [
                  ...parsedReply.statusHistory,
                  {
                    status,
                    duration: null,
                    start: dateNow,
                    wrapupType: option.wrapupType,
                    skill: option.skill,
                    channel: option.channel,
                  },
                ],
              })
            )
            io.in(agentId).emit("agent ws", {
              type: "status",
              status,
              start: dateNow,
              wrapupType: option,
            })

            io.of("/supervisor").emit("global", {
              type: "status",
              agentId,
              status,
              start: dateNow,
              wrapupType: option,
            })
          }
          if (status === "available" || status === "break") {
            redisClient.SET(
              `statusAgent:${agentId}`,
              JSON.stringify({
                ...parsedReply,
                status,
                statusHistory: [
                  ...parsedReply.statusHistory,
                  {
                    status,
                    duration: null,
                    start: dateNow,
                  },
                ],
              })
            )
            io.in(agentId).emit("agent ws", {
              type: "status",
              status,
              start: dateNow,
            })

            io.of("/supervisor").emit("global", {
              type: "status",
              agentId,
              status,
              start: dateNow,
            })
          }
        }
      } else {
        redisClient.SET(
          `statusAgent:${agentId}`,
          JSON.stringify({
            status: "available",
            statusHistory: [
              {
                status: "available",
                duration: null,
                start: dateNow,
              },
            ],
          })
        )
        io.in(agentId).emit("agent ws", {
          type: "status",
          status: "available",
          start: dateNow,
        })
        io.of("/supervisor").emit("global", {
          type: "status",
          agentId,
          status: "available",
        })
      }
    })
  },
}
