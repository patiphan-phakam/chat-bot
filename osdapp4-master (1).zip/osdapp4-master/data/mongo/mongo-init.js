db.createUser({
  user: "user1",
  pwd: "psw",
  roles: ["readWrite", "dbAdmin"],
})
