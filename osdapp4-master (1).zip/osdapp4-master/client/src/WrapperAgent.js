import React, { useContext, useEffect } from "react"
import { useLocation } from "react-router-dom"
import { Link } from "react-router-dom"
import clsx from "clsx"
import { makeStyles, useTheme } from "@material-ui/core/styles"
import { withStyles } from "@material-ui/core/styles"
import Drawer from "@material-ui/core/Drawer"
import AppBar from "@material-ui/core/AppBar"
import Toolbar from "@material-ui/core/Toolbar"
import List from "@material-ui/core/List"
import CssBaseline from "@material-ui/core/CssBaseline"
import Typography from "@material-ui/core/Typography"
import Divider from "@material-ui/core/Divider"
import IconButton from "@material-ui/core/IconButton"
import MenuIcon from "@material-ui/icons/Menu"
import ChevronLeftIcon from "@material-ui/icons/ChevronLeft"
import ChevronRightIcon from "@material-ui/icons/ChevronRight"
import ListItem from "@material-ui/core/ListItem"
import ListItemIcon from "@material-ui/core/ListItemIcon"
import ListItemText from "@material-ui/core/ListItemText"
import ShowChartRoundedIcon from "@material-ui/icons/ShowChartRounded"
import ChatRoundedIcon from "@material-ui/icons/ChatRounded"
import NotificationsIcon from "@material-ui/icons/Notifications"
import AccountCircleIcon from "@material-ui/icons/AccountCircle"
import Badge from "@material-ui/core/Badge"
import Menu from "@material-ui/core/Menu"
import MenuItem from "@material-ui/core/MenuItem"
import { GlobalContext } from "./"
import NotificationBox from "./components/NotificationBox"
const drawerWidth = 240

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
  },
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
  },
  appBarShift: {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  menuButton: {
    marginRight: 36,
  },
  hide: {
    display: "none",
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
    whiteSpace: "nowrap",
  },
  drawerOpen: {
    width: drawerWidth,
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  drawerClose: {
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: "hidden",
    width: 60,
  },
  toolbar: {
    display: "flex",
    alignItems: "center",
    width: "100%",
    justifyContent: "flex-end",
    padding: theme.spacing(0, 1),
    ...theme.mixins.toolbar,
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3),
  },
}))

const StyledBadgeConnected = withStyles((theme) => ({
  badge: {
    backgroundColor: "#44b700",
    boxShadow: `0 0 0 2px ${theme.palette.background.paper}`,
    "&::after": {
      position: "absolute",
      top: 0,
      left: 0,
      width: "100%",
      height: "100%",
      borderRadius: "50%",
      animation: "$ripple 1.2s infinite ease-in-out",
      border: "1px solid #44b700",
      content: '""',
    },
  },
  "@keyframes ripple": {
    "0%": {
      transform: "scale(.8)",
      opacity: 1,
    },
    "100%": {
      transform: "scale(2.4)",
      opacity: 0,
    },
  },
}))(Badge)

const StyledBadgeNotConnected = withStyles((theme) => ({
  badge: {
    backgroundColor: "red",
    boxShadow: `0 0 0 2px ${theme.palette.background.paper}`,
    "&::after": {
      position: "absolute",
      top: 0,
      left: 0,
      width: "100%",
      height: "100%",
      borderRadius: "50%",
      animation: "$ripple 1.2s infinite ease-in-out",
      border: "1px solid red",
      content: '""',
    },
  },
}))(Badge)

function usePageViews() {
  let location = useLocation()
  React.useEffect(() => {
    console.log(location.pathname)
  }, [location])
}

export default function MiniDrawer({ children, agentconnected, state, tab }) {
  const classes = useStyles()
  const theme = useTheme()
  const [open, setOpen] = React.useState(false)
  const [anchorEl, setAnchorEl] = React.useState(null)
  const { _disconnect, agentReducer } = useContext(GlobalContext)
  const [openNotiBox, setOpenNotiBox] = React.useState(false)

  const handleDrawerOpen = () => {
    setOpen(true)
  }

  useEffect(() => {
    const { author } = state.chatFlowSupervisor[
      state.chatFlowSupervisor.length - 1
    ]

    tab !== "chat" &&
      state.chatFlowSupervisor &&
      author &&
      author !== "me" &&
      setOpenNotiBox(true)
  }, [state.chatFlowSupervisor])

  const handleDrawerClose = () => {
    setOpen(false)
  }

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget)
  }

  const handleClose = () => {
    setAnchorEl(null)
  }

  usePageViews()
  if (window.location.pathname === "/login") return <div>{children}</div>

  return (
    <div style={{ minHeight: "100vh" }}>
      <CssBaseline />
      <AppBar
        position="fixed"
        className={clsx(classes.appBar, {
          [classes.appBarShift]: open,
        })}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            onClick={handleDrawerOpen}
            edge="start"
            className={clsx(classes.menuButton, {
              [classes.hide]: open,
            })}
          >
            <MenuIcon />
          </IconButton>
          <div
            style={{
              width: "100%",
              display: "flex",
              justifyContent: "flex-end",
              alignItems: "center",
            }}
          >
            {agentReducer.email === "" ? (
              <img
                alt=""
                style={{ width: 60, height: 60 }}
                src="/images/spinner.svg"
              />
            ) : (
              <div>{agentReducer.email}</div>
            )}
            {/* <IconButton aria-label="show 11 new notifications" color="inherit">
              <Badge badgeContent={1} color="secondary">
                <NotificationsIcon />
              </Badge>
            </IconButton> */}
            <IconButton
              aria-label="show more"
              aria-haspopup="true"
              color="inherit"
              onClick={handleClick}
            >
              {agentconnected ? (
                <StyledBadgeConnected
                  overlap="circle"
                  anchorOrigin={{
                    vertical: "bottom",
                    horizontal: "right",
                  }}
                  variant="dot"
                >
                  <AccountCircleIcon />
                </StyledBadgeConnected>
              ) : (
                <StyledBadgeNotConnected
                  overlap="circle"
                  anchorOrigin={{
                    vertical: "bottom",
                    horizontal: "right",
                  }}
                  variant="dot"
                >
                  <AccountCircleIcon />
                </StyledBadgeNotConnected>
              )}
            </IconButton>

            <Menu
              anchorEl={anchorEl}
              id="simple-menu"
              keepMounted
              open={Boolean(anchorEl)}
              onClose={handleClose}
            >
              <MenuItem onClick={handleClose}>Profile</MenuItem>
              <MenuItem
                onClick={() => {
                  _disconnect()
                  handleClose()
                }}
              >
                Logout
              </MenuItem>
            </Menu>
          </div>
        </Toolbar>
      </AppBar>
      <Drawer
        variant="permanent"
        className={clsx(classes.drawer, {
          [classes.drawerOpen]: open,
          [classes.drawerClose]: !open,
        })}
        classes={{
          paper: clsx({
            [classes.drawerOpen]: open,
            [classes.drawerClose]: !open,
          }),
        }}
        open={open}
      >
        <div className={classes.toolbar}>
          <IconButton onClick={handleDrawerClose}>
            {theme.direction === "rtl" ? (
              <ChevronRightIcon />
            ) : (
              <ChevronLeftIcon />
            )}
          </IconButton>
        </div>
        <Divider />
        <List>
          <ListItem button component={Link} to="/?tab=chat">
            <ListItemIcon>
              <ChatRoundedIcon />
            </ListItemIcon>
            <ListItemText primary="chat" />
          </ListItem>
          {/* <ListItem
            button
            component={Link}
            to="/?tab=analytics&agentId=123&skill=skill1"
          >
            <ListItemIcon>
              <ShowChartRoundedIcon />
            </ListItemIcon>
            <ListItemText primary="analytics" />
          </ListItem> */}
        </List>
      </Drawer>
      <main>{children}</main>
      <NotificationBox
        openNotiBox={openNotiBox}
        setOpenNotiBox={setOpenNotiBox}
        lastMsg={state.chatFlowSupervisor[state.chatFlowSupervisor.length - 1]}
      />
    </div>
  )
}
