import React, { Suspense, lazy } from "react"
import { Switch, Route } from "react-router-dom"
import Empty from "./components/Empty"
import { Helmet } from "react-helmet"
import Lot from "./components/Lot"

const MainContainer = lazy(() => import("./containers/MainContainer"))
const LoginContainer = lazy(() => import("./containers/LoginContainer"))
const SupervisorContainer = lazy(() =>
  import("./containers/SupervisorContainer")
)

const SupervisorAgentContainer = lazy(() =>
  import("./containers/SupervisorAgentContainer")
)

const LoginSupervisorContainer = lazy(() =>
  import("./containers/LoginSupervisorContainer")
)

const AdminContainer = lazy(() => import("./containers/admin"))

const LoginAdminContainer = lazy(() =>
  import("./containers/admin/LoginAdminContainer")
)

const ReportSkillsContainer = lazy(() =>
  import("./containers/ReportSkillsContainer")
)

const ReportAgentsContainer = lazy(() =>
  import("./containers/ReportAgentsContainer")
)

const Test = lazy(() => import("./containers/Test"))

const Router = () => (
  <>
    <Helmet>
      <title>OSD - omni</title>
    </Helmet>
    <Suspense
      fallback={
        <div
          style={{
            width: "100vw",
            height: "100vh",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Lot height={200} width={200} animationData="waiting" />
        </div>
      }
    >
      <Switch>
        <Route exact path="/" component={MainContainer} />
        <Route exact path="/login" component={LoginContainer} />
        <Route exact path="/supervisor" component={SupervisorContainer} />
        <Route
          exact
          path="/supervisor/login"
          component={LoginSupervisorContainer}
        />
        <Route
          exact
          path="/supervisor/skills"
          component={ReportSkillsContainer}
        />
        <Route
          exact
          path="/supervisor/agents"
          component={ReportAgentsContainer}
        />
        <Route
          exact
          path="/supervisor/:agentId"
          component={SupervisorAgentContainer}
        />

        <Route exact path="/admin" component={AdminContainer} />
        <Route exact path="/admin/login" component={LoginAdminContainer} />
        <Route exact path="/test" component={Test} />

        <Route component={Empty} />
      </Switch>
    </Suspense>
  </>
)

export default Router
