import React, { useReducer, createContext } from "react"
import ReactDOM from "react-dom"
import "./index.css"
import { BrowserRouter } from "react-router-dom"
import Router from "./Router"
import { createMuiTheme, ThemeProvider } from "@material-ui/core/styles"
import { MuiPickersUtilsProvider } from "@material-ui/pickers"
import DateFnsUtils from "@date-io/date-fns"
import { FRONT_END_URL, BACK_END_URL } from "./config"

const initialStateAgent = {
  _id: "",
  skills: [],
  breaks: [],
  mytodos: [],
  myComponents: [],
  email: "",
  password: "",
  customers: [
    // {
    //   id: "2807938259293308",
    //   channel: "facebook",
    //   chat: [
    //     {
    //       author: "customer",
    //       msg: "Hello, I need help",
    //       type: "text",
    //       date: ISODate("2020-03-20T04:07:24.000Z"),
    //     },
    //     {
    //       author: "agent",
    //       msg: "Sure, how can I help?",
    //       type: "text",
    //       date: ISODate("2020-03-20T07:27:25.202Z"),
    //     },
    //     {
    //       author: "customer",
    //       msg: "I did not get invoice",
    //       type: "text",
    //       date: ISODate("2020-03-20T07:27:25.202Z"),
    //     },
    //     {
    //       author: "agent",
    //       msg: "Ok, could you tell me the order id please? thank you.",
    //       type: "text",
    //       date: ISODate("2020-03-20T04:07:25.514Z"),
    //     },
    //   ],
    //   firstname: "Francois",
    //   lastname: "Pierre",
    //   gender: "male",
    //   date: ISODate("2020-03-20T07:27:24.202Z"),
    //   address: "hi",
    //   email: null,
    //   mobile: "4324234",
    //   notes: "hdghgfh",
    // }
  ],
}

const initialStateSupervisor = {
  _id: "",
  email: "",
  agents: [],
}

function reducerAgent(state, action) {
  const { payload } = action
  switch (action.type) {
    case "agentInfo":
      return payload

    case "addCustomerHistory":
      if (state.customers.filter((x) => x._id === payload._id).length > 0) {
        const without = state.customers.filter((x) => x._id !== payload._id)
        return {
          ...state,
          customers: [payload, ...without],
        }
      }
      return {
        ...state,
        customers: [payload, ...state.customers],
      }

    default:
      throw new Error()
  }
}

function reducerSupervisor(state, action) {
  const { payload } = action
  switch (action.type) {
    case "supervisorInfo":
      return payload
    default:
      throw new Error()
  }
}

const GlobalReducer = () => {
  const [stateAgent, dispatchAgent] = useReducer(
    reducerAgent,
    initialStateAgent
  )
  const [stateSupervisor, dispatchSupervisor] = useReducer(
    reducerSupervisor,
    initialStateSupervisor
  )

  const _addCustomerHistory = (payload) => {
    return dispatchAgent({
      type: "addCustomerHistory",
      payload,
    })
  }

  const _agentAction = (payload) => {
    return dispatchAgent({
      type: "agentInfo",
      payload,
    })
  }

  const _supervisorAction = (payload) => {
    return dispatchSupervisor({
      type: "supervisorInfo",
      payload,
    })
  }

  const _disconnect = () => {
    localStorage.removeItem("tokenOmni")
    window.location.replace(`${FRONT_END_URL}/login`)
  }

  const _disconnectSupervisor = () => {
    localStorage.removeItem("tokenSupervisor")
    window.location.replace(`${FRONT_END_URL}/supervisor/login`)
  }

  const theme = createMuiTheme({
    palette: {
      primary: {
        main: "#1976d2",
      },
      secondary: {
        main: "#e91e63",
      },
    },
    status: {
      danger: "orange",
    },
    typography: {
      color: "#424242",
    },
    overrides: {
      MuiTypography: {
        color: "#424242",
      },
      MuiPaper: {
        root: {
          color: "#424242",
        },
      },
    },
  })

  const contextValues = {
    agentReducer: stateAgent,
    _addCustomerHistory,
    _agentAction,
    _disconnect,
    supervisorReducer: stateSupervisor,
    _supervisorAction,
    _disconnectSupervisor,
  }

  return (
    <ThemeProvider theme={theme}>
      <GlobalContext.Provider value={contextValues}>
        <MuiPickersUtilsProvider utils={DateFnsUtils}>
          <Router />
        </MuiPickersUtilsProvider>
      </GlobalContext.Provider>
    </ThemeProvider>
  )
}

export const GlobalContext = createContext({})

ReactDOM.render(
  <BrowserRouter>
    <GlobalReducer />
  </BrowserRouter>,
  document.getElementById("root")
)
