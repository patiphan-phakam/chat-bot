import React, { useState, useContext } from "react"
import axios from "axios"
import Login from "../components/Login"
import { Redirect } from "react-router-dom"
import { GlobalContext } from "../"

import { FRONT_END_URL, BACK_END_URL } from "../config"

const LoginContainer = () => {
  const { _supervisorAction } = useContext(GlobalContext)
  const [login, setlogin] = useState({
    email: "supervisor1@gmail.com",
    password: "123",
  })
  const [errorlogin, seterrorlogin] = useState({ email: "", password: "" })
  const [redirect, setredirect] = useState(null)
  const [loading, setLoading] = useState(false)

  const _input = (key, value) => setlogin({ ...login, [key]: value })

  const _login = (e) => {
    setLoading(true)
    e.preventDefault()
    axios
      .post(`${BACK_END_URL}/auth/loginsupervisor`, {
        email: login.email,
        password: login.password,
      })
      .then(({ data }) => {
        localStorage.setItem("tokenSupervisor", data.token)
        _supervisorAction(data.supervisor)
        seterrorlogin({ email: "", password: "" })
        setredirect(true)
        setLoading("success")
      })
      .catch((e) => {
        const { type, message } = e.response.data
        seterrorlogin({ [type]: message })
        setLoading("error")
      })
  }

  if (redirect) {
    window.location.replace(`${FRONT_END_URL}/supervisor/?tab=dashboard`)
  }
  return (
    <Login
      loading={loading}
      _login={_login}
      _input={_input}
      errorlogin={errorlogin}
    />
  )
}

export default LoginContainer
