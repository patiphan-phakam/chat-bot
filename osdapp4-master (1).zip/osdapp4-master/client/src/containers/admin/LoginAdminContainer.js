import React, { useState } from "react"
import axios from "axios"
import Login from "../../components/Login"

import { FRONT_END_URL, BACK_END_URL } from "../../config"

export default () => {
    const [login, setlogin] = useState({
        email: "supervisor1@gmail.com",
        password: "123",
    })
    const [errorlogin, seterrorlogin] = useState({ email: "", password: "" })
    const [redirect, setredirect] = useState(null)
    const [loading, setLoading] = useState(false)

    const _input = (key, value) => setlogin({...login, [key]: value })

    const _login = (e) => {
        setLoading(true)
        e.preventDefault()
        axios
            .post(`${BACK_END_URL}/auth/loginadmin`, {
                email: login.email,
                password: login.password,
            })
            .then(({ data }) => {
                console.log("form api login -------------", data)
                localStorage.setItem("tokenAdmin", data.token)
                seterrorlogin({ email: "", password: "" })
                setredirect(true)
                setLoading("success")
            })
            .catch((e) => {
                console.log(e.response.data)
                const { type, message } = e.response.data
                seterrorlogin({
                    [type]: message })
                setLoading("error")
            })
    }

    if (redirect) {
        window.location.replace(`${FRONT_END_URL}/admin/?tab=agents`)
    }
    return ( <
        Login loading = { loading }
        _login = { _login }
        _input = { _input }
        errorlogin = { errorlogin }
        />
    )
}