import React, { useState, useEffect, useReducer } from "react"
import axios from "axios"
import queryString from "query-string"
import { Redirect } from "react-router-dom"
import WrapperAdmin from "../../WrapperAdmin"
import SkillTab from "../../components/Admin/SkillTab"
import { BACK_END_URL } from "../../config"

const initialState = {
  settings: {
    skills: [],
  },
  admin: {
    _id: "",
    email: "",
  },
  agents: [],
}

function reducer(state, action) {
  const { payload, type } = action
  switch (type) {
    case "readAdmin":
      return {
        ...state,
        admin: {
          ...state.admin,
          email: payload.admin.email,
          _id: payload.admin._id,
        },
      }

    case "readSettings":
      return {
        ...state,
        settings: {
          ...state.settings,
          skills: payload.skills,
        },
      }

    case "readAgents":
      return {
        ...state,
        agents: payload,
      }

    case "checkAgentBox": {
      if (payload) {
        const without = state.agents.filter((x) => x._id !== payload.item._id)

        return {
          ...state,
          agents: [...without, { ...payload.item, checked: payload.checked }],
        }
      } else {
        return state
      }
    }

    case "resetAgentBox": {
      return {
        ...state,
        agents: state.agents.map((x) => ({ ...x, ["checked"]: false })),
      }
    }

    case "assignSkillAgent": {
      if (payload.bool) {
        return {
          ...state,
          agents: state.agents.map((x) => {
            if (x.checked) {
              return {
                ...x,
                skills: [...new Set([...x.skills, payload.selectedSkill])],
              }
            } else {
              return x
            }
          }),
        }
      } else {
        return {
          ...state,
          agents: state.agents.map((x) => {
            if (x.checked) {
              return {
                ...x,
                skills: x.skills.filter((y) => y !== payload.selectedSkill),
              }
            } else {
              return x
            }
          }),
        }
      }
    }

    default:
      throw new Error()
  }
}

export default () => {
  const [adminReducer, dispatch] = useReducer(reducer, initialState)
  const [selectedSkill, setSelectedSkill] = useState("skill1")
  const [trsfrIsLocked, setTrsfrIsLocked] = useState(false)
  const [isAddSkill, setIsAddSkill] = useState(false)

  const _trsfrIsLocked = () => setTrsfrIsLocked(!trsfrIsLocked)
  const _selectedSkill = (skill) => setSelectedSkill(skill)

  const _resetAgentBox = () => {
    dispatch({
      type: "resetAgentBox",
    })
  }

  const _confirmSkill = () => {
    // agents: ["5df19bbda116c95b5b8c142e", "5df19bd3a116c95b5b8c169c"]
    const agents = adminReducer.agents
      .filter(({ checked }) => checked)
      .map(({ _id }) => _id)
    console.log(
      "agents",
      adminReducer.agents.filter(({ checked }) => !checked)
    )
    if (isAddSkill) {
      axios
        .put(`${BACK_END_URL}/api/agents/skills/add`, {
          agents,
          skill: selectedSkill,
        })
        .then(({ data }) => {
          _trsfrIsLocked()
          _resetAgentBox()
          console.log(data)
        })
        .catch((err) => console.log(err))
    } else {
      axios
        .put(`${BACK_END_URL}/api/agents/skills/del`, {
          agents,
          skill: selectedSkill,
        })
        .then(({ data }) => {
          _trsfrIsLocked()
          _resetAgentBox()
          console.log(data)
        })
        .catch((err) => console.log(err))
    }
  }

  const _checkAgentBox = (checked, item) => {
    console.log("payloaddddd", checked, item)
    dispatch({
      type: "checkAgentBox",
      payload: { checked, item },
    })
  }

  const _assignSkillAgent = (bool) => {
    dispatch({
      type: "assignSkillAgent",
      payload: { bool, selectedSkill },
    })
    setIsAddSkill(bool)
    _trsfrIsLocked()
  }

  const _readSettings = () => {
    axios
      .get(`${BACK_END_URL}/api/settings/`)
      .then(({ data }) => {
        dispatch({
          type: "readSettings",
          payload: data,
        })
      })
      .catch((err) => console.log(err))
  }

  const _readAgents = () => {
    axios
      .get(`${BACK_END_URL}/api/agents/`)
      .then(({ data }) => {
        dispatch({
          type: "readAgents",
          payload: data.map((x) => ({ ...x, checked: false })),
        })
      })
      .catch((err) => console.log(err))
  }

  const { tab } = queryString.parse(window.location.search)
  if (tab === "agents")
    return (
      <WrapperAdmin adminReducer={adminReducer}>
        <SkillTab
          selectedSkill={selectedSkill}
          _selectedSkill={_selectedSkill}
          _readSettings={_readSettings}
          _readAgents={_readAgents}
          adminReducer={adminReducer}
          _checkAgentBox={_checkAgentBox}
          _resetAgentBox={_resetAgentBox}
          _assignSkillAgent={_assignSkillAgent}
          trsfrIsLocked={trsfrIsLocked}
          _trsfrIsLocked={_trsfrIsLocked}
          _confirmSkill={_confirmSkill}
        />
      </WrapperAdmin>
    )

  //   if (tab === "stats")
  //     return (
  //       <WrapperAdmin>
  //         <SupervisorTabStats />
  //       </WrapperAdmin>
  //     )
  return <Redirect to="/admin/?tab=agents" />
}
