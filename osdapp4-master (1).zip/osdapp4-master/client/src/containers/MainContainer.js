import React, { useEffect, useState, useReducer, useContext } from "react"
import queryString from "query-string"
import axios from "axios"
import io from "socket.io-client"
import TabChat from "../components/TabChat"
import { PAGE_TOKEN, BACK_END_URL } from "../config"
import { Redirect } from "react-router-dom"
import TabAnalytics from "../components/TabAnalytics"
import { GlobalContext } from "../"
import WrapperAgent from "../WrapperAgent"

// const socket = io('http://localhost', {
//   path: '/backend'
// });

const NamespaceGlobal = io(`https://dchat.osd.co.th/`, {
  path: "/socket/socket.io",
})
const initialState = {
  agentStatus: {
    status: "",
    since: null,
  },
  userInfo: {
    agentId: "",
    channel: "",
    skill: "",
    userId: "",
    first_name: "",
    timezone: 0,
    last_name: "",
    gender: "",
    profile_pic: "",
    notes: "",
    address: "",
    email: "",
    mobile: "",
  },
  alerts: {},
  flow: [
    // {
    //   author: "user",
    //   msg: "",
    //   type: "text",
    // },
    // {
    //   author: "me",
    //   msg: "",
    //   type: "text",
    // },
  ],
  chatFlowSupervisor: [
    {
      author: "supervisor1",
      msg: "",
      type: "text",
      date: new Date(),
    },
    {
      author: "me",
      msg: "",
      type: "text",
      date: new Date(),
    },
  ],
}

function reducer(state, action) {
  const { payload, type } = action
  switch (type) {
    case "resetFlow":
      return { ...state, flow: [] }

    case "agentStatus":
      return { ...state, agentStatus: payload }

    case "userInfo":
      if (payload.flow) {
        return {
          ...state,
          userInfo: payload,
          flow: payload.flow,
        }
      } else {
        return {
          ...state,
          userInfo: payload,
        }
      }

    case "userNotes":
      return {
        ...state,
        userInfo: { ...state.userInfo, notes: payload },
      }
    case "newMessage":
      return {
        ...state,
        flow: [...state.flow, { ...payload }],
      }
    case "newMessageSupervisor":
      return {
        ...state,
        chatFlowSupervisor: [...state.chatFlowSupervisor, { ...payload }],
      }

    case "reset":
      return initialState
    // return { initialState, ...state.chatFlowSupervisor }
    // return { ...state, flow: [...state.flow, payload] };
    default:
      throw new Error()
  }
}

const MainContainer = () => {
  const [agentconnected, setagentconnected] = useState(false)
  const [state, dispatch] = useReducer(reducer, initialState)
  const { _agentAction, agentReducer, _addCustomerHistory } = useContext(
    GlobalContext
  )
  const [inputText, setinputText] = useState("")
  const [redirect, useredirect] = useState(false)

  const [deciSec, setdeciSec] = useState(0)
  const [countSec, setcountSec] = useState(0)
  const [countMin, setcountMin] = useState(0)
  const [counterMsg, setcounterMsg] = useState(null)
  const [newMsgLoading, setnewMsgLoading] = useState(false)
  const [wasOnHistory, setWasOnHistory] = useState(false)

  const _selectHistoryProfile = (payload) => {
    setWasOnHistory(true)
    dispatch({
      type: "userInfo",
      payload,
    })
  }

  useEffect(() => {
    if (wasOnHistory && state.agentStatus.status === "busy") {
      dispatch({ type: "resetFlow" })
      setWasOnHistory(false)
    }
  }, [state.agentStatus.status])

  const _newAlert = () => {
    const { agentId, skill } = state.userInfo
    axios
      .post(`${BACK_END_URL}/api/alerts`, {
        agentId,
        skill,
      })
      .then(({ data }) => {
        console.log("new alert", data)
      })
      .catch((err) => console.log(err))
  }

  const _msgToSupervisor = (msg) => {
    const { _id } = agentReducer
    const date = new Date()
    axios
      .post(`${BACK_END_URL}/api/chat/agenttosup`, {
        msg,
        supervisorGroup: "team1",
        type: "text",
        agentId: _id,
        date,
      })
      .then(({ data }) =>
        console.log(`${BACK_END_URL}/api/chat/agenttosup`, data)
      )
      .then(() =>
        dispatch({
          type: "newMessageSupervisor",
          payload: {
            msg,
            author: "me",
            type: "text",
            date,
          },
        })
      )
      .catch((e) => console.log(e))
  }

  const _submitForm = (form) => {
    const { userId, skill, agentId } = state.userInfo

    const {
      first_name,
      last_name,
      gender,
      notes,
      address,
      mobile,
      email,
    } = form

    axios
      .put(`${BACK_END_URL}/api/customers/${userId}`, {
        firstname: first_name,
        lastname: last_name,
        address,
        email,
        mobile,
        notes,
        gender,
        skill,
        chat: state.flow,
      })
      .then(({ data }) => {
        axios
          .put(`${BACK_END_URL}/api/agents/customers/${agentId}`, {
            customerId: userId,
          })
          .then((e) => {
            console.log("success", e)
          })
          .catch((e) => console.log(e))
      })
      .catch((e) => console.log("const _submitUserForm not found", e))
  }

  const _break = () => {
    axios
      .post("https://dchat.osd.co.th/backend/break", {
        agentId: agentReducer._id,
        closing: state.agentStatus.status === "busy",
      })
      .then(({ data }) =>
        dispatch({
          type: "agentStatus",
          payload: { status: "break" },
        })
      )
      .catch((e) => console.log("_break fail", e))
  }

  const _resume = () => {
    axios.post("https://dchat.osd.co.th/backend/resume", {
      agentId: agentReducer._id,
      skills: agentReducer.skills,
    })
    const {
      userId,
      first_name,
      last_name,
      address,
      email,
      mobile,
      notes,
      gender,
    } = state.userInfo
    axios
      .put(`${BACK_END_URL}/api/customers/${userId}`, {
        firstname: first_name,
        lastname: last_name,
        address,
        email,
        mobile,
        notes,
        gender,
      })
      .then(({ data }) => {
        dispatch({
          type: "reset",
        })
      })
      .catch((e) => console.log("const _submitUserForm not found"))
  }

  const _inputText = (e) => setinputText(e.target.value)
  const _inputTextSubmit = (e) => {
    const { channel, userId } = state.userInfo
    const { _id } = agentReducer
    if (inputText.length > 0) {
      e.preventDefault()
      setnewMsgLoading(true)
      const fixedDate = new Date()
      axios
        .post(`${BACK_END_URL}/sendmessage`, {
          channel,
          PSID: userId,
          text: inputText,
          type: "text",
          agentId: _id,
          date: fixedDate,
        })
        .then(({ data }) => {
          setnewMsgLoading(false)
          dispatch({
            type: "newMessage",
            payload: {
              msg: inputText,
              author: "agent",
              type: "text",
              date: fixedDate,
            },
          })
        })
        .then((e) => console.log(e))
      setinputText("")
    }
  }

  useEffect(() => {
    const token = localStorage.getItem("tokenOmni")
    if (token) {
      axios
        .post(`${BACK_END_URL}/auth/token`, "", {
          headers: { Authorization: token },
        })
        .then(({ data }) => {
          axios
            .get(`${BACK_END_URL}/api/agents/${data.agent._id}`)
            .then((e) => {
              _agentAction(e.data)
            })
            .catch((e) => console.log(e))
        })
        .catch((e) => useredirect(true))

      NamespaceGlobal.on(`webhook msg`, ({ message, date }) => {
        console.log("webhook message :", message, date)
        return dispatch({
          type: "newMessage",
          payload: {
            msg: message,
            author: "customer",
            type: "text",
            date,
          },
        })
      })
    }
    if (!token) return useredirect(true)
  }, [localStorage.getItem("tokenOmni")])

  const _callme = () => {
    const { channel, userId } = state.userInfo
    axios
      .post(`${BACK_END_URL}/sendmessage`, {
        channel,
        PSID: userId,
        text: inputText,
        type: "call",
      })
      .then(({ data }) => console.log(data))
      .then((e) => console.log(e))
  }

  const _txt = () => {
    const { channel, userId } = state.userInfo
    const { _id } = agentReducer
    axios
      .post(`${BACK_END_URL}/sendmessage`, {
        channel,
        PSID: userId,
        text: "text from component1",
        type: "text",
        agentId: _id,
        date: new Date(),
      })
      .then(({ data }) => console.log(data))
      .then(() =>
        dispatch({
          type: "newMessage",
          payload: {
            msg: "[component 1 - text: 'text from component1']",
            author: "agent",
            type: "text",
          },
        })
      )
      .catch((e) => console.log(e))
  }

  const _receipe = () => {
    const { channel, userId } = state.userInfo
    axios
      .post(`${BACK_END_URL}/sendmessage`, {
        channel,
        PSID: userId,
        text: inputText,
        type: "receipe",
      })
      .then(({ data }) => console.log(data))
      .then((e) => console.log(e))
  }

  const _carousel = () => {
    const { channel, userId } = state.userInfo
    axios
      .post(`${BACK_END_URL}/sendmessage`, {
        channel,
        PSID: userId,
        text: inputText,
        type: "carousel",
      })
      .then(({ data }) => console.log(data))
      .then(() =>
        dispatch({
          type: "newMessage",
          payload: {
            msg: "[component carousel1]",
            author: "agent",
            type: "text",
          },
        })
      )
      .catch((e) => console.log(e))
  }
  const _closeConversation = (wrapupType) => {
    const { channel, userId } = state.userInfo
    const { _id, skills } = agentReducer
    console.log(channel, userId, _id, skills)

    dispatch({
      type: "agentStatus",
      payload: {
        status: "wrapup",
        // since: new Date()
      },
    })

    setcounterMsg(`disconnecting from ${userId}...`)

    axios
      .put(`${BACK_END_URL}/api/customers/${userId}`, {
        chat: state.flow,
      })
      .then(({ data }) => {
        axios
          .put(`${BACK_END_URL}/api/agents/customers/${_id}`, {
            customerId: userId,
          })
          .then((e) => {
            console.log("okkk", e)
          })
          .catch((e) => console.log(e))
      })
      .catch((e) => console.log("const _submitUserForm not found", e))

    axios
      .post(`${BACK_END_URL}/sendmessage`, {
        channel,
        PSID: userId,
        text: "thank you, it is finish please rate me.",
        type: "close",
        agentId: _id,
      })
      .then(() =>
        axios.post(`${BACK_END_URL}/closechat`, {
          userId,
          agentId: _id,
          agentSkills: skills,
          skill: state.userInfo.skill,
          wrapupType,
          channel: state.userInfo.channel,
        })
      )
      .then(() => {
        _addCustomerHistory({
          _id: state.userInfo.userId,
          channel: state.userInfo.channel,
          chat: state.flow,
          skill: state.userInfo.skill,
          firstname: state.userInfo.first_name,
          lastname: state.userInfo.last_name,
          gender: state.userInfo.gender,
          address: state.userInfo.address,
          email: state.userInfo.email,
          mobile: state.userInfo.mobile,
          notes: state.userInfo.notes,
          date: new Date(),
        })
      })

      .then((e) => {
        setdeciSec(0)
        setcountSec(0)
        setcountMin(0)
        setcounterMsg(null)
      })
      .catch((e) => console.log("error wrap: ", e))
  }

  useEffect(() => {
    NamespaceGlobal.on(`msg supervisor -> agent`, (payload) => {
      dispatch({
        type: "newMessageSupervisor",
        payload: {
          msg: payload.msg,
          agentId: payload.agentId,
          author: "supervisor",
          date: payload.date,
        },
      })
    })

    //TODO ON MATCH
    NamespaceGlobal.on(`match user/agent`, (payload) => {
      console.log("----- match ---", payload)
      if (payload.channel === "facebook") {
        axios
          .get(
            `https://graph.facebook.com/${payload.userId}?fields=profile_pic,last_name,gender,first_name,id,timezone,name&access_token=${PAGE_TOKEN}`
          )
          .then(({ data }) => {
            dispatch({ type: "userInfo", payload: { ...payload, ...data } })
            dispatch({
              type: "agentStatus",
              payload: {
                status: "busy",
                // since: new Date()
              },
            })
            axios
              .get(`${BACK_END_URL}/api/customers/${payload.userId}`)
              .then((resp) => {
                if (resp.data) {
                  dispatch({
                    type: "userInfo",
                    payload: {
                      ...payload,
                      ...resp.data,
                      first_name: resp.data.firstname,
                      last_name: resp.data.lastname,
                    },
                  })
                }
                if (!resp.data) {
                  axios
                    .post(`${BACK_END_URL}/api/customers`, {
                      agentId: payload.agentId,
                      _id: payload.userId,
                      channel: payload.channel,
                      firstname: data.first_name,
                      lastname: data.last_name,
                      gender: data.gender,
                    })
                    .then(({ data }) => console.log("save user", data))
                    .catch((e) =>
                      console.log(
                        "cannot created `${BACK_END_URL}/api/customers` ",
                        e
                      )
                    )
                }
              })
              .catch((e) => {
                console.log(
                  "`${BACK_END_URL}/api/customers/${payload.userId}` err",
                  e
                )
              })
            NamespaceGlobal.emit("storeUserId", {
              userId: payload.userId,
            })
          })
          .catch((e) => console.log("facebook err --- ", e))
      } else {
        dispatch({
          type: "userInfo",
          payload: { ...payload, first_name: "noname", last_name: "noname" },
        })
        dispatch({
          type: "agentStatus",
          payload: {
            status: "busy",
            // since: new Date()
          },
        })

        axios
          .get(`${BACK_END_URL}/api/customers/${payload.userId}`)
          .then(({ data }) => {
            if (data) {
              dispatch({
                type: "userInfo",
                payload: {
                  ...payload,
                  ...data,
                  first_name: data.firstname,
                  last_name: data.lastname,
                },
              })
            } else {
              axios
                .post(`${BACK_END_URL}/api/customers`, {
                  _id: payload.userId,
                  agentId: payload.agentId,
                  userId: payload.userId,
                  channel: payload.channel,
                  firstname: "no name",
                  lastname: "no name",
                })
                .catch((e) =>
                  console.log("cannot created `${BACK_END_URL}/api/customers` ")
                )
            }
          })
          .catch((e) => {
            console.log("`${BACK_END_URL}/api/customers/${payload.userId}`", e)
          })
        NamespaceGlobal.emit("storeUserId", {
          userId: payload.userId,
        })
      }
    })
  }, [])

  useEffect(() => {
    const { _id, skills } = agentReducer
    if (_id !== "") {
      NamespaceGlobal.emit("storeagentId", {
        agentId: _id,
        skills,
      })
      NamespaceGlobal.emit(`agent join room`, { agentId: _id, skills })
      NamespaceGlobal.on(`roomjoined`, (agentId) => {
        setagentconnected(true)

        axios
          .get(`https://dchat.osd.co.th/backend/api/agents/status/${agentId}`)
          .then(({ data }) => {
            dispatch({
              type: "agentStatus",
              payload: {
                status: data.status,
              },
            })
          })
      })

      axios.get(`${BACK_END_URL}/currentmsg/${_id}`).then(({ data }) => {
        data.map((x) => {
          const parsed = JSON.parse(x)
          dispatch({
            type: "newMessage",
            payload: {
              msg: parsed.message,
              author: parsed.author === "customer" ? "customer" : "agent",
              type: "text",
              date: parsed.date,
            },
          })
        })
      })
    }
  }, [agentReducer])

  const { tab } = queryString.parse(window.location.search)

  if (redirect) return <Redirect to="/login" />
  if (tab === "chat")
    return (
      <WrapperAgent agentconnected={agentconnected} state={state} tab={tab}>
        <TabChat
          _selectHistoryProfile={_selectHistoryProfile}
          _msgToSupervisor={_msgToSupervisor}
          state={state}
          agentReducer={agentReducer}
          agentconnected={agentconnected}
          inputText={inputText}
          _inputText={_inputText}
          _inputTextSubmit={_inputTextSubmit}
          _callme={_callme}
          _receipe={_receipe}
          _carousel={_carousel}
          _closeConversation={_closeConversation}
          _txt={_txt}
          deciSec={deciSec}
          countSec={countSec}
          countMin={countMin}
          counterMsg={counterMsg}
          newMsgLoading={newMsgLoading}
          _break={_break}
          _resume={_resume}
          _submitForm={_submitForm}
          _newAlert={_newAlert}
        />
      </WrapperAgent>
    )

  if (tab === "analytics")
    return (
      <WrapperAgent state={state} agentconnected={agentconnected} tab={tab}>
        <TabAnalytics />
      </WrapperAgent>
    )

  return <Redirect to="/?tab=chat" />
}

export default MainContainer

// NamespaceGlobal.on(`match user/agent`, (payload) => {
//   if (payload.channel === "facebook") {
//     axios
//       .get(
//         `https://graph.facebook.com/${payload.userId}?fields=profile_pic,last_name,gender,first_name,id,timezone,name&access_token=${PAGE_TOKEN}`
//       )
//       .then(({ data }) => {
//         dispatch({ type: "userInfo", payload: { ...payload, ...data } })
//         dispatch({
//           type: "agentStatus",
//           payload: {
//             status: "busy",
//             // since: new Date()
//           },
//         })
//         axios
//           .get(`${BACK_END_URL}/api/customers/${payload.userId}`)
//           .then((resp) => {
//             if (resp.data) {
//               dispatch({
//                 type: "userInfo",
//                 payload: {
//                   ...payload,
//                   ...resp.data,
//                   first_name: resp.data.firstname,
//                   last_name: resp.data.lastname,
//                 },
//               })
//             }
//             if (!resp.data) {
//               console.log("not get user: ", payload)
//               axios
//                 .post(`${BACK_END_URL}/api/customers`, {
//                   agentId: payload.agentId,
//                   _id: payload.userId,
//                   channel: payload.channel,
//                   firstname: data.first_name,
//                   lastname: data.last_name,
//                   gender: data.gender,
//                 })
//                 .then(({ data }) => console.log("save user", data))
//                 .catch((e) =>
//                   console.log(
//                     "cannot created `${BACK_END_URL}/api/customers` ",
//                     e
//                   )
//                 )
//             }
//           })
//           .catch((e) => {
//             console.log(
//               "`${BACK_END_URL}/api/customers/${payload.userId}` err",
//               e
//             )
//           })
//         NamespaceGlobal.emit("storeUserId", {
//           userId: payload.userId,
//         })
//       })
//       .catch((e) => console.log("facebook err --- ", e))
//   } else {
//     dispatch({ type: "userInfo", payload })
//     dispatch({
//       type: "agentStatus",
//       payload: {
//         status: "busy",
//         // since: new Date()
//       },
//     })

//     axios
//       .get(`${BACK_END_URL}/api/customers/${payload.userId}`)
//       .then(({ data }) => {
//         if (data) {
//           dispatch({
//             type: "userInfo",
//             payload: data,
//           })
//         } else {
//           axios
//             .post(`${BACK_END_URL}/api/customers`, {
//               _id: payload.userId,
//               agentId: payload.agentId,
//               userId: payload.userId,
//               channel: payload.channel,
//             })
//             .catch((e) =>
//               console.log("cannot created `${BACK_END_URL}/api/customers` ")
//             )
//         }
//       })
//       .catch((e) => {
//         console.log("`${BACK_END_URL}/api/customers/${payload.userId}`", e)
//       })
//     NamespaceGlobal.emit("storeUserId", {
//       userId: payload.userId,
//     })
//   }
// })
