import React, { useEffect, useReducer, useState } from "react"
import queryString from "query-string"
import axios from "axios"
import WrapperSupervisor from "../WrapperSupervisor"
import { BACK_END_URL } from "../config"
import ReportAgents from "../components/ReportAgents"
import dateFormat from "dateformat"
import { PROD } from "../config"

const token = localStorage.getItem("tokenSupervisor")

const initSupervisor = {
  supervisor: {
    _id: "",
    email: "",
    skills: [],
  },
  listAgents: [
    {
      // _id: "5ddc93d61c9d440000e2c6ba",
      // email: "1agentskill1skill2@gmail.com",
      // skills: ["skill1", "skill2"],
      // name: "james",
    },
  ],
  oneAgentByDate: null,
  chatReport: [
    // "_id" : ObjectId("5eec3555a6840dd43974b864"),
    // "date" : ISODate("2020-06-09T02:30:20.202Z"),
    // "skill" : "skill1",
    // "source" : "messenger",
    // "agentid" : "5ddc93d61c9d440000e2c6ba",
    // "customerid" : "3807938259293308",
    // "customername" : "jean",
    // "chatid" : "324234234",
    // "status" : "wrapup1",
    // "duration" : 23423423
  ],
}
function reducerSupervisor(state, action) {
  const { payload, type } = action
  switch (type) {
    case "write_chat_report":
      return {
        ...state,
        chatReport: payload,
      }
    case "stats_oneagents":
      return {
        ...state,
        oneAgentByDate: payload,
      }
    case "stats_agents":
      return {
        ...state,
        listAgents: payload,
      }
    case "read_list_agent":
      return {
        ...state,
        listAgents: payload,
      }
    case "read_supervisor":
      return {
        ...state,
        ...payload,
      }

    default:
      throw new Error()
  }
}

export default () => {
  const [reducer, dispatch] = useReducer(reducerSupervisor, initSupervisor)
  const [datesInput, selectDatesInput] = useState({
    startDate: dateFormat(new Date(), "2020-06-04"),
    endDate: dateFormat(new Date(), "yyyy-mm-dd"),
  })
  const [selectedAgent, setSelectedAgent] = useState(null)

  const _selectAgent = (_id) =>
    axios
      .get(
        `${BACK_END_URL}/api/stats/reportoneagent/${selectedAgent}/2020-06-04/2020-06-05`
      )
      .then(({ data }) => {
        dispatch({
          type: "read_list_agent",
          payload: data,
        })
      })
      .catch((e) => console.log(e))

  const _selectDates = (key, value) => {
    console.log(key, dateFormat(value, "yyyy-mm-dd"))
    selectDatesInput({ ...datesInput, [key]: dateFormat(value, "yyyy-mm-dd") })
  }

  const _agentList = () => {
    axios
      .get(`${BACK_END_URL}/api/agents`)
      .then(({ data }) => {
        dispatch({
          type: "read_list_agent",
          payload: data,
        })
      })
      .catch((e) => console.log(e))
  }

  useEffect(() => {
    _agentList()
  }, [])

  const _searchChatReport = (query) => {
    axios
      .get(
        `${BACK_END_URL}/api/stats/reportchat/${datesInput.startDate}/${datesInput.endDate}/${query}`
      )
      .then(({ data }) => {
        dispatch({
          type: "write_chat_report",
          payload: data,
        })
      })
  }

  const _searchOneAgent = async (_id) => {
    try {
      const agentInfo = await axios.get(
        `${BACK_END_URL}/api/stats/reportoneagent/${_id}/${datesInput.startDate}/${datesInput.endDate}`
      )
      dispatch({
        type: "stats_oneagents",
        payload: agentInfo.data,
      })
    } catch (e) {
      console.log("_searchOneAgent", e)
    }
  }

  const _search = async () => {
    try {
      const agentList = await axios.get(`${BACK_END_URL}/api/agents`)
      const agentStats = await axios.get(
        `${BACK_END_URL}/api/stats/reportagent/${datesInput.startDate}/${datesInput.endDate}`
      )
      const totalAgentStats = agentStats.data
        .reduce((accumulator, currentValue) => {
          return [...accumulator, currentValue.agents]
        }, [])
        .reduce((accumulator, currentValue) => {
          if (!accumulator) {
            return currentValue
          }
          const obji = {}
          Object.entries(currentValue).map((x) => {
            obji[x[0]] = {
              line: {
                answered: x[1].line.answered + accumulator[x[0]].line.answered,
                chatTime: x[1].line.chatTime + accumulator[x[0]].line.chatTime,
                notAnswered:
                  x[1].line.notAnswered + accumulator[x[0]].line.notAnswered,
              },
              messenger: {
                answered:
                  x[1].messenger.answered +
                  accumulator[x[0]].messenger.answered,
                chatTime:
                  x[1].messenger.chatTime +
                  accumulator[x[0]].messenger.chatTime,
                notAnswered:
                  x[1].messenger.notAnswered +
                  accumulator[x[0]].messenger.notAnswered,
              },
            }
          })
          return obji
        }, false)
      dispatch({
        type: "stats_agents",
        payload: agentList.data.map((x) => {
          return {
            ...x,
            stats_total: totalAgentStats[x._id],
          }
        }),
      })
    } catch (error) {
      console.log("error", error)
    }

    axios
      .get(
        `${BACK_END_URL}/api/stats/reportagent/${datesInput.startDate}/${datesInput.endDate}`
      )
      .then(({ data }) => {
        // console.log(" --=-=-=4234data    ", data)
      })
      .catch((e) => console.log(e))
  }

  const { tab } = queryString.parse(window.location.search)

  if (!token) return window.location.replace("/")

  useEffect(() => {
    if (token) {
      axios
        .post(`${BACK_END_URL}/auth/token`, "", {
          headers: { Authorization: token },
        })
        .then(({ data }) => {
          dispatch({
            type: "read_supervisor",
            payload: data.supervisor,
          })

          _search()
        })
        .catch((e) => window.location.replace("/"))
    }
  }, [token])

  return (
    <WrapperSupervisor supervisorReducer={reducer}>
      <button
        onClick={() => {
          axios
            .get(`${BACK_END_URL}/api/agents`)
            .then(({ data }) => {
              console.log("jambonking", data)
            })
            .catch((e) => console.log(e))
        }}
      >
        YEYEYYEY
      </button>
      <ReportAgents
        reducer={reducer}
        _selectDates={_selectDates}
        _search={_search}
        datesInput={datesInput}
        _searchOneAgent={_searchOneAgent}
        _searchChatReport={_searchChatReport}
      />
    </WrapperSupervisor>
  )
}
