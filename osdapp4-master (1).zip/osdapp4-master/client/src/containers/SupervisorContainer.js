import React, { useState, useEffect, useReducer } from "react"
import axios from "axios"
import io from "socket.io-client"
import queryString from "query-string"
import { Redirect } from "react-router-dom"
import Supervisor from "../components/Supervisor"
import SupervisorTabStats from "../components/SupervisorTabStats"
import WrapperSupervisor from "../WrapperSupervisor"

// const ioAgentState = io(`${process.env.BACK_END_URL}/agentsstate`)
// const NamespaceGlobal = io(`${process.env.BACK_END_URL}`)

import { FRONT_END_URL, BACK_END_URL } from "../config"

// const NamespaceSupervisor = io(`${process.env.FRONT_END_URL}/supervisor`, {
//   path: "/socket/socket.io",
// })

const NamespaceSupervisor = io(`https://dchat.osd.co.th/supervisor`, {
  path: "/socket/socket.io",
})

const initialState = {
  supervisor: {
    _id: "",
    email: "",
    skills: [],
  },
  agents: [],
  alerts: {},
  queueAgents: {
    // skill1: ['agentId']
  },
  queueCustomers: {
    // skill1: ['']
  },
  timeoutCustomers: {
    // skill1: 0
  },
  totalDuration: {
    // skill1: 0
  },
  totalSessions: {
    // skill1: 0
  },
  stats: [
    // day,
    // ratings,
    // performance,
    // sessions
  ],
}

function reducer(state, action) {
  const { payload, type } = action
  switch (type) {
    case "totalSessions":
      return {
        ...state,
        totalSessions: { ...payload },
      }

    case "totalDuration":
      return {
        ...state,
        totalDuration: { ...payload },
      }

    case "customers_timeout":
      return {
        ...state,
        timeoutCustomers: { ...payload },
      }

    case "days_stats":
      return { ...state, stats: payload }

    case "ws_status":
      return {
        ...state,
        agents: state.agents.map((x) => {
          if (x._id === payload.agentId) {
            return {
              ...x,
              status: payload.status,
              statusHistory: x.statusHistory
                ? [
                    ...x.statusHistory.slice(0, -1),
                    {
                      ...x.statusHistory[x.statusHistory.length - 1],
                      duration:
                        new Date(payload.start).getTime() -
                        new Date(
                          x.statusHistory[x.statusHistory.length - 1].start
                        ).getTime(),
                    },
                    {
                      status: payload.status,
                      duration: null,
                      start: payload.start,
                    },
                  ]
                : [
                    {
                      status: payload.status,
                      duration: null,
                      start: payload.start,
                    },
                  ],
            }
          } else {
            return x
          }
        }),
      }
    case "ws_ratingsAgent":
      return {
        ...state,
        agents: state.agents.map((x) => {
          if (x._id === payload._id) {
            return {
              ...x,
              ratings: x.ratings
                ? {
                    ...x.ratings,
                    [Object.entries(payload.data)[0][0]]: x.ratings[
                      Object.entries(payload.data)[0][0]
                    ]
                      ? {
                          ...x.ratings[Object.entries(payload.data)[0][0]],
                          ...Object.entries(payload.data)[0][1],
                        }
                      : Object.entries(payload.data)[0][1],
                  }
                : payload.data,
            }
          } else {
            return x
          }
        }),
      }
    case "ratingsAgent":
      return {
        ...state,
        agents: state.agents.map((x) => {
          if (x._id === payload._id) {
            return {
              ...x,
              ratings: payload.data,
            }
          } else {
            return x
          }
        }),
      }
    case "statusAgent":
      return {
        ...state,
        agents: state.agents.map((x) => {
          if (x._id === payload._id) {
            return {
              ...x,
              status: payload.status,
              statusHistory: payload.statusHistory,
            }
          } else {
            return x
          }
        }),
      }

    case "readSupervisor":
      return {
        ...state,
        supervisor: payload,
      }

    case "readAgents":
      return {
        ...state,
        agents: payload,
      }

    case "alerts_read":
      return {
        ...state,
        alerts: payload,
      }

    case "ws_new_alert":
      return {
        ...state,
        alerts: { ...state.alerts, ...payload },
      }

    case "readAgentsQueues":
      return {
        ...state,
        queueAgents: { ...state.queueAgents, [payload.skill]: payload.data },
      }

    case "readCustomersQueues":
      return {
        ...state,
        queueCustomers: {
          ...state.queueCustomers,
          [payload.skill]: payload.data,
        },
      }

    case "ws_queue_agent_join":
      return {
        ...state,
        queueAgents: {
          ...state.queueAgents,
          [payload.skill]: state.queueAgents[payload.skill]
            ? [...state.queueAgents[payload.skill], payload.agentId]
            : [payload.agentId],
        },
      }

    case "ws_queue_agent_leave":
      if (state.queueAgents[payload.skill]) {
        return {
          ...state,
          queueAgents: {
            ...state.queueAgents,
            [payload.skill]: state.queueAgents[payload.skill].filter(
              (x) => x !== payload.agentId
            ),
          },
        }
      } else {
        return state
      }

    case "ws_queue_customer_join":
      return {
        ...state,
        queueCustomers: {
          ...state.queueCustomers,
          [payload.skill]: state.queueCustomers[payload.skill]
            ? [
                ...state.queueCustomers[payload.skill],
                {
                  userId: payload.userId,
                  channel: payload.channel,
                },
              ]
            : [
                {
                  userId: payload.userId,
                  channel: payload.channel,
                },
              ],
        },
      }

    case "ws_queue_customer_leave":
      return {
        ...state,
        queueCustomers: {
          ...state.queueCustomers,
          [payload.skill]: state.queueCustomers[payload.skill].filter(
            (x) => x.userId !== payload.userId
          ),
        },
      }

    default:
      throw new Error()
  }
}

export default () => {
  const [redirect, useredirect] = useState(false)
  const [supervisorReducer, dispatch] = useReducer(reducer, initialState)
  const [useEffUpdate, setuseEffUpdate] = useState(false)

  useEffect(() => {
    if (supervisorReducer.agents.length > 0 && !useEffUpdate) {
      setuseEffUpdate(true)
      supervisorReducer.agents.map((x) => {
        axios
          .get(`${BACK_END_URL}/api/agents/rating/${x._id}`)
          .then(
            ({ data }) =>
              data !== "" &&
              dispatch({
                type: "ratingsAgent",
                payload: { data, _id: x._id },
              })
          )
          .catch((e) => console.log("_readAgent() error", e))
        axios
          .get(`https://dchat.osd.co.th/backend/api/agents/status/${x._id}`)
          .then(({ data }) => {
            if (data !== "") {
              dispatch({
                type: "statusAgent",
                payload: { ...data, _id: x._id },
              })
            }
          })
          .catch((e) => console.log(e))
      })
    }
  }, [supervisorReducer.agents])

  useEffect(() => {
    const { skills } = supervisorReducer.supervisor
    if (skills.length > 0) {
      skills.map((skill) =>
        NamespaceSupervisor.emit(`supervisor join room`, skill)
      )
      NamespaceSupervisor.on("global", (payload) => {
        if (payload.type === "status") {
          dispatch({
            type: "ws_status",
            payload,
          })
        }
        if (payload.type === "newalert") {
          dispatch({
            type: "ws_new_alert",
            payload: {
              [payload.alertId]: {
                date: payload.date,
                agentId: payload.agentId,
                skill: payload.skill,
                solved: payload.solved,
                stamp: payload.stamp,
              },
            },
          })
        }
        if (payload.type === "queue_agent_join") {
          payload.skills.map((skill) => {
            if (supervisorReducer.supervisor.skills.includes(skill)) {
              dispatch({
                type: "ws_queue_agent_join",
                payload: {
                  agentId: payload.agentId,
                  skill,
                },
              })
            }
          })
        }
        if (payload.type === "queue_agent_leave") {
          payload.skills.map((skill) => {
            if (supervisorReducer.supervisor.skills.includes(skill)) {
              dispatch({
                type: "ws_queue_agent_leave",
                payload: {
                  agentId: payload.agentId,
                  skill,
                },
              })
            }
          })
        }
        if (payload.type === "queue_customer_join") {
          if (
            supervisorReducer.supervisor.skills.includes(payload.data.skill)
          ) {
            dispatch({
              type: "ws_queue_customer_join",
              payload: {
                skill: payload.data.skill,
                userId: payload.data.userId,
                channel: payload.data.channel,
              },
            })
          }
        }
        if (payload.type === "queue_customer_leave") {
          if (supervisorReducer.supervisor.skills.includes(payload.skill)) {
            dispatch({
              type: "ws_queue_customer_leave",
              payload,
            })
          }
        }
        if (payload.type === "rating") {
          dispatch({
            type: "ws_ratingsAgent",
            payload: { data: payload.data, _id: payload.agentId },
          })
        }
        if (payload.type === "timeout_customer") {
          dispatch({
            type: "customers_timeout",
            payload: payload.data,
          })
        }
        if (payload.type === "total_sessions") {
          dispatch({
            type: "totalSessions",
            payload: payload.data,
          })
        }
        if (payload.type === "total_duration_waiting") {
          dispatch({
            type: "totalDuration",
            payload: payload.data,
          })
        }
        console.log("ws", payload)
      })

      skills.map((skill) => {
        axios
          .get(`https://dchat.osd.co.th/backend/queuecustomers/${skill}`)
          .then(({ data }) => {
            const result = data.map((x) => JSON.parse(x))

            dispatch({
              type: "readCustomersQueues",
              payload: {
                skill,
                data: result,
              },
            })
          })
          .catch((e) => console.log(e))
      })

      skills.map((skill) => {
        axios
          .get(`https://dchat.osd.co.th/backend/queueagents/${skill}`)
          .then(({ data }) => {
            dispatch({
              type: "readAgentsQueues",
              payload: { data, skill },
            })
          })
          .catch((e) => console.log(e))
      })
      axios
        .get(`https://dchat.osd.co.th/backend/api/stats/totalduration`)
        .then(({ data }) => {
          dispatch({
            type: "totalDuration",
            payload: data,
          })
        })
        .catch((e) => console.log(e))
      axios
        .get(`https://dchat.osd.co.th/backend/api/stats/totalsessions`)
        .then(({ data }) => {
          dispatch({
            type: "totalSessions",
            payload: data,
          })
        })
        .catch((e) => console.log(e))
    }
  }, [supervisorReducer.supervisor.skills])

  const _solvingAlert = (alertId, agentId) => {
    axios
      .post(`${BACK_END_URL}/api/alerts/solve`, {
        alertId,
      })
      .then(({ data }) => {
        window.location.replace(`${FRONT_END_URL}/supervisor/${agentId}`)
      })
      .catch((err) => console.log(err))
  }

  useEffect(() => {
    axios
      .get(`${BACK_END_URL}/api/agents/`)
      .then(({ data }) => {
        dispatch({
          type: "readAgents",
          payload: data,
        })
      })
      .catch((err) => console.log(err))

    axios
      .get(`${BACK_END_URL}/api/alerts`)
      .then(({ data }) => {
        dispatch({
          type: "alerts_read",
          payload: data,
        })
      })
      .catch((err) => console.log(err))

    axios
      .get(
        `${BACK_END_URL}/api/stats/days/${new Date(
          new Date().setDate(new Date().getDate() - 7)
        )}/${new Date()}`
      )
      .then(({ data }) => {
        dispatch({
          type: "days_stats",
          payload: data,
        })
      })
      .catch((err) => console.log(err))

    axios
      .get(`${BACK_END_URL}/api/stats/customerstimeout`)
      .then(({ data }) => {
        dispatch({
          type: "customers_timeout",
          payload: data,
        })
      })
      .catch((err) => console.log(err))
  }, [])

  useEffect(() => {
    const token = localStorage.getItem("tokenSupervisor")
    if (token) {
      axios
        .post(`${BACK_END_URL}/auth/token`, "", {
          headers: { Authorization: token },
        })
        .then(({ data }) => {
          dispatch({
            type: "readSupervisor",
            payload: data.supervisor,
          })

          // yeah
        })

        .catch((e) => useredirect(true))
    }
    if (!token) return useredirect(true)
  }, [localStorage.getItem("tokenSupervisor")])

  if (redirect) return <Redirect to="/supervisor/login" />

  const { tab } = queryString.parse(window.location.search)
  if (tab === "dashboard")
    return (
      <WrapperSupervisor supervisorReducer={supervisorReducer}>
        <Supervisor
          supervisorReducer={supervisorReducer}
          _solvingAlert={_solvingAlert}
        />
      </WrapperSupervisor>
    )

  if (tab === "stats")
    return (
      <WrapperSupervisor supervisorReducer={supervisorReducer}>
        <SupervisorTabStats />
      </WrapperSupervisor>
    )
  return <Redirect to="/supervisor/?tab=dashboard" />
}
