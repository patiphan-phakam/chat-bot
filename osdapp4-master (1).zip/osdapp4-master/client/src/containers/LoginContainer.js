import React, { useState, useContext } from "react"
import axios from "axios"
import Login from "../components/Login"
import { Redirect } from "react-router-dom"
import { GlobalContext } from "../"

import { BACK_END_URL } from "../config"

// const BACK_END_URL = 'http://localhost:5000/backend' //edit 

const LoginContainer = () => {
    const { _agentAction } = useContext(GlobalContext)
    const [login, setlogin] = useState({ email: "", password: "" })
    const [errorlogin, seterrorlogin] = useState({ email: "", password: "" })
    const [redirect, setredirect] = useState(null)
    const [loading, setLoading] = useState(false)

    const _input = (key, value) => setlogin({...login, [key]: value })

    const _login = (e) => {
        setLoading(true)
        e.preventDefault()
        axios
            .post(`${BACK_END_URL}/auth/login`, {
                email: login.email,
                password: login.password,
            })
            .then(({ data }) => {
                localStorage.setItem("tokenOmni", data.token)
                _agentAction(data.agent)
                seterrorlogin({ email: "", password: "" })
                setredirect(true)
                setLoading("success")
            })
            .catch((e) => {
                const { type, message } = e.response.data
                seterrorlogin({
                    [type]: message
                })
                setLoading("error")
            })
    }

    if (redirect) {
        window.location.replace(`/?tab=chat`)
    }
    return ( <
        Login loading = { loading }
        _login = { _login }
        _input = { _input }
        errorlogin = { errorlogin }
        />
    )
}

export default LoginContainer