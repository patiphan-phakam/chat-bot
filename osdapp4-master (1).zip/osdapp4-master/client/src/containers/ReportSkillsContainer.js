import React, { useEffect, useReducer, useState } from "react"
import queryString from "query-string"
import axios from "axios"
import WrapperSupervisor from "../WrapperSupervisor"
import { BACK_END_URL } from "../config"
import ReportSkills from "../components/ReportSkills"
import dateFormat from "dateformat"

const calcReportSkillbyDay = (x) => ({
  skill1: {
    totalAnswers: x.messenger.skill1.totalAnswers + x.line.skill1.totalAnswers,
    abandonCustomers:
      x.messenger.skill1.abandonCustomers + x.line.skill1.abandonCustomers,
    total:
      x.messenger.skill1.totalAnswers +
      x.messenger.skill1.abandonCustomers +
      x.line.skill1.totalAnswers +
      x.line.skill1.abandonCustomers,
    totalAnswers: x.messenger.skill1.totalAnswers + x.line.skill1.totalAnswers,
    waitingTime: x.messenger.skill1.waitingTime + x.line.skill1.waitingTime,
  },
  skill2: {
    totalAnswers: x.messenger.skill2.totalAnswers + x.line.skill2.totalAnswers,
    abandonCustomers:
      x.messenger.skill2.abandonCustomers + x.line.skill2.abandonCustomers,
    total:
      x.messenger.skill2.totalAnswers +
      x.messenger.skill2.abandonCustomers +
      x.line.skill2.totalAnswers +
      x.line.skill2.abandonCustomers,
    totalAnswers: x.messenger.skill2.totalAnswers + x.line.skill2.totalAnswers,
    waitingTime: x.messenger.skill2.waitingTime + x.line.skill2.waitingTime,
  },
  skill3: {
    totalAnswers: x.messenger.skill3.totalAnswers + x.line.skill3.totalAnswers,
    abandonCustomers:
      x.messenger.skill3.abandonCustomers + x.line.skill3.abandonCustomers,
    total:
      x.messenger.skill3.totalAnswers +
      x.messenger.skill3.abandonCustomers +
      x.line.skill3.totalAnswers +
      x.line.skill3.abandonCustomers,
    totalAnswers: x.messenger.skill3.totalAnswers + x.line.skill3.totalAnswers,
    waitingTime: x.messenger.skill3.waitingTime + x.line.skill3.waitingTime,
  },
  skill4: {
    totalAnswers: x.messenger.skill4.totalAnswers + x.line.skill4.totalAnswers,
    abandonCustomers:
      x.messenger.skill4.abandonCustomers + x.line.skill4.abandonCustomers,
    total:
      x.messenger.skill4.totalAnswers +
      x.messenger.skill4.abandonCustomers +
      x.line.skill4.totalAnswers +
      x.line.skill4.abandonCustomers,
    totalAnswers: x.messenger.skill4.totalAnswers + x.line.skill4.totalAnswers,
    waitingTime: x.messenger.skill4.waitingTime + x.line.skill4.waitingTime,
  },
  skill5: {
    totalAnswers: x.messenger.skill5.totalAnswers + x.line.skill5.totalAnswers,
    abandonCustomers:
      x.messenger.skill5.abandonCustomers + x.line.skill5.abandonCustomers,
    total:
      x.messenger.skill5.totalAnswers +
      x.messenger.skill5.abandonCustomers +
      x.line.skill5.totalAnswers +
      x.line.skill5.abandonCustomers,
    totalAnswers: x.messenger.skill5.totalAnswers + x.line.skill5.totalAnswers,
    waitingTime: x.messenger.skill5.waitingTime + x.line.skill5.waitingTime,
  },
})

const calcReduce = (accumulator, currentValue) => ({
  messenger: {
    skill1: {
      totalAnswers:
        accumulator.messenger.skill1.totalAnswers +
        currentValue.messenger.skill1.totalAnswers,
      abandonCustomers:
        accumulator.messenger.skill1.abandonCustomers +
        currentValue.messenger.skill1.abandonCustomers,
      total:
        accumulator.messenger.skill1.total +
        currentValue.messenger.skill1.total,
      totalAnswers:
        accumulator.messenger.skill1.totalAnswers +
        currentValue.messenger.skill1.totalAnswers,
      waitingTime:
        accumulator.messenger.skill1.waitingTime +
        currentValue.messenger.skill1.waitingTime,
    },
    skill2: {
      totalAnswers:
        accumulator.messenger.skill2.totalAnswers +
        currentValue.messenger.skill2.totalAnswers,
      abandonCustomers:
        accumulator.messenger.skill2.abandonCustomers +
        currentValue.messenger.skill2.abandonCustomers,
      total:
        accumulator.messenger.skill2.total +
        currentValue.messenger.skill2.total,
      totalAnswers:
        accumulator.messenger.skill2.totalAnswers +
        currentValue.messenger.skill2.totalAnswers,
      waitingTime:
        accumulator.messenger.skill2.waitingTime +
        currentValue.messenger.skill2.waitingTime,
    },
    skill3: {
      totalAnswers:
        accumulator.messenger.skill3.totalAnswers +
        currentValue.messenger.skill3.totalAnswers,
      abandonCustomers:
        accumulator.messenger.skill3.abandonCustomers +
        currentValue.messenger.skill3.abandonCustomers,
      total:
        accumulator.messenger.skill3.total +
        currentValue.messenger.skill3.total,
      totalAnswers:
        accumulator.messenger.skill3.totalAnswers +
        currentValue.messenger.skill3.totalAnswers,
      waitingTime:
        accumulator.messenger.skill3.waitingTime +
        currentValue.messenger.skill3.waitingTime,
    },
    skill4: {
      totalAnswers:
        accumulator.messenger.skill4.totalAnswers +
        currentValue.messenger.skill4.totalAnswers,
      abandonCustomers:
        accumulator.messenger.skill4.abandonCustomers +
        currentValue.messenger.skill4.abandonCustomers,
      total:
        accumulator.messenger.skill4.total +
        currentValue.messenger.skill4.total,
      totalAnswers:
        accumulator.messenger.skill4.totalAnswers +
        currentValue.messenger.skill4.totalAnswers,
      waitingTime:
        accumulator.messenger.skill4.waitingTime +
        currentValue.messenger.skill4.waitingTime,
    },
    skill5: {
      totalAnswers:
        accumulator.messenger.skill5.totalAnswers +
        currentValue.messenger.skill5.totalAnswers,
      abandonCustomers:
        accumulator.messenger.skill5.abandonCustomers +
        currentValue.messenger.skill5.abandonCustomers,
      total:
        accumulator.messenger.skill5.total +
        currentValue.messenger.skill5.total,
      totalAnswers:
        accumulator.messenger.skill5.totalAnswers +
        currentValue.messenger.skill5.totalAnswers,
      waitingTime:
        accumulator.messenger.skill5.waitingTime +
        currentValue.messenger.skill5.waitingTime,
    },
  },
  line: {
    skill1: {
      totalAnswers:
        accumulator.line.skill1.totalAnswers +
        currentValue.line.skill1.totalAnswers,
      abandonCustomers:
        accumulator.line.skill1.abandonCustomers +
        currentValue.line.skill1.abandonCustomers,
      total: accumulator.line.skill1.total + currentValue.line.skill1.total,
      totalAnswers:
        accumulator.line.skill1.totalAnswers +
        currentValue.line.skill1.totalAnswers,
      waitingTime:
        accumulator.line.skill1.waitingTime +
        currentValue.line.skill1.waitingTime,
    },
    skill2: {
      totalAnswers:
        accumulator.line.skill2.totalAnswers +
        currentValue.line.skill2.totalAnswers,
      abandonCustomers:
        accumulator.line.skill2.abandonCustomers +
        currentValue.line.skill2.abandonCustomers,
      total: accumulator.line.skill2.total + currentValue.line.skill2.total,
      totalAnswers:
        accumulator.line.skill2.totalAnswers +
        currentValue.line.skill2.totalAnswers,
      waitingTime:
        accumulator.line.skill2.waitingTime +
        currentValue.line.skill2.waitingTime,
    },
    skill3: {
      totalAnswers:
        accumulator.line.skill3.totalAnswers +
        currentValue.line.skill3.totalAnswers,
      abandonCustomers:
        accumulator.line.skill3.abandonCustomers +
        currentValue.line.skill3.abandonCustomers,
      total: accumulator.line.skill3.total + currentValue.line.skill3.total,
      totalAnswers:
        accumulator.line.skill3.totalAnswers +
        currentValue.line.skill3.totalAnswers,
      waitingTime:
        accumulator.line.skill3.waitingTime +
        currentValue.line.skill3.waitingTime,
    },
    skill4: {
      totalAnswers:
        accumulator.line.skill4.totalAnswers +
        currentValue.line.skill4.totalAnswers,
      abandonCustomers:
        accumulator.line.skill4.abandonCustomers +
        currentValue.line.skill4.abandonCustomers,
      total: accumulator.line.skill4.total + currentValue.line.skill4.total,
      totalAnswers:
        accumulator.line.skill4.totalAnswers +
        currentValue.line.skill4.totalAnswers,
      waitingTime:
        accumulator.line.skill4.waitingTime +
        currentValue.line.skill4.waitingTime,
    },
    skill5: {
      totalAnswers:
        accumulator.line.skill5.totalAnswers +
        currentValue.line.skill5.totalAnswers,
      abandonCustomers:
        accumulator.line.skill5.abandonCustomers +
        currentValue.line.skill5.abandonCustomers,
      total: accumulator.line.skill5.total + currentValue.line.skill5.total,
      totalAnswers:
        accumulator.line.skill5.totalAnswers +
        currentValue.line.skill5.totalAnswers,
      waitingTime:
        accumulator.line.skill5.waitingTime +
        currentValue.line.skill5.waitingTime,
    },
  },
  total: {
    skill1: {
      totalAnswers:
        accumulator.messenger.skill1.totalAnswers +
        accumulator.line.skill1.totalAnswers +
        currentValue.line.skill1.totalAnswers +
        currentValue.messenger.skill1.totalAnswers,
      abandonCustomers:
        accumulator.messenger.skill1.abandonCustomers +
        accumulator.line.skill1.abandonCustomers +
        currentValue.line.skill1.abandonCustomers +
        currentValue.messenger.skill1.abandonCustomers,
      total:
        accumulator.messenger.skill1.total +
        accumulator.line.skill1.total +
        currentValue.line.skill1.total +
        currentValue.messenger.skill1.total,
      totalAnswers:
        accumulator.messenger.skill1.totalAnswers +
        accumulator.line.skill1.totalAnswers +
        currentValue.line.skill1.totalAnswers +
        currentValue.messenger.skill1.totalAnswers,
      waitingTime:
        accumulator.messenger.skill1.waitingTime +
        accumulator.line.skill1.waitingTime +
        currentValue.line.skill1.waitingTime +
        currentValue.messenger.skill1.waitingTime,
    },
    skill2: {
      totalAnswers:
        accumulator.messenger.skill2.totalAnswers +
        accumulator.line.skill2.totalAnswers +
        currentValue.line.skill2.totalAnswers +
        currentValue.messenger.skill2.totalAnswers,
      abandonCustomers:
        accumulator.messenger.skill2.abandonCustomers +
        accumulator.line.skill2.abandonCustomers +
        currentValue.line.skill2.abandonCustomers +
        currentValue.messenger.skill2.abandonCustomers,
      total:
        accumulator.messenger.skill2.total +
        accumulator.line.skill2.total +
        currentValue.line.skill2.total +
        currentValue.messenger.skill2.total,
      totalAnswers:
        accumulator.messenger.skill2.totalAnswers +
        accumulator.line.skill2.totalAnswers +
        currentValue.line.skill2.totalAnswers +
        currentValue.messenger.skill2.totalAnswers,
      waitingTime:
        accumulator.messenger.skill2.waitingTime +
        accumulator.line.skill2.waitingTime +
        currentValue.line.skill2.waitingTime +
        currentValue.messenger.skill2.waitingTime,
    },
    skill3: {
      totalAnswers:
        accumulator.messenger.skill3.totalAnswers +
        accumulator.line.skill3.totalAnswers +
        currentValue.line.skill3.totalAnswers +
        currentValue.messenger.skill3.totalAnswers,
      abandonCustomers:
        accumulator.messenger.skill3.abandonCustomers +
        accumulator.line.skill3.abandonCustomers +
        currentValue.line.skill3.abandonCustomers +
        currentValue.messenger.skill3.abandonCustomers,
      total:
        accumulator.messenger.skill3.total +
        accumulator.line.skill3.total +
        currentValue.line.skill3.total +
        currentValue.messenger.skill3.total,
      totalAnswers:
        accumulator.messenger.skill3.totalAnswers +
        accumulator.line.skill3.totalAnswers +
        currentValue.line.skill3.totalAnswers +
        currentValue.messenger.skill3.totalAnswers,
      waitingTime:
        accumulator.messenger.skill3.waitingTime +
        accumulator.line.skill3.waitingTime +
        currentValue.line.skill3.waitingTime +
        currentValue.messenger.skill3.waitingTime,
    },
    skill4: {
      totalAnswers:
        accumulator.messenger.skill4.totalAnswers +
        accumulator.line.skill4.totalAnswers +
        currentValue.line.skill4.totalAnswers +
        currentValue.messenger.skill4.totalAnswers,
      abandonCustomers:
        accumulator.messenger.skill4.abandonCustomers +
        accumulator.line.skill4.abandonCustomers +
        currentValue.line.skill4.abandonCustomers +
        currentValue.messenger.skill4.abandonCustomers,
      total:
        accumulator.messenger.skill4.total +
        accumulator.line.skill4.total +
        currentValue.line.skill4.total +
        currentValue.messenger.skill4.total,
      totalAnswers:
        accumulator.messenger.skill4.totalAnswers +
        accumulator.line.skill4.totalAnswers +
        currentValue.line.skill4.totalAnswers +
        currentValue.messenger.skill4.totalAnswers,
      waitingTime:
        accumulator.messenger.skill4.waitingTime +
        accumulator.line.skill4.waitingTime +
        currentValue.line.skill4.waitingTime +
        currentValue.messenger.skill4.waitingTime,
    },
    skill5: {
      totalAnswers:
        accumulator.messenger.skill5.totalAnswers +
        accumulator.line.skill5.totalAnswers +
        currentValue.line.skill5.totalAnswers +
        currentValue.messenger.skill5.totalAnswers,
      abandonCustomers:
        accumulator.messenger.skill5.abandonCustomers +
        accumulator.line.skill5.abandonCustomers +
        currentValue.line.skill5.abandonCustomers +
        currentValue.messenger.skill5.abandonCustomers,
      total:
        accumulator.messenger.skill5.total +
        accumulator.line.skill5.total +
        currentValue.line.skill5.total +
        currentValue.messenger.skill5.total,
      totalAnswers:
        accumulator.messenger.skill5.totalAnswers +
        accumulator.line.skill5.totalAnswers +
        currentValue.line.skill5.totalAnswers +
        currentValue.messenger.skill5.totalAnswers,
      waitingTime:
        accumulator.messenger.skill5.waitingTime +
        accumulator.line.skill5.waitingTime +
        currentValue.line.skill5.waitingTime +
        currentValue.messenger.skill5.waitingTime,
    },
  },
})

const initCalcReduce = () => ({
  messenger: {
    skill1: {
      totalAnswers: 0,
      abandonCustomers: 0,
      total: 0,
      totalAnswers: 0,
      waitingTime: 0,
    },
    skill2: {
      totalAnswers: 0,
      abandonCustomers: 0,
      total: 0,
      totalAnswers: 0,
      waitingTime: 0,
    },
    skill3: {
      totalAnswers: 0,
      abandonCustomers: 0,
      total: 0,
      totalAnswers: 0,
      waitingTime: 0,
    },
    skill4: {
      totalAnswers: 0,
      abandonCustomers: 0,
      total: 0,
      totalAnswers: 0,
      waitingTime: 0,
    },
    skill5: {
      totalAnswers: 0,
      abandonCustomers: 0,
      total: 0,
      totalAnswers: 0,
      waitingTime: 0,
    },
  },
  line: {
    skill1: {
      totalAnswers: 0,
      abandonCustomers: 0,
      total: 0,
      totalAnswers: 0,
      waitingTime: 0,
    },
    skill2: {
      totalAnswers: 0,
      abandonCustomers: 0,
      total: 0,
      totalAnswers: 0,
      waitingTime: 0,
    },
    skill3: {
      totalAnswers: 0,
      abandonCustomers: 0,
      total: 0,
      totalAnswers: 0,
      waitingTime: 0,
    },
    skill4: {
      totalAnswers: 0,
      abandonCustomers: 0,
      total: 0,
      totalAnswers: 0,
      waitingTime: 0,
    },
    skill5: {
      totalAnswers: 0,
      abandonCustomers: 0,
      total: 0,
      totalAnswers: 0,
      waitingTime: 0,
    },
  },
  total: {
    skill1: {
      totalAnswers: 0,
      abandonCustomers: 0,
      total: 0,
      totalAnswers: 0,
      waitingTime: 0,
    },
    skill2: {
      totalAnswers: 0,
      abandonCustomers: 0,
      total: 0,
      totalAnswers: 0,
      waitingTime: 0,
    },
    skill3: {
      totalAnswers: 0,
      abandonCustomers: 0,
      total: 0,
      totalAnswers: 0,
      waitingTime: 0,
    },
    skill4: {
      totalAnswers: 0,
      abandonCustomers: 0,
      total: 0,
      totalAnswers: 0,
      waitingTime: 0,
    },
    skill5: {
      totalAnswers: 0,
      abandonCustomers: 0,
      total: 0,
      totalAnswers: 0,
      waitingTime: 0,
    },
  },
})

const token = localStorage.getItem("tokenSupervisor")

const initSupervisor = {
  supervisor: {
    _id: "",
    email: "",
    skills: [],
  },
  stats: {
    messenger: {},
    line: {},
    total: {},
    // skill1: {
    //   totalAnswers: 400,
    //   abandonCustomers: 24,
    //   total: 424,
    //   waitingTime: 600000,
    // }
  },
  statsByDay: [],
}
function reducerSupervisor(state, action) {
  const { payload, type } = action
  switch (type) {
    case "write_stats_by_day":
      return {
        ...state,
        statsByDay: payload,
      }
    case "write_stats":
      return {
        ...state,
        stats: { ...state.stats, ...payload },
      }
    case "read_supervisor":
      return {
        ...state,
        ...payload,
      }

    default:
      throw new Error()
  }
}

export default () => {
  const [reducer, dispatch] = useReducer(reducerSupervisor, initSupervisor)
  const [datesInput, selectDatesInput] = useState({
    startDate: dateFormat(new Date(), "2020-06-04"),
    endDate: dateFormat(new Date(), "yyyy-mm-dd"),
  })

  const _selectDates = (key, value) => {
    selectDatesInput({ ...datesInput, [key]: dateFormat(value, "yyyy-mm-dd") })
  }

  const _search = () => {
    axios
      .get(
        `${BACK_END_URL}/api/stats/reportskill/${datesInput.startDate}/${datesInput.endDate}`
      )
      .then(({ data }) => {
        dispatch({
          type: "write_stats_by_day",
          payload: data.map((x) => ({
            ...x,
            total: calcReportSkillbyDay(x),
          })),
        })

        const reduceme = data.reduce((accumulator, currentValue) => {
          console.log(accumulator, currentValue)
          return calcReduce(accumulator, currentValue)
        }, initCalcReduce())
        console.log("reducervMEE", reduceme)
        dispatch({
          type: "write_stats",
          payload: reduceme,
        })
      })
      .catch((e) => console.log(e))
  }

  const { tab } = queryString.parse(window.location.search)

  if (!token) return window.location.replace("/")

  useEffect(() => {
    if (token) {
      axios
        .post(`${BACK_END_URL}/auth/token`, "", {
          headers: { Authorization: token },
        })
        .then(({ data }) => {
          dispatch({
            type: "read_supervisor",
            payload: data.supervisor,
          })

          _search()
        })
        .catch((e) => window.location.replace("/"))
    }
  }, [token])

  return (
    <WrapperSupervisor supervisorReducer={reducer}>
      <ReportSkills
        reducer={reducer}
        _selectDates={_selectDates}
        _search={_search}
        datesInput={datesInput}
      />
    </WrapperSupervisor>
  )
}
