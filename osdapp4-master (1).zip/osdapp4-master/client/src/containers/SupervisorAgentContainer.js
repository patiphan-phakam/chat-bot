import React, { useEffect, useState, useReducer, useMemo } from "react"
import axios from "axios"
import { Redirect } from "react-router-dom"
import SupervisorAgent from "../components/SupervisorAgent"
import WrapperSupervisor from "../WrapperSupervisor"
import io from "socket.io-client"
import { BACK_END_URL } from "../config"

const NamespaceGlobal = io(`https://dchat.osd.co.th/`, {
  path: "/socket/socket.io",
})

const initialState = {
  supervisor: {
    _id: "",
    email: "",
    skills: [],
  },
  agent: {
    ratings: {
      "9": {
        stars1: 0,
        stars2: 0,
        stars3: 0,
        stars4: 0,
        stars5: 0,
      },
      "10": {
        stars1: 0,
        stars2: 0,
        stars3: 0,
        stars4: 0,
        stars5: 0,
      },
      "11": {
        stars1: 0,
        stars2: 0,
        stars3: 0,
        stars4: 0,
        stars5: 0,
      },
      "12": {
        stars1: 0,
        stars2: 0,
        stars3: 0,
        stars4: 0,
        stars5: 0,
      },
      "13": {
        stars1: 0,
        stars2: 0,
        stars3: 0,
        stars4: 0,
        stars5: 0,
      },
      "14": {
        stars1: 0,
        stars2: 0,
        stars3: 0,
        stars4: 0,
        stars5: 0,
      },
      "15": {
        stars1: 0,
        stars2: 0,
        stars3: 0,
        stars4: 0,
        stars5: 0,
      },
      "16": {
        stars1: 0,
        stars2: 0,
        stars3: 0,
        stars4: 0,
        stars5: 0,
      },
      "17": {
        stars1: 0,
        stars2: 0,
        stars3: 0,
        stars4: 0,
        stars5: 0,
      },
      "18": {
        stars1: 0,
        stars2: 0,
        stars3: 0,
        stars4: 0,
        stars5: 0,
      },
    },
    skills: [],
    loading: false, // Loading effect
    status: null,
    statusHistory: [
      // {
      //   status: "available",
      //   duration: 6373,
      //   start: "2020-03-11T07:27:30.000Z"
      // }
    ],
  },
  chatFlowSupervisor: [
    // {
    //   author: "supervisor1",
    //   msg: "",
    //   type: "text",
    //   date: new Date()
    // },
    // {
    //   author: "me",
    //   msg: "",
    //   type: "text",
    //   date: new Date()
    // }
  ],
  flow: [
    // {
    //   author: "user",
    //   msg: "",
    //   type: "text"
    // },
    // {
    //   author: "me",
    //   msg: "",
    //   type: "text"
    // }
  ],
}

function reducer(state, action) {
  const { payload, type } = action
  switch (type) {
    case "readAgent":
      return {
        ...state,
        agent: payload,
      }

    case "agentEmailSkills":
      return {
        ...state,
        agent: { ...state.agent, email: payload.email, skills: payload.skills },
      }

    case "agentStatus":
      return {
        ...state,
        agent: { ...state.agent, ...payload },
      }

    case "agentStatusWs":
      if (state.agent.statusHistory.length > 0) {
        const lastValue =
          state.agent.statusHistory[state.agent.statusHistory.length - 1]
        const without = state.agent.statusHistory.slice(0, -1)
        const duration =
          new Date(payload.start).getTime() -
          new Date(lastValue.start).getTime()
        const result = [
          ...without,
          { ...lastValue, duration },
          { ...payload, duration: null },
        ]
        return {
          ...state,
          agent: {
            ...state.agent,
            ...{
              status: payload.status,
              statusHistory: result,
            },
          },
        }
      } else {
        return {
          ...state,
          agent: {
            ...state.agent,
            ...{
              status: payload.status,
              statusHistory: [{ ...payload, duration: null }],
            },
          },
        }
      }

    case "ratingsAgent":
      return {
        ...state,
        agent: {
          ...state.agent,
          ratings: { ...state.agent.ratings, ...payload },
        },
      }

    case "msgToAgent":
      return {
        ...state,
        chatFlowSupervisor: [...state.chatFlowSupervisor, { ...payload }],
      }

    case "newMessage":
      return {
        ...state,
        flow: [...state.flow, { ...payload }],
      }

    case "historyMsg":
      return {
        ...state,
        flow: [...payload, ...state.flow],
      }

    case "readSupervisor":
      return {
        ...state,
        supervisor: payload,
      }

    default:
      throw new Error()
  }
}

const SupervisorAgentContainer = ({ match }) => {
  const [redirect, useredirect] = useState(false)
  const [supervisorReducer, dispatch] = useReducer(reducer, initialState)
  const [msgSupToAgent, setmsgSupToAgent] = useState("")
  const [unlockChat, setunlockChat] = useState(false)
  const [wsStatusNoRerender, setwsStatusNoRerender] = useState(false)

  const _unlockChat = () => setunlockChat(true)
  const _readAgent = () => {
    const { agentId } = match.params

    axios
      .get(`${BACK_END_URL}/api/agents/${agentId}`)
      .then(({ data }) => {
        dispatch({
          type: "agentEmailSkills",
          payload: data,
        })
      })
      .catch((e) => console.log("_readAgent() error", e))

    axios
      .get(`${BACK_END_URL}/api/agents/status/${agentId}`)
      .then(({ data }) => {
        dispatch({
          type: "agentStatus",
          payload: data,
        })
      })
      .catch((e) => console.log("_readAgent() error", e))

    axios
      .get(`${BACK_END_URL}/api/agents/rating/${agentId}`)
      .then(({ data }) => {
        dispatch({
          type: "ratingsAgent",
          payload: data,
        })
      })
      .catch((e) => console.log("_readAgent() error", e))
  }

  useEffect(() => {
    const { agentId } = match.params
    if (agentId !== "") {
      NamespaceGlobal.emit(`supervisor join agent room`, agentId)
      NamespaceGlobal.on(`supervisor roomjoined`, (agentId) => {
        console.log(`supervisor joined agent ${agentId} room`)
      })

      NamespaceGlobal.on("msg agent -> supervisor", (payload) => {
        dispatch({
          type: "msgToAgent",
          payload: {
            msg: payload.msg,
            agentId: match.params.agentId,
            author: "agent",
            date: payload.date,
          },
        })
      })

      NamespaceGlobal.on("agent ws", (payload) => {
        if (payload.type === "status") {
          dispatch({
            type: "agentStatusWs",
            payload,
          })
        }
        if (payload.type === "rating") {
          console.log(payload.rating)
          dispatch({
            type: "ratingsAgent",
            payload: payload.rating,
          })
        }
      })

      //form db
      axios
        .get(`${BACK_END_URL}/api/agents/allchats/${agentId}`)
        .then(({ data }) => {
          data.map((x) => {
            if (x.chat) {
              dispatch({
                type: "historyMsg",
                payload: x.chat,
              })
            }
          })
        })
        .then(() => {
          //from memory
          axios.get(`${BACK_END_URL}/currentmsg/${agentId}`).then(({ data }) => {
            //TODO parse here
            const arrParse = data
              .map((x) => JSON.parse(x))
              .sort((a, b) => new Date(a.date) - new Date(b.date))

            arrParse.map((x) => {
              dispatch({
                type: "newMessage",
                payload: {
                  msg: x.message,
                  author: x.author === "customer" ? "user" : "agent",
                  type: "text",
                  date: x.date,
                },
              })
            })
          })
        })

      NamespaceGlobal.on(`webhook msg`, ({ message, date }) => {
        return dispatch({
          type: "newMessage",
          payload: {
            msg: message,
            author: "user",
            type: "text",
            date,
          },
        })
      })

      NamespaceGlobal.on(`agent -> customer`, ({ msg, type, date }) => {
        return dispatch({
          type: "newMessage",
          payload: {
            msg,
            author: "agent",
            type: "text",
            date,
          },
        })
      })
      _readAgent()
      const token = localStorage.getItem("tokenSupervisor")
      if (token) {
        axios
          .post(`${BACK_END_URL}/auth/token`, "", {
            headers: { Authorization: token },
          })
          .then(({ data }) => {
            dispatch({
              type: "readSupervisor",
              payload: data.supervisor,
            })
          })

          .catch((e) => useredirect(true))
      }
      if (!token) return useredirect(true)
    }
  }, [match.params.agentId])

  const _submitChatsa = (e) => {
    e.preventDefault()
    axios
      .post(`${BACK_END_URL}/api/chat/suptoagent`, {
        msg: msgSupToAgent,
        agentId: match.params.agentId,
        supervisorId: "supervisor1",
      })
      .then(() => {
        dispatch({
          type: "msgToAgent",
          payload: {
            msg: msgSupToAgent,
            agentId: match.params.agentId,
            author: "me",
            date: new Date(),
          },
        })
      })

    setmsgSupToAgent("")
  }

  const _onChangeChatAgent = (e) => setmsgSupToAgent(e.target.value)

  const _updateSkills = (skills) => {
    const { agentId } = match.params
    axios
      .put(`${BACK_END_URL}/api/agents/${agentId}/?skills=${skills}`)
      .then(({ data }) => {
        dispatch({
          type: "readAgent",
          payload: data,
        })
      })
      .catch((err) => console.log(err))
  }

  // useEffect(() => {
  //   const supervisorGroup = "team1"
  //   NamespaceSupervisor.emit(`supervisor join room`, supervisorGroup)

  //   NamespaceSupervisor.on("msg agent -> supervisor", (payload) => {
  //     dispatch({
  //       type: "msgToAgent",
  //       payload: {
  //         msg: payload.msg,
  //         agentId: match.params.agentId,
  //         author: "agent",
  //         date: payload.date,
  //       },
  //     })
  //     console.log("msg agent -> supervisor", payload)
  //   })
  //   // NamespaceGlobal.to("team1").emit(`msg supervisor -> agent`, {
  //   //   msg: msgSupToAgent,
  //   //   author: "supervisor1",
  //   //   type: "text",
  //   //   date: new Date()
  //   // })
  // }, [])

  // CALCULATION

  useEffect(() => {
    console.log("reudcer", supervisorReducer.agent.ratings)
  }, [supervisorReducer.agent])

  const calculation = {
    ratings: {
      toTable: function () {
        const averageCalculate = (arr) => {
          let total = 0
          let counter = 0
          Object.entries(arr).map((x) => {
            const extractKey = Number(x[0].slice(5))
            if (!isNaN(extractKey)) {
              total = total + x[1] * extractKey
              counter = counter + x[1]
            }
          })
          if (!isNaN(total / counter)) {
            return total / counter
          } else {
            return 0
          }
        }
        return Object.entries(supervisorReducer.agent.ratings).map((x) => {
          return {
            name: `${x[0]}h`,
            ...x[1],
            average: averageCalculate(x[1]),
          }
        })
      },
    },
    status: {
      groupBy: function (xs, key) {
        return xs.reduce((rv, x) => {
          ;(rv[x[key]] = rv[x[key]] || []).push(x)
          return rv
        }, {})
      },
      totalDuration: function (arr) {
        return arr.reduce(function (acc, obj) {
          return acc + obj.duration
        }, 0)
      },
      keyFilter: function (key) {
        return supervisorReducer.agent.statusHistory.filter(
          (x) => x.status === key
        )
      },
      timeAccu: function (key, subkey) {
        return this.keyFilter(key).reduce(function (acc, obj) {
          return acc + obj[subkey]
        }, 0)
      },
      timePerc: function (key) {
        // statusTimePerc("available") => 18%
        return Math.round(
          (100 / this.totalDuration(supervisorReducer.agent.statusHistory)) *
            this.timeAccu(key, "duration")
        )
      },
      totalWorkTime: function () {
        // workTimePerc("busy", "duration") => 18%
        return Math.round(
          (100 / this.totalDuration(supervisorReducer.agent.statusHistory)) *
            (this.timeAccu("busy", "duration") +
              this.timeAccu("wrapup", "duration"))
        )
      },
    },
  }

  if (redirect) return <Redirect to="/supervisor/login" />
  return (
    <div>
      <WrapperSupervisor supervisorReducer={supervisorReducer}>
        <SupervisorAgent
          supervisorReducer={supervisorReducer}
          match={match}
          msgSupToAgent={msgSupToAgent}
          _onChangeChatAgent={_onChangeChatAgent}
          _submitChatsa={_submitChatsa}
          _unlockChat={_unlockChat}
          unlockChat={unlockChat}
          _readAgent={_readAgent}
          _updateSkills={_updateSkills}
          calculation={calculation}
        />{" "}
      </WrapperSupervisor>{" "}
    </div>
  )
}

export default SupervisorAgentContainer
