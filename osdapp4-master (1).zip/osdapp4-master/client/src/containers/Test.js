import React, { useEffect, useState } from "react"
import { PROD, dev } from "../config"
import io from "socket.io-client"
const ioAgentState = io(`http://localhost:5000/my-namespace`)

export default () => {
  useEffect(() => {
    ioAgentState.on(`hehe`, (data) => {
      console.log(data)
    })
  }, [io])
  return <div>test page</div>
}
