export const PAGE_TOKEN =
  "EAAHQZCaznRV4BAF7bYgwkthLHd2WZCaXtMUQDXEv31USrn0Rix10m516zbZAHetyrkaNHT2Dy9ZBmSzLhcsKPZCj7rAq2pY19aCLIZCXZBZAAlDE0uPZCJDGNxl9hd4YlvlmR4zwOrNEnhPHSDxZC8RmYN7BUacmLh7DWJtkqrerxqiQZDZD"

const { hostname } = window.location

export const FRONT_END_URL = hostname.includes("localhost")
  ? "http://localhost:3000"
  : "https://dchat.osd.co.th"

export const BACK_END_URL = "https://dchat.osd.co.th/backend"

// export const BACK_END_URL = hostname.includes("localhost") ?
// "http://localhost:5000/backend" :
// "https://dchat.osd.co.th/backend"
