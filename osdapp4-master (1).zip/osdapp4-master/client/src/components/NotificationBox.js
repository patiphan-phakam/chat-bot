import React from "react"
import { makeStyles } from "@material-ui/core/styles"
import Button from "@material-ui/core/Button"
import Snackbar from "@material-ui/core/Snackbar"
import IconButton from "@material-ui/core/IconButton"
import CloseIcon from "@material-ui/icons/Close"
import Slide from "@material-ui/core/Slide"
import Avatar from "@material-ui/core/Avatar"

const useStyles = makeStyles(theme => ({
  close: {
    padding: theme.spacing(0.5)
  }
}))

export default function NotificationBox({
  openNotiBox,
  setOpenNotiBox,
  lastMsg
}) {
  const queueRef = React.useRef([])
  const [open, setOpen] = React.useState(false)
  const [messageInfo, setMessageInfo] = React.useState(undefined)

  const processQueue = () => {
    if (queueRef.current.length > 0) {
      setMessageInfo(queueRef.current.shift())
      setOpen(true)
    }
  }

  const handleClick = message => () => {
    queueRef.current.push({
      message,
      key: new Date().getTime()
    })

    if (open) {
      // immediately begin dismissing current message
      // to start showing new one
      setOpen(false)
    } else {
      processQueue()
    }
  }

  const handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return
    }
    setOpen(false)
  }

  const handleExited = () => {
    processQueue()
  }

  const classes = useStyles()
  return (
    <div>
      <Snackbar
        // key={messageInfo ? messageInfo.key : undefined}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right"
        }}
        // transition={<Slide {...props} direction="right" />}
        open={openNotiBox}
        autoHideDuration={6000}
        onClose={handleClose}
        onExited={handleExited}
        ContentProps={{
          "aria-describedby": "message-id"
        }}
        message={
          <div id="message-id" style={{ display: "flex" }}>
            <Avatar>S</Avatar>
            <div style={{ marginLeft: 10 }}>
              <div style={{ fontWeight: "bold" }}>
                {lastMsg && lastMsg.author}
              </div>
              <div>{lastMsg && lastMsg.msg}</div>
            </div>
          </div>
        }
        action={[
          <Button
            key="undo"
            style={{ color: "white" }}
            size="small"
            onClick={handleClose}
          >
            Answer
          </Button>,
          <IconButton
            key="close"
            aria-label="close"
            color="inherit"
            className={classes.close}
            onClick={() => setOpenNotiBox(false)}
          >
            <CloseIcon />
          </IconButton>
        ]}
      />
    </div>
  )
}
