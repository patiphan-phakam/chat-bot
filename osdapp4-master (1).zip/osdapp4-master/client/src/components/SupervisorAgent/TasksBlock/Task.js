import React from "react"
import { makeStyles } from "@material-ui/core/styles"
import MoreVertButton from "@material-ui/icons/MoreVert"
import EditButton from "@material-ui/icons/Edit"
import DeleteButton from "@material-ui/icons/Delete"
import IconButton from "@material-ui/core/IconButton"

const useStyles = makeStyles(theme => ({
  task: {
    padding: theme.spacing(1, 0),
    minWidth: "calc(100vw - 1150px)"
  }
}))

const styles = {
  inProgress: {
    background: "#fff7c4",
    color: "#fad30f",
    padding: 3,
    borderRadius: 5,
    fontSize: 12,
    fontWeight: "bold",
    textAlign: "center",
    width: 74
  },
  outdated: {
    background: "#ffb0c9",
    color: "#ff0051",
    padding: 3,
    borderRadius: 5,
    fontSize: 12,
    fontWeight: "bold",
    textAlign: "center",
    width: 74
  },
  completed: {
    background: "#cdf7f2",
    color: "#00bfa5",
    padding: 3,
    borderRadius: 5,
    fontSize: 12,
    fontWeight: "bold",
    textAlign: "center",
    width: 74
  }
}

const Task = ({ title, due, status, assigned, totalTime }) => {
  const classes = useStyles()
  return (
    <div
      className={classes.task}
      style={{
        display: "flex",
        borderTop: "1px solid #e0e0e0",
        justifyContent: "space-between",
        flexWrap: "wrap",
        flexGrow: 1
      }}
    >
      <div>
        <div style={{ fontWeight: "bold", width: 150 }}>{title}</div>
        <div>Due: {due} days</div>
        <div>Total Time: {totalTime}</div>
      </div>
      <div>
        <div style={{ color: "#757575" }}>Status</div>
        <div
          style={
            status === "In-progress"
              ? styles.inProgress
              : status === "Outdated"
              ? styles.outdated
              : status === "Completed" && styles.completed
          }
        >
          {status}
        </div>
      </div>
      <div>
        <div style={{ color: "#757575" }}>Assigned</div>
        <div>{assigned}</div>
      </div>
      <div style={{ display: "flex", flexWrap: "wrap" }}>
        <IconButton
          aria-label="edit"
          style={{ width: 25, height: 25, padding: 0 }}
        >
          <EditButton style={{ fontSize: 17 }} />
        </IconButton>
        <IconButton
          aria-label="delete"
          style={{ width: 25, height: 25, padding: 0 }}
        >
          <DeleteButton style={{ fontSize: 19 }} />
        </IconButton>
      </div>
    </div>
  )
}

export default Task
