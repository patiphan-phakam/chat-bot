import React, { useState, useEffect } from "react"
import { makeStyles } from "@material-ui/core/styles"
import Paper from "@material-ui/core/Paper"
import Typography from "@material-ui/core/Typography"
import Button from "@material-ui/core/Button"
import TextField from "@material-ui/core/TextField"

const useStyles = makeStyles(theme => ({
  root: {
    padding: theme.spacing(3, 2),
    margin: theme.spacing(1),
    width: 220,
    display: "flex",
    flexDirection: "column",
    flexWrap: "wrap"
  },
  picProfile: {
    width: theme.spacing(8),
    height: theme.spacing(8)
  }
}))

const styles = {
  addressTitle: {
    color: "#424242",
    fontSize: 18,
    marginTop: 10
  }
}

export default ({ supervisorReducer, _updateSkills }) => {
  const [editMode, setEditMode] = useState(false)
  const [skills, setSkills] = useState([])
  const [errMsg, setErrMsg] = useState(null)
  const classes = useStyles()

  useEffect(() => {
    setSkills(
      supervisorReducer.agent.skills.map((x, index) => ({ skill: x, index }))
    )
  }, [supervisorReducer.agent.skills])

  const _delete = index => {
    if (skills.length < 2) {
      setErrMsg("1 min skill is required")
    } else {
      const without = skills.filter(x => x.index !== index)
      setSkills(without)
    }
  }

  const _update = (value, index) => {
    const without = skills.filter(x => x.index !== index)
    setSkills([...without, { skill: value, index }])
  }

  const _submit = () => {
    if (skills.filter(x => x.skill === "").length === 0) {
      setEditMode(!editMode)
      setErrMsg(null)
      _updateSkills(skills.map(x => x.skill).join())
    } else {
      setErrMsg("skill cannot be empty")
    }
  }

  return (
    <Paper className={classes.root}>
      <Typography variant="h5" className={classes.title} gutterBottom>
        Skills
      </Typography>

      {editMode ? (
        skills.length > 0 &&
        skills
          .sort((a, b) => a.index - b.index)
          .map((x, index) => (
            <div
              key={index}
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center"
              }}
            >
              ✎{" "}
              <TextField
                style={{ margin: "0px 5px 0px 5px" }}
                value={x.skill}
                onChange={e => _update(e.target.value, x.index)}
              />{" "}
              <span
                onClick={() => _delete(x.index)}
                style={{ cursor: "pointer" }}
              >
                ❌
              </span>
            </div>
          ))
      ) : (
        <ul>
          {" "}
          {skills.map((x, index) => (
            <li key={index}>{x.skill}</li>
          ))}{" "}
        </ul>
      )}
      {errMsg && (
        <div style={{ margin: "10px 0px 10px 0px", color: "red" }}>
          {errMsg}
        </div>
      )}

      {editMode && (
        <Button
          style={{ marginTop: 15 }}
          onClick={() =>
            setSkills([...skills, { skill: "", index: skills.length }])
          }
          variant="outlined"
          color="primary"
          size="small"
        >
          Add Skill
        </Button>
      )}

      <Button
        style={{ marginTop: 15 }}
        onClick={_submit}
        variant="contained"
        color="primary"
      >
        {editMode ? "Save" : "Edit"}
      </Button>
    </Paper>
  )
}
