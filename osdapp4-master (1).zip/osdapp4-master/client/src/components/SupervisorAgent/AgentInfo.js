import React from "react"
import { makeStyles } from "@material-ui/core/styles"
import Paper from "@material-ui/core/Paper"
import Avatar from "@material-ui/core/Avatar"
import Typography from "@material-ui/core/Typography"
import Rating from "@material-ui/lab/Rating"
import FormatListBulletedIcon from "@material-ui/icons/FormatListBulleted"
import CommentIcon from "@material-ui/icons/Comment"
import { Link } from "react-router-dom"

const useStyles = makeStyles(theme => ({
  root: {
    padding: theme.spacing(3, 2),
    margin: theme.spacing(1),
    width: 220,
    display: "flex",
    flexDirection: "column",
    flexWrap: "wrap",
    cursor: "pointer",
    "&:hover": {
      opacity: 0.7
    }
  },
  picProfile: {
    width: theme.spacing(8),
    height: theme.spacing(8)
  }
}))

const styles = {
  addressTitle: {
    color: "#424242",
    fontSize: 18,
    marginTop: 10
  }
}

const AgentInfo = () => {
  const classes = useStyles()
  return (
    <Paper className={classes.root}>
      <div style={styles.addressTitle}>Address</div>
      <div style={{ marginTop: 5 }}>
        Donec hendrerit arcu nec consectetur molestie. Fusce temdivus nulla eget
        magna congue, ut dadivibus nisi rhoncus. Morbi vitae ante interdum,
        rhoncus felis sit amet, rhoncus diam.
      </div>
      <div style={styles.addressTitle}>Phone</div>
      <div style={{ marginTop: 5 }}>09X-XXX-XXXX</div>
      <div style={styles.addressTitle}>E-Mail</div>
      <div style={{ marginTop: 5 }}>name_sur@gmail.com</div>
    </Paper>
  )
}

export default AgentInfo
