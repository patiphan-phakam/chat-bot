import React from "react"
import Paper from "@material-ui/core/Paper"
import { makeStyles } from "@material-ui/core/styles"
import Typography from "@material-ui/core/Typography"
import Restore from "@material-ui/icons/Restore"

const useStyles = makeStyles(theme => ({
  blockStats: {
    padding: theme.spacing(3, 2),
    margin: theme.spacing(1),
    flex: 1,
    display: "flex",
    justifyContent: "space-between"
  }
}))

const StatCard = ({ number, underTitle }) => {
  const classes = useStyles()
  return (
    <Paper className={classes.blockStats}>
      <div>
        <div style={{ color: "#757575", fontSize: 40, fontWeight: 550 }}>
          {number}
        </div>
        <div style={{ color: "#757575" }}>{underTitle}</div>
      </div>
      <div>
        <Restore style={{ fontSize: 80, color: "#757575" }} />
      </div>
    </Paper>
  )
}

export default StatCard
