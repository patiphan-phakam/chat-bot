import React from "react"
import ChatSupervisorAgent from "./ChatSupervisorAgent"
import ChatCustomerAgent from "./ChatCustomerAgent"
import Card from "./Card"
import AgentInfo from "./AgentInfo"
import StatCard from "./StatCard"
import TasksBlock from "./TasksBlock"
import GraphPie from "./GraphPie"
import GraphAvgSession from "./GraphAvgSession"
import GraphWrapUp from "./GraphWrapUp"
import GraphRating from "./GraphRating"
import Typography from "@material-ui/core/Typography"
import useMediaQuery from "@material-ui/core/useMediaQuery"

const SupervisorAgent = ({
  match,
  msgSupToAgent,
  chatsa,
  _onChangeChatAgent,
  _submitChatsa,
  supervisorReducer,
  _unlockChat,
  unlockChat,
  _updateSkills,
  calculation,
}) => {
  const isMore1390 = useMediaQuery("(min-width:1390px)")

  const { status } = calculation

  return (
    <>
      <div style={{ marginLeft: 8, color: "#424242" }}>
        <Typography variant="h4" gutterBottom>
          Profile
        </Typography>
        <Typography variant="body2" gutterBottom>
          <span>
            <a
              style={{ color: "#424242" }}
              href="https://dchat.osd.co.th/supervisor/?tab=dashboard"
            >
              Dashboard
            </a>
          </span>
          <span> / Agent: {supervisorReducer.agent.email}</span>
        </Typography>
      </div>
      <div
        style={{
          width: "calc(100% - 16px)",
          borderBottom: "2px solid #BEBEBE",
          margin: "20px 8px 20px 8px",
          textAlign: "right",
        }}
      />

      <div style={{ display: "flex" }}>
        <div>
          <Card agent={supervisorReducer.agent} />
          <AgentInfo />
          {/* <SkillsConfig
          supervisorReducer={supervisorReducer}
          _updateSkills={_updateSkills}
        /> */}
        </div>
        <div>
          <div style={{ display: "flex", flexWrap: "wrap" }}>
            <div>
              {/* show all stats for debug */}
              {/* {!isNaN(status.timePerc("available")) && (
              <span>
                <span>available: {status.timePerc("available")}% /</span>
                <span> busy: {status.timePerc("busy")}% / </span>
                <span> disconnect: {status.timePerc("disconnect")}% / </span>
                <span> wrapup: {status.timePerc("wrapup")}% / </span>
                <span> toilet: 0% </span>
              </span>
            )} */}

              <div style={{ display: "flex", flexWrap: "wrap" }}>
                <StatCard
                  number={status.totalWorkTime() + "%"}
                  underTitle="Working Time"
                />
                <StatCard
                  number={status.keyFilter("busy").length}
                  underTitle="Engaged Sessions"
                />
              </div>
              <div style={{ display: "flex", flexWrap: "wrap" }}>
                <ChatCustomerAgent
                  supervisorReducer={supervisorReducer}
                  _unlockChat={_unlockChat}
                  unlockChat={unlockChat}
                />
                <ChatSupervisorAgent
                  msgSupToAgent={msgSupToAgent}
                  chatsa={chatsa}
                  _onChangeChatAgent={_onChangeChatAgent}
                  _submitChatsa={_submitChatsa}
                  supervisorReducer={supervisorReducer}
                />
              </div>
            </div>

            {/* <TasksBlock /> */}

            <GraphWrapUp calculation={calculation} isMore1390={isMore1390} />
            <GraphAvgSession
              calculation={calculation}
              isMore1390={isMore1390}
            />
            <GraphPie calculation={calculation} isMore1390={isMore1390} />
            <GraphRating calculation={calculation} isMore1390={isMore1390} />
          </div>
        </div>
      </div>
    </>
  )
}

export default SupervisorAgent
