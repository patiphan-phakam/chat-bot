import React from "react"
import { makeStyles } from "@material-ui/core/styles"
import Paper from "@material-ui/core/Paper"
import InputChat from "./InputChat"
import HeaderChat from "./HeaderChat"
import Content from "./Content"

const useStyles = makeStyles(theme => ({
  root: {
    padding: theme.spacing(3, 2),
    margin: theme.spacing(1),
    color: "#757575",
    display: "flex",
    flexDirection: "column",
    width: 350,
    maxHeight: 550
  }
}))

const ChatContent = ({
  msgSupToAgent,
  chatsa,
  _onChangeChatAgent,
  _submitChatsa,
  supervisorReducer
}) => {
  const classes = useStyles()
  return (
    <Paper className={classes.root}>
      <HeaderChat />
      <Content supervisorReducer={supervisorReducer} />
      <InputChat
        msgSupToAgent={msgSupToAgent}
        chatsa={chatsa}
        _onChangeChatAgent={_onChangeChatAgent}
        _submitChatsa={_submitChatsa}
      />
    </Paper>
  )
}

export default ChatContent
