import React, { useState } from "react"
import Button from "@material-ui/core/Button"
import TextField from "@material-ui/core/TextField"
import SendIcon from "@material-ui/icons/Send"

const InputChat = ({
  msgSupToAgent,
  chatsa,
  _onChangeChatAgent,
  _submitChatsa
}) => {
  return (
    <form
      onSubmit={_submitChatsa}
      style={{ height: 51, display: "flex", marginTop: 10 }}
    >
      <TextField
        id="outlined-textarea"
        label="To agent"
        placeholder="To agent"
        variant="outlined"
        fullWidth
        value={msgSupToAgent}
        onChange={_onChangeChatAgent}
      />
      <Button
        type="submit"
        variant="contained"
        color="primary"
        style={{ marginLeft: 10 }}
      >
        <SendIcon />
      </Button>
    </form>
  )
}

export default InputChat
