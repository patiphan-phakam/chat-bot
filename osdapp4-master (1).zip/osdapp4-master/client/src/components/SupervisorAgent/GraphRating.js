import React, { useEffect, useState } from "react"
import {
  ComposedChart,
  Line,
  Area,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts"
import { makeStyles } from "@material-ui/core/styles"
import Paper from "@material-ui/core/Paper"
import Typography from "@material-ui/core/Typography"

const init = [
  {
    name: "9h",
    stars5: 60,
    stars4: 20,
    stars3: 10,
    stars2: 5,
    stars1: 5,
    average: 3,
  },
  {
    name: "10h",
    stars5: 140,
    stars4: 50,
    stars3: 30,
    stars2: 15,
    stars1: 5,
    average: 4,
  },
  {
    name: "11h",
    stars5: 80,
    stars4: 60,
    stars3: 40,
    stars2: 25,
    stars1: 15,
    average: 3.5,
  },
  {
    name: "12h",
    stars5: 10,
    stars4: 5,
    stars3: 0,
    stars2: 1,
    stars1: 2,
    average: 4.8,
  },
  {
    name: "13h",
    stars5: 60,
    stars4: 20,
    stars3: 10,
    stars2: 5,
    stars1: 5,
    average: 3,
  },
  {
    name: "14h",
    stars5: 140,
    stars4: 50,
    stars3: 30,
    stars2: 15,
    stars1: 5,
    average: 4,
  },
  {
    name: "15h",
    stars5: 80,
    stars4: 60,
    stars3: 40,
    stars2: 25,
    stars1: 15,
    average: 3.5,
  },
  {
    name: "16h",
    stars5: 20,
    stars4: 5,
    stars3: 3,
    stars2: 5,
    stars1: 5,
    average: 4.8,
  },
  {
    name: "17h",
    stars5: 80,
    stars4: 20,
    stars3: 10,
    stars2: 5,
    stars1: 0,
    average: 4,
  },
  {
    name: "18h",
    stars5: 60,
    stars4: 20,
    stars3: 10,
    stars2: 5,
    stars1: 5,
    average: 3,
  },
]

const useStyles = makeStyles((theme) => ({
  root: {
    padding: theme.spacing(3, 2),
    margin: theme.spacing(1),
  },
  title: {
    padding: theme.spacing(0, 3),
  },
}))

const Graph1 = ({ calculation, isMore1390 }) => {
  const [transformedData, settransformedData] = useState(init)
  const classes = useStyles()

  // useEffect(() => {
  //   calculation.ratings.toTable() &&
  //     console.log(
  //       "--- TO TABLE ---",
  //       settransformedData(calculation.ratings.toTable())
  //     )
  // }, [calculation.ratings])

  return (
    <Paper className={classes.root}>
      <Typography variant="h5" className={classes.title} gutterBottom>
        AGENT RATING
      </Typography>
      <ComposedChart
        width={isMore1390 ? 510 : 385}
        height={isMore1390 ? 400 : 250}
        data={
          calculation.ratings.toTable()
            ? calculation.ratings.toTable()
            : transformedData
        }
      >
        <CartesianGrid stroke="#f5f5f5" />
        <XAxis
          dataKey="name"
          //   label={{ value: "Dates", position: "insideBottomRight", offset: 0 }}
        />
        <YAxis />
        <YAxis
          yAxisId="right"
          type="number"
          dataKey="average"
          name="average rating"
          orientation="right"
          ticks={[0, 1, 2, 3, 4, 5]}
          height={50}
        />
        <Tooltip />
        <Legend />

        <Bar dataKey="stars1" stackId="a" fill="#fa6b8d" />
        <Bar dataKey="stars2" stackId="a" fill="#ffb366" />

        <Bar dataKey="stars3" stackId="a" fill="#2b4e80" />

        <Bar dataKey="stars4" stackId="a" fill="#369fe0" />

        <Bar dataKey="stars5" stackId="a" fill="#51c9b8" />
        <Line
          strokeWidth={4}
          yAxisId={"right"}
          type="monotone"
          dataKey="average"
          stroke="#7fc722"
        />
      </ComposedChart>
    </Paper>
  )
}

export default Graph1
