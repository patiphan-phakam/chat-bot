import React, { useState } from "react"
import Typography from "@material-ui/core/Typography"
import MoreVertButton from "@material-ui/icons/MoreVert"
import IconButton from "@material-ui/core/IconButton"

const HeaderChat = () => {
  const [openMenu, setopenMenu] = useState(false)
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center"
      }}
    >
      <Typography variant="h6" gutterBottom>
        LIVE CHAT
      </Typography>
      <div style={{ position: "relative" }}>
        <IconButton aria-label="menu" onClick={() => setopenMenu(!openMenu)}>
          <MoreVertButton />
        </IconButton>
        {openMenu && (
          <div
            style={{
              position: "absolute",
              background: "#ff1f3d",
              color: "white",
              padding: 10,
              borderRadius: 5,
              cursor: "pointer"
            }}
          >
            Alert
          </div>
        )}
      </div>
    </div>
  )
}

export default HeaderChat
