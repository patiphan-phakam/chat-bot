import React from "react"
import { makeStyles } from "@material-ui/core/styles"
import Paper from "@material-ui/core/Paper"
import InputChat from "./InputChat"
import HeaderChat from "./HeaderChat"
import Content from "./Content"

const useStyles = makeStyles(theme => ({
  root: {
    padding: theme.spacing(3, 2),
    margin: theme.spacing(1),
    color: "#757575",
    display: "flex",
    flexDirection: "column",
    width: 350,
    maxHeight: 550
  }
}))

const ChatContent = ({ supervisorReducer, _unlockChat, unlockChat }) => {
  const classes = useStyles()
  return (
    <Paper className={classes.root}>
      <HeaderChat />
      <Content supervisorReducer={supervisorReducer} />
      <InputChat _unlockChat={_unlockChat} unlockChat={unlockChat} />
    </Paper>
  )
}

export default ChatContent
