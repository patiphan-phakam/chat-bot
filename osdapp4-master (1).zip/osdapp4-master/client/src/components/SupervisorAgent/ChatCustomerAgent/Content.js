import React from "react"
import Avatar from "@material-ui/core/Avatar"
import dateFormat from "dateformat"

const MsgAgent = ({ message, time }) => {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "flex-end",
        width: "100%",
        margin: "10px 0px"
      }}
    >
      <div
        style={{
          marginRight: 5,
          borderRadius: 5,
          background: "#78afd6",
          padding: 5,
          color: "black",
          maxWidth: "73%"
        }}
      >
        <div style={{ fontWeight: "bold" }}>Agent</div>
        {message}
      </div>
      <div>
        <Avatar>A</Avatar>
        <div>{time}</div>
      </div>
    </div>
  )
}

const MsgSupervisor = ({ message, time }) => {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "flex-start",
        width: "100%",
        margin: "10px 0px"
      }}
    >
      <div>
        <Avatar>C</Avatar>
        <div>{time}</div>
      </div>

      <div
        style={{
          marginLeft: 5,
          borderRadius: 5,
          background: "#ffd66e",
          padding: 5,
          color: "black",
          maxWidth: "73%"
        }}
      >
        <div style={{ fontWeight: "bold" }}>Customer</div>
        {message}
      </div>
    </div>
  )
}

const Content = ({ supervisorReducer }) => {
  return (
    <div
      style={{
        overflowY: "scroll",
        height: "calc(100vh - 335px)",
        paddingRight: "15px"
      }}
    >
      {supervisorReducer &&
        supervisorReducer.flow.map(({ author, msg, type, date }) => {
          if (author !== "agent")
            return (
              <MsgSupervisor
                author={"customer"}
                message={msg}
                time={dateFormat(date, "HH:MM")}
              />
            )
          return (
            <MsgAgent
              message={msg}
              author={"agent"}
              time={dateFormat(date, "HH:MM")}
            />
          )
        })}
    </div>
  )
}

export default Content
