import React from "react"
import Avatar from "@material-ui/core/Avatar"

const MsgAgent = (message, time) => {
  return (
    <div style={{ display: "flex", justifyContent: "flex-end" }}>
      <div>
        <Avatar>A</Avatar>
        <div>{time}</div>
      </div>

      <div>{message}</div>
    </div>
  )
}

export default MsgAgent
