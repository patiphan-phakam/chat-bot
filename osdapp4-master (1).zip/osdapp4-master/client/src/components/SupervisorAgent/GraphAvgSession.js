import React, { useState, useEffect } from "react"
import dateFormat from "date-format"
import { makeStyles } from "@material-ui/core/styles"
import Paper from "@material-ui/core/Paper"
import Typography from "@material-ui/core/Typography"
import {
  ComposedChart,
  Line,
  Area,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts"

const init = [
  {
    hour: 9,
    counter: 0,
    name: "9h",
    avg_session_time: 0,
    averageWaitingTime: 0,
  },
  {
    hour: 10,
    counter: 0,
    name: "10h",
    avg_session_time: 0,
    averageWaitingTime: 0,
  },
  {
    hour: 11,
    counter: 0,
    name: "11h",
    avg_session_time: 0,
    averageWaitingTime: 0,
  },
  {
    hour: 12,
    counter: 0,
    name: "12h",
    avg_session_time: 0,
    averageWaitingTime: 0,
  },
  {
    hour: 13,
    counter: 0,
    name: "13h",
    avg_session_time: 0,
    averageWaitingTime: 0,
  },
  {
    hour: 14,
    counter: 0,
    name: "14h",
    avg_session_time: 0,
    averageWaitingTime: 0,
  },
  {
    hour: 15,
    counter: 0,
    name: "15h",
    avg_session_time: 0,
    averageWaitingTime: 0,
  },
  {
    hour: 16,
    counter: 0,
    name: "16h",
    avg_session_time: 0,
    averageWaitingTime: 0,
  },
  {
    hour: 17,
    counter: 0,
    name: "17h",
    avg_session_time: 0,
    averageWaitingTime: 0,
  },
  {
    hour: 18,
    counter: 0,
    name: "18h",
    avg_session_time: 0,
    averageWaitingTime: 0,
  },
]

const useStyles = makeStyles((theme) => ({
  root: {
    padding: theme.spacing(3, 2),
    margin: theme.spacing(1),
  },
  title: {
    padding: theme.spacing(0, 3),
  },
}))

const tickComp = (sec) => {
  const date = new Date(sec * 1000)

  return dateFormat("mm:ss", date)
}

const GraphWaiting = ({ calculation, isMore1390 }) => {
  const [transformedData, settransformedData] = useState(init)
  const classes = useStyles()

  useEffect(() => {
    const stackInObj = Object.entries(
      calculation.status.groupBy(
        calculation.status.keyFilter("busy").map((x) => {
          return { ...x, time: Number(dateFormat("hh", new Date(x.start))) }
        }),
        "time"
      )
    )

    // TODO BY BLOCK TAKE AND AND ADD OR DO ARR []
    const withoutBlock = transformedData.filter(
      (x) => !stackInObj.some((e) => Number(e[0]) === x.hour)
    )

    const toto = stackInObj.map((x) => ({
      name: `${x[0]}h`,
      hour: Number(x[0]),
      counter: x[1].length,
      avg_session_time: Math.round(
        x[1].reduce((acc, obj) => acc + obj.duration, 0) / x[1].length / 1000
      ),
    }))
    settransformedData(
      [...withoutBlock, ...toto].sort((a, b) => a.hour - b.hour)
    )
  }, [calculation.status])

  return (
    <Paper className={classes.root}>
      <Typography variant="h5" className={classes.title} gutterBottom>
        AVERAGE SESSION TIME
      </Typography>
      <ComposedChart
        width={isMore1390 ? 475 : 385}
        height={isMore1390 ? 400 : 250}
        data={transformedData}
      >
        <CartesianGrid stroke="#f5f5f5" />
        <XAxis interval={0} dataKey="name" />
        <YAxis tickFormatter={tickComp} dataKey="avg_session_time" />
        <Tooltip formatter={tickComp} />
        <Legend />
        <Bar dataKey="avg_session_time" stackId="a" fill="#ffb366" />
      </ComposedChart>
    </Paper>
  )
}

export default GraphWaiting
