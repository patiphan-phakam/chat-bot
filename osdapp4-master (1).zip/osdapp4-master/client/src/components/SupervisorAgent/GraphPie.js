import React, { useState, useEffect } from "react"
import { PieChart, Pie, Sector, Cell } from "recharts"
import { makeStyles } from "@material-ui/core/styles"
import Paper from "@material-ui/core/Paper"
import Typography from "@material-ui/core/Typography"
import TrendingUp from "@material-ui/icons/TrendingUp"
import TrendingDown from "@material-ui/icons/TrendingDown"
import dateFormat from "date-format"

const useStyles = makeStyles((theme) => ({
  root: {
    padding: theme.spacing(3, 2),
    margin: theme.spacing(1),
  },
  title: {
    padding: theme.spacing(0, 3),
  },
}))

const renderActiveShape = (props) => {
  const RADIAN = Math.PI / 180
  const {
    cx,
    cy,
    midAngle,
    innerRadius,
    outerRadius,
    startAngle,
    endAngle,
    fill,
    payload,
    percent,
    value,
    name,
  } = props

  const sin = Math.sin(-RADIAN * midAngle)
  const cos = Math.cos(-RADIAN * midAngle)
  const sx = cx + (outerRadius + 10) * cos
  const sy = cy + (outerRadius + 10) * sin
  const mx = cx + (outerRadius + 30) * cos
  const my = cy + (outerRadius + 30) * sin
  const ex = mx + (cos >= 0 ? 1 : -1) * 22
  const ey = my
  const textAnchor = cos >= 0 ? "start" : "end"

  return (
    <g>
      <text
        x={cx}
        y={cy}
        dy={8}
        textAnchor="middle"
        fill={fill}
        style={{ fontSize: 16, fontWeight: 550 }}
      >
        {payload.name}
      </text>
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius}
        outerRadius={outerRadius}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
      />
      <Sector
        cx={cx}
        cy={cy}
        startAngle={startAngle}
        endAngle={endAngle}
        innerRadius={outerRadius + 6}
        outerRadius={outerRadius + 10}
        fill={fill}
      />
      <path
        d={`M${sx},${sy}L${mx},${my}L${ex},${ey}`}
        stroke={fill}
        fill="none"
      />
      <circle cx={ex} cy={ey} r={2} fill={fill} stroke="none" />
      <text
        x={ex + (cos >= 0 ? 1 : -1) * 12}
        y={ey}
        textAnchor={textAnchor}
        fill="#333"
      >{`${name}`}</text>
      <text
        x={ex + (cos >= 0 ? 1 : -1) * 12}
        y={ey}
        dy={18}
        textAnchor={textAnchor}
        fill="#999"
      >
        {`(Rate ${(percent * 100).toFixed(2)}%)`}
      </text>
    </g>
  )
}
const COLORS = ["#51c9b8", "#7980e0", "#fa6b8d"]

const GraphPie = ({ calculation, isMore1390 }) => {
  const classes = useStyles()
  const [transformedData, settransformedData] = useState([
    { name: "wrapup1", average: 0 },
    { name: "wrapup2", average: 0 },
    { name: "wrapup3", average: 0 },
  ])
  const [activeIndex, setActiveIndex] = useState(0)
  const onPieEnter = (data, index) => {
    setActiveIndex(index)
  }

  useEffect(() => {
    const byKeys = calculation.status.groupBy(
      calculation.status.keyFilter("wrapup"),
      "wrapupType"
    )

    const totalDuration = 100 / calculation.status.keyFilter("wrapup").length

    const data = Object.entries(byKeys).map((x) => {
      return {
        name: x[0],
        average: x[1].length * totalDuration,
      }
    })

    settransformedData(data)
  }, [calculation.status])

  return (
    <Paper className={classes.root}>
      <Typography variant="h5" className={classes.title} gutterBottom>
        WRAPUP STATUS
      </Typography>
      <PieChart width={isMore1390 ? 440 : 385} height={isMore1390 ? 360 : 185}>
        <Pie
          activeIndex={activeIndex}
          activeShape={renderActiveShape}
          data={transformedData}
          cx={isMore1390 ? 220 : 180}
          cy={isMore1390 ? 160 : 80}
          innerRadius={isMore1390 ? 60 : 40}
          outerRadius={isMore1390 ? 80 : 50}
          fill="#8884d8"
          dataKey="average"
          onMouseEnter={onPieEnter}
        >
          {transformedData.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
      </PieChart>
      <div style={{ width: "100%", display: "flex" }}>
        {transformedData.map(({ name, average }, index) => (
          <div style={{ width: "100%", textAlign: "center" }}>
            {index === 0 ? (
              <TrendingUp
                style={{ color: COLORS[index], fontSize: isMore1390 ? 50 : 30 }}
              />
            ) : (
              <TrendingDown
                style={{ color: COLORS[index], fontSize: isMore1390 ? 50 : 30 }}
              />
            )}
            <Typography variant={isMore1390 ? "h5" : "body1"}>
              {average.toFixed()}%
            </Typography>
            <div>{name}</div>
          </div>
        ))}
      </div>
    </Paper>
  )
}

export default GraphPie
