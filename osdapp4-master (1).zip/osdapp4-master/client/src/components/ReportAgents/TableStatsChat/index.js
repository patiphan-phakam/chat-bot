import React, { useState } from "react"
import Typography from "@material-ui/core/Typography"
import { KeyboardDatePicker } from "@material-ui/pickers"
import InputLabel from "@material-ui/core/InputLabel"
import MenuItem from "@material-ui/core/MenuItem"
import { makeStyles } from "@material-ui/core/styles"
import FormControl from "@material-ui/core/FormControl"
import Select from "@material-ui/core/Select"
import Button from "@material-ui/core/Button"
import SearchIcon from "@material-ui/icons/Search"
import SaveAltIcon from "@material-ui/icons/SaveAlt"
import TableStats from "./TableStats"
import { CSVLink, CSVDownload } from "react-csv"
import dateformat from "dateformat"
import TextField from "@material-ui/core/TextField"

const useStyles = makeStyles((theme) => ({
  main: {
    background: "white",
    padding: theme.spacing(1),
    borderRadius: 5,
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  btn: {
    margin: theme.spacing(1),
  },
  btnAgent: {
    margin: theme.spacing(1),
    height: "56px",
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
  input: { margin: 5 },
}))

function msToTime(duration) {
  if (duration) {
    var milliseconds = parseInt((duration % 1000) / 100),
      seconds = Math.floor((duration / 1000) % 60),
      minutes = Math.floor((duration / (1000 * 60)) % 60),
      hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

    hours = hours < 10 ? "0" + hours : hours
    minutes = minutes < 10 ? "0" + minutes : minutes
    seconds = seconds < 10 ? "0" + seconds : seconds
    return hours + ":" + minutes + ":" + seconds
  } else {
    return "00:00:00"
  }
}

export default ({
  reducer,
  _selectDates,
  _search,
  datesInput,
  _searchChatReport,
}) => {
  const classes = useStyles()
  const [chatState, setChatState] = useState({
    skill: null,
    source: null,
    agent: null,
    customerid: null,
    customername: null,
    chatid: null,
    status: null,
    duration: null,
  })

  const _handleChange = (k, v) => setChatState({ ...chatState, [k]: v })

  const {
    skill,
    source,
    agent,
    customerid,
    customername,
    chatid,
    status,
    duration,
  } = chatState

  return (
    <div className={classes.formControl}>
      <Typography variant="h4" gutterBottom>
        Agents chat report
      </Typography>
      <div style={{ borderBottom: "2px solid rgb(190, 190, 190)" }} />
      <div style={{ paddingTop: 14 }}>
        <KeyboardDatePicker
          className={classes.formControl}
          placeholder="2018/10/10"
          value={datesInput.startDate}
          onChange={(date) => _selectDates("startDate", date)}
          format="yyyy/MM/dd"
          inputVariant="outlined"
          label="Start Date"
        />

        <KeyboardDatePicker
          className={classes.formControl}
          placeholder="2018/10/10"
          value={datesInput.endDate}
          onChange={(date) => _selectDates("endDate", date)}
          format="yyyy/MM/dd"
          inputVariant="outlined"
          label="End Date"
        />
        <FormControl variant="outlined" className={classes.formControl}>
          <InputLabel id="demo-simple-select-outlined-label">Skill</InputLabel>
          <Select
            labelId="demo-simple-select-outlined-label"
            id="demo-simple-select-outlined"
            value={skill}
            onChange={(e) => _handleChange("skill", e.target.value)}
            label="Skill"
          >
            <MenuItem value={null}>All</MenuItem>
            <MenuItem value={"skill1"}>Skill 1</MenuItem>
            <MenuItem value={"skill2"}>Skill 2</MenuItem>
            <MenuItem value={"skill3"}>Skill 3</MenuItem>
            <MenuItem value={"skill4"}>Skill 4</MenuItem>
            <MenuItem value={"skill5"}>Skill 5</MenuItem>
          </Select>
        </FormControl>
        <FormControl variant="outlined" className={classes.formControl}>
          <InputLabel id="demo-simple-select-outlined-label">Source</InputLabel>
          <Select
            labelId="demo-simple-select-outlined-label"
            id="demo-simple-select-outlined"
            value={source}
            onChange={(e) => _handleChange("source", e.target.value)}
            label="Source"
          >
            <MenuItem value={null}>All</MenuItem>
            <MenuItem value={"messenger"}>Messenger</MenuItem>
            <MenuItem value={"line"}>Line</MenuItem>
          </Select>
        </FormControl>
        <FormControl variant="outlined" className={classes.formControl}>
          <InputLabel id="demo-simple-select-outlined-label">Agent</InputLabel>

          <Select
            value={agent}
            onChange={(e) => {
              _handleChange("agent", e.target.value)
            }}
            label="agents"
          >
            <MenuItem value={null}>All</MenuItem>
            {reducer.listAgents.map((x, i) => (
              <MenuItem key={x._id} value={x._id}>
                {x.name}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <TextField
          className={classes.formControl}
          label="Customer ID"
          variant="outlined"
          onChange={(e) => _handleChange("customerid", e.target.value)}
        />
        <TextField
          className={classes.formControl}
          label="Customer Name"
          variant="outlined"
          onChange={(e) => _handleChange("customername", e.target.value)}
        />
        <TextField
          className={classes.formControl}
          label="Chat ID"
          variant="outlined"
          onChange={(e) => _handleChange("chatid", e.target.value)}
        />
        <FormControl variant="outlined" className={classes.formControl}>
          <InputLabel id="demo-simple-select-outlined-label">Status</InputLabel>

          <Select
            value={status}
            onChange={(e) => _handleChange("status", e.target.value)}
            label="agents"
          >
            <MenuItem value={null}>All</MenuItem>
            <MenuItem value={"wrapup1"}>Wrapup 1</MenuItem>
            <MenuItem value={"wrapup2"}>Wrapup 2</MenuItem>
            <MenuItem value={"wrapup3"}>Wrapup 3</MenuItem>
          </Select>
        </FormControl>
        <TextField
          className={classes.formControl}
          label="Duration >="
          variant="outlined"
          type="number"
          onChange={(e) => _handleChange("duration", e.target.value)}
        />
      </div>
      <div style={{ display: "flex", wrap: "wrap", justifyContent: "center" }}>
        <Button
          startIcon={<SearchIcon />}
          className={classes.btn}
          variant="contained"
          color="primary"
          onClick={() => {
            let query = ""
            Object.entries(chatState).map((x) => {
              if (x[1]) {
                query =
                  query + `${query.length === 0 ? "?" : "&"}${x[0]}=${x[1]}`
              }
            })
            _searchChatReport(query)
          }}
        >
          Search
        </Button>
      </div>
      <TableStats data={reducer.chatReport} />
    </div>
  )
}
