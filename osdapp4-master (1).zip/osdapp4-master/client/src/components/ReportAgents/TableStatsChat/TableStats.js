import React, { useState } from "react"
import Typography from "@material-ui/core/Typography"
import { makeStyles, useTheme } from "@material-ui/core/styles"
import Table from "@material-ui/core/Table"
import TableBody from "@material-ui/core/TableBody"
import TableCell from "@material-ui/core/TableCell"
import TableContainer from "@material-ui/core/TableContainer"
import TableHead from "@material-ui/core/TableHead"
import TableRow from "@material-ui/core/TableRow"
import dateFormat from "dateformat"

import TableFooter from "@material-ui/core/TableFooter"
import TablePagination from "@material-ui/core/TablePagination"
import IconButton from "@material-ui/core/IconButton"
import FirstPageIcon from "@material-ui/icons/FirstPage"
import KeyboardArrowLeft from "@material-ui/icons/KeyboardArrowLeft"
import KeyboardArrowRight from "@material-ui/icons/KeyboardArrowRight"
import LastPageIcon from "@material-ui/icons/LastPage"

const useStyles1 = makeStyles((theme) => ({
  root: {
    flexShrink: 0,
    marginLeft: theme.spacing(2.5),
  },
}))

function TablePaginationActions(props) {
  const classes = useStyles1()
  const theme = useTheme()
  const { count, page, rowsPerPage, onChangePage } = props

  const handleFirstPageButtonClick = (event) => {
    onChangePage(event, 0)
  }

  const handleBackButtonClick = (event) => {
    onChangePage(event, page - 1)
  }

  const handleNextButtonClick = (event) => {
    onChangePage(event, page + 1)
  }

  const handleLastPageButtonClick = (event) => {
    onChangePage(event, Math.max(0, Math.ceil(count / rowsPerPage) - 1))
  }

  return (
    <div className={classes.root}>
      <IconButton
        onClick={handleFirstPageButtonClick}
        disabled={page === 0}
        aria-label="first page"
      >
        {theme.direction === "rtl" ? <LastPageIcon /> : <FirstPageIcon />}
      </IconButton>
      <IconButton
        onClick={handleBackButtonClick}
        disabled={page === 0}
        aria-label="previous page"
      >
        {theme.direction === "rtl" ? (
          <KeyboardArrowRight />
        ) : (
          <KeyboardArrowLeft />
        )}
      </IconButton>
      <IconButton
        onClick={handleNextButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="next page"
      >
        {theme.direction === "rtl" ? (
          <KeyboardArrowLeft />
        ) : (
          <KeyboardArrowRight />
        )}
      </IconButton>
      <IconButton
        onClick={handleLastPageButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="last page"
      >
        {theme.direction === "rtl" ? <FirstPageIcon /> : <LastPageIcon />}
      </IconButton>
    </div>
  )
}

function msToTime(duration) {
  if (duration) {
    var milliseconds = parseInt((duration % 1000) / 100),
      seconds = Math.floor((duration / 1000) % 60),
      minutes = Math.floor((duration / (1000 * 60)) % 60),
      hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

    hours = hours < 10 ? "0" + hours : hours
    minutes = minutes < 10 ? "0" + minutes : minutes
    seconds = seconds < 10 ? "0" + seconds : seconds
    return hours + ":" + minutes + ":" + seconds
  } else {
    return "00:00:00"
  }
}

const useStyles = makeStyles({
  table: {
    minWidth: 650,
    width: "100%",
    maxWidth: "88vw",
  },
  rowTitle: {
    fontWeight: "bold",
  },
})

export default ({ data }) => {
  const classes = useStyles()
  const [page, setPage] = useState(0)
  const [rowsPerPage, setRowsPerPage] = useState(5)

  const handleChangePage = (event, newPage) => {
    setPage(newPage)
  }

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10))
    setPage(0)
  }
  return (
    <div>
      <Typography variant="h6" gutterBottom>
        Agent Details
      </Typography>

      <TableContainer className={classes.table}>
        <Table>
          <TableHead>
            <TableRow style={{ background: "#f2f2f2" }}>
              <TableCell className={classes.rowTitle} align="center">
                No.
              </TableCell>
              <TableCell className={classes.rowTitle} align="center">
                Date
              </TableCell>
              <TableCell className={classes.rowTitle} align="center">
                Agent ID
              </TableCell>
              <TableCell className={classes.rowTitle} align="center">
                Agent Name
              </TableCell>
              <TableCell className={classes.rowTitle} align="center">
                Chat ID
              </TableCell>
              <TableCell className={classes.rowTitle} align="center">
                Customer ID
              </TableCell>
              <TableCell className={classes.rowTitle} align="center">
                Customer name
              </TableCell>
              <TableCell className={classes.rowTitle} align="center">
                Source
              </TableCell>
              <TableCell className={classes.rowTitle} align="center">
                Status
              </TableCell>
              <TableCell className={classes.rowTitle} align="center">
                Duration
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {data.map((row, i) => {
              return (
                <TableRow key={row._id}>
                  <TableCell align="center" component="th" scope="row">
                    {i + 1}
                  </TableCell>
                  <TableCell style={{ minWidth: 120 }} align="center">
                    {dateFormat(row.date, "yyyy-mm-dd")}
                  </TableCell>
                  <TableCell align="center">{row.agentid}</TableCell>
                  <TableCell align="center">{row.agentname}</TableCell>
                  <TableCell align="center">{row.chatid}</TableCell>
                  <TableCell align="center">{row.customerid}</TableCell>
                  <TableCell align="center">{row.customername}</TableCell>
                  <TableCell align="center">{row.source}</TableCell>
                  <TableCell align="center">{row.status}</TableCell>
                  <TableCell align="center">{msToTime(row.duration)}</TableCell>
                </TableRow>
              )
            })}
          </TableBody>
          {data.length !== 0 && (
            <TableFooter>
              <TableRow>
                <TablePagination
                  style={{ minWidth: 500 }}
                  rowsPerPageOptions={[5, 10, 25, { label: "All", value: -1 }]}
                  colSpan={3}
                  count={2}
                  rowsPerPage={rowsPerPage}
                  page={page}
                  SelectProps={{
                    inputProps: { "aria-label": "rows per page" },
                    native: true,
                  }}
                  onChangePage={handleChangePage}
                  onChangeRowsPerPage={handleChangeRowsPerPage}
                  ActionsComponent={TablePaginationActions}
                />
              </TableRow>
            </TableFooter>
          )}
        </Table>
      </TableContainer>
    </div>
  )
}
