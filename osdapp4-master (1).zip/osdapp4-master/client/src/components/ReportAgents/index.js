import React from "react"
import TableStatsGlobal from "./TableStatsGlobal"
import TableStatsByDate from "./TableStatsByDate"
import TableStatsChat from "./TableStatsChat"
import queryString from "query-string"

export default ({
  reducer,
  _selectDates,
  _search,
  datesInput,
  _searchOneAgent,
  _searchChatReport,
}) => {
  const { tab } = queryString.parse(window.location.search)
  if (tab === "global")
    return (
      <TableStatsGlobal
        _selectDates={_selectDates}
        _search={_search}
        datesInput={datesInput}
        reducer={reducer}
      />
    )
  if (tab === "bydate")
    return (
      <TableStatsByDate
        _selectDates={_selectDates}
        datesInput={datesInput}
        reducer={reducer}
        _searchOneAgent={_searchOneAgent}
      />
    )

  if (tab === "chat")
    return (
      <TableStatsChat
        _selectDates={_selectDates}
        datesInput={datesInput}
        reducer={reducer}
        _searchChatReport={_searchChatReport}
      />
    )

  return <div>empty</div>
}
