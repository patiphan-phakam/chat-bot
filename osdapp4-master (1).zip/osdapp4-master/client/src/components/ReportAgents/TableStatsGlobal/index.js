import React, { useState } from "react"
import Typography from "@material-ui/core/Typography"
import { KeyboardDatePicker } from "@material-ui/pickers"
import InputLabel from "@material-ui/core/InputLabel"
import MenuItem from "@material-ui/core/MenuItem"
import { makeStyles } from "@material-ui/core/styles"
import FormControl from "@material-ui/core/FormControl"
import Select from "@material-ui/core/Select"
import Button from "@material-ui/core/Button"
import SearchIcon from "@material-ui/icons/Search"
import SaveAltIcon from "@material-ui/icons/SaveAlt"
import TableStats from "./TableStats"
import { CSVLink, CSVDownload } from "react-csv"
import DialogSelectAgents from "./DialogSelectAgents"
import dateformat from "dateformat"

const useStyles = makeStyles((theme) => ({
  main: {
    background: "white",
    padding: theme.spacing(1),
    borderRadius: 5,
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  btn: {
    margin: theme.spacing(1),
  },
  btnAgent: {
    margin: theme.spacing(1),
    height: "56px",
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
  input: { margin: 5 },
}))

const skillsLit = ["all", "skill1", "skill2", "skill3", "skill4", "skill5"]
const agentsList = [
  {
    _id: "5ddc93d61c9d440000e2c6ba",
    email: "1agentskill1skill2@gmail.com",
    skills: ["skill1", "skill2"],
    name: "james",
  },
  {
    _id: "5ddc93d61c9d440000e2c6bf",
    email: "1agentskill1skill2@gmail.com",
    skills: ["skill1", "skill3"],
    name: "james2",
  },
  {
    _id: "5ddc93d61c9d440000e2d6ba",
    email: "1agentskill1skill2@gmail.com",
    skills: ["skill1", "skill4"],
    name: "james3",
  },
  {
    _id: "5ddc93d61c9d440000esc6ba",
    email: "1agentskill1skill2@gmail.com",
    skills: ["skill2", "skill5"],
    name: "james4",
  },
]

function msToTime(duration) {
  if (duration) {
    var milliseconds = parseInt((duration % 1000) / 100),
      seconds = Math.floor((duration / 1000) % 60),
      minutes = Math.floor((duration / (1000 * 60)) % 60),
      hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

    hours = hours < 10 ? "0" + hours : hours
    minutes = minutes < 10 ? "0" + minutes : minutes
    seconds = seconds < 10 ? "0" + seconds : seconds
    return hours + ":" + minutes + ":" + seconds
  } else {
    return "00:00:00"
  }
}

export default ({ reducer, _selectDates, _search, datesInput }) => {
  const classes = useStyles()
  const [selectedDate, handleDateChange] = useState(new Date())
  const [source, setSource] = React.useState("all")
  const [skillsSelect, setSkillsSelect] = useState("all")
  const [agentSelect, setAgentSelect] = useState(
    agentsList.map((x) => ({ ...x, check: true }))
  )
  const [dialogAgentOpen, setDialogAgentOpen] = useState(false)

  const _selectAgent = (_id) => {
    setAgentSelect(
      agentSelect.map((x) =>
        x._id === _id
          ? x.check
            ? { ...x, check: false }
            : { ...x, check: true }
          : x
      )
    )
  }

  const _selectAll = () => {
    setAgentSelect(agentSelect.map((x) => ({ ...x, check: true })))
  }
  const _unselectAll = () => {
    setAgentSelect(agentSelect.map((x) => ({ ...x, check: false })))
  }

  return (
    <div className={classes.formControl}>
      <Typography variant="h4" gutterBottom>
        Agents summary report
      </Typography>
      <div style={{ borderBottom: "2px solid rgb(190, 190, 190)" }} />
      <div style={{ paddingTop: 14 }}>
        <KeyboardDatePicker
          className={classes.formControl}
          placeholder="2018/10/10"
          value={datesInput.startDate}
          onChange={(date) => _selectDates("startDate", date)}
          format="yyyy/MM/dd"
          inputVariant="outlined"
          label="Start Date"
        />

        <KeyboardDatePicker
          className={classes.formControl}
          placeholder="2018/10/10"
          value={datesInput.endDate}
          onChange={(date) => _selectDates("endDate", date)}
          format="yyyy/MM/dd"
          inputVariant="outlined"
          label="End Date"
        />
        <FormControl variant="outlined" className={classes.formControl}>
          <InputLabel id="demo-simple-select-outlined-label">Source</InputLabel>
          <Select
            labelId="demo-simple-select-outlined-label"
            id="demo-simple-select-outlined"
            value={source}
            onChange={(e) => setSource(e.target.value)}
            label="Source"
          >
            <MenuItem value="all">All</MenuItem>
            <MenuItem value={"messenger"}>Messenger</MenuItem>
            <MenuItem value={"line"}>Line</MenuItem>
          </Select>
        </FormControl>
        <FormControl variant="outlined" className={classes.formControl}>
          <InputLabel id="demo-simple-select-outlined-label">Skills</InputLabel>
          <Select
            value={skillsSelect}
            onChange={(e) => {
              setSkillsSelect(e.target.value)
            }}
            label="Skills"
          >
            {skillsLit.map((x, i) => (
              <MenuItem key={i} value={x}>
                {x}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <Button
          className={classes.btnAgent}
          variant="outlined"
          onClick={() => setDialogAgentOpen(true)}
        >
          Agents
        </Button>
      </div>
      <div style={{ display: "flex", wrap: "wrap", justifyContent: "center" }}>
        <Button
          startIcon={<SearchIcon />}
          className={classes.btn}
          variant="contained"
          color="primary"
          onClick={_search}
        >
          Search
        </Button>
        {Object.keys(reducer.listAgents[0]).length !== 0 && (
          <CSVLink
            data={
              skillsSelect === "all"
                ? reducer.listAgents.map(({ _id, name, stats_total }) => {
                    return {
                      ID_agent: _id,
                      name,
                      answered: stats_total
                        ? source === "all"
                          ? stats_total.messenger.answered +
                            stats_total.line.answered
                          : stats_total[source].answered
                        : "",
                      notAnswered: stats_total
                        ? source === "all"
                          ? stats_total.messenger.notAnswered +
                            stats_total.line.notAnswered
                          : stats_total[source].notAnswered
                        : "",
                      total: stats_total
                        ? source === "all"
                          ? stats_total.messenger.notAnswered +
                            stats_total.line.notAnswered +
                            stats_total.messenger.answered +
                            stats_total.line.answered
                          : stats_total[source].notAnswered +
                            stats_total[source].answered
                        : "",
                      chatTime: stats_total
                        ? source === "all"
                          ? msToTime(
                              stats_total.messenger.chatTime +
                                stats_total.line.chatTime
                            )
                          : msToTime(stats_total[source].chatTime)
                        : "",
                      avgChatTime: stats_total
                        ? source === "all"
                          ? msToTime(
                              stats_total.messenger.chatTime +
                                stats_total.line.chatTime /
                                  (stats_total.messenger.answered +
                                    stats_total.line.answered)
                            )
                          : msToTime(
                              stats_total[source].chatTime /
                                stats_total[source].answered
                            )
                        : "",
                    }
                  })
                : reducer.listAgents.filter((x) =>
                    x.skills.includes(skillsSelect)
                  )
            }
            style={{ textDecoration: "none" }}
          >
            <Button
              startIcon={<SaveAltIcon />}
              className={classes.btn}
              variant="outlined"
              color="primary"
            >
              export
            </Button>
          </CSVLink>
        )}
      </div>
      <TableStats
        source={source}
        data={
          skillsSelect === "all"
            ? reducer.listAgents
            : reducer.listAgents.filter((x) => x.skills.includes(skillsSelect))
        }
      />
      <DialogSelectAgents
        open={dialogAgentOpen}
        _close={() => setDialogAgentOpen(false)}
        _selectAgent={_selectAgent}
        list={agentSelect}
        _selectAll={_selectAll}
        _unselectAll={_unselectAll}
      />
    </div>
  )
}
