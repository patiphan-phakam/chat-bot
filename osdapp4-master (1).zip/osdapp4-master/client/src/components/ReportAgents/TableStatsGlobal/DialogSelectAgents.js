import React from "react"
import PropTypes from "prop-types"
import { makeStyles } from "@material-ui/core/styles"
import Button from "@material-ui/core/Button"
import Avatar from "@material-ui/core/Avatar"
import List from "@material-ui/core/List"
import ListItem from "@material-ui/core/ListItem"
import ListItemAvatar from "@material-ui/core/ListItemAvatar"
import ListItemText from "@material-ui/core/ListItemText"
import DialogTitle from "@material-ui/core/DialogTitle"
import Dialog from "@material-ui/core/Dialog"
import Divider from "@material-ui/core/Divider"

import ListItemIcon from "@material-ui/core/ListItemIcon"
import Checkbox from "@material-ui/core/Checkbox"

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    maxWidth: 360,
    backgroundColor: theme.palette.background.paper,
  },
  titleList: {
    fontWeight: "bold",
  },
}))

export default ({
  open,
  _close,
  _selectAgent,
  list,
  _selectAll,
  _unselectAll,
}) => {
  const classes = useStyles()
  return (
    <Dialog onClose={_close} aria-labelledby="simple-dialog-title" open={open}>
      <List className={classes.root}>
        <ListItem role={undefined} dense button>
          <ListItemIcon>
            <Checkbox
              edge="start"
              checked={list.every((x) => x.check)}
              tabIndex={-1}
              disableRipple
              onClick={(e) =>
                e.target.checked ? _selectAll() : _unselectAll()
              }
            />
          </ListItemIcon>
          <ListItemText
            classes={{
              primary: classes.titleList,
            }}
            primary="Select all"
          />
        </ListItem>
        <Divider />
        {list.map((x) => {
          const labelId = `checkbox-list-label-${x}`

          return (
            <ListItem key={x._id} role={undefined} dense button>
              <ListItemIcon>
                <Checkbox
                  edge="start"
                  checked={x.check}
                  onClick={() => _selectAgent(x._id)}
                  tabIndex={-1}
                  disableRipple
                  inputProps={{ "aria-labelledby": labelId }}
                />
              </ListItemIcon>
              <ListItemText id={labelId} primary={x.name} />
            </ListItem>
          )
        })}
      </List>
    </Dialog>
  )
}
