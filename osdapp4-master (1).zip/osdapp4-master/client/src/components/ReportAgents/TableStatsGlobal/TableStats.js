import React from "react"
import Typography from "@material-ui/core/Typography"
import { makeStyles } from "@material-ui/core/styles"
import Table from "@material-ui/core/Table"
import TableBody from "@material-ui/core/TableBody"
import TableCell from "@material-ui/core/TableCell"
import TableContainer from "@material-ui/core/TableContainer"
import TableHead from "@material-ui/core/TableHead"
import TableRow from "@material-ui/core/TableRow"

const sampleData = [
  {
    _id: "123",
    agentName: "nameAgent",
    answered: 123,
    notAnswered: 0,
    chatTime: 22300000,
  },
  {
    _id: "124",
    agentName: "nameAgent",
    answered: 123,
    notAnswered: 0,
    chatTime: 19230000,
  },
  {
    _id: "123",
    agentName: "nameAgent",
    answered: 123,
    notAnswered: 0,
    chatTime: 30130000,
  },
  {
    _id: "223",
    agentName: "nameAgent",
    answered: 113,
    notAnswered: 0,
    chatTime: 13530000,
  },
  {
    _id: "323",
    agentName: "nameAgent",
    answered: 123,
    notAnswered: 0,
    chatTime: 17230000,
  },
]

function msToTime(duration) {
  if (duration) {
    var milliseconds = parseInt((duration % 1000) / 100),
      seconds = Math.floor((duration / 1000) % 60),
      minutes = Math.floor((duration / (1000 * 60)) % 60),
      hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

    hours = hours < 10 ? "0" + hours : hours
    minutes = minutes < 10 ? "0" + minutes : minutes
    seconds = seconds < 10 ? "0" + seconds : seconds
    return hours + ":" + minutes + ":" + seconds
  } else {
    return "00:00:00"
  }
}

const useStyles = makeStyles({
  table: {
    minWidth: 650,
  },
  rowTitle: {
    fontWeight: "bold",
  },
})

export default ({ data, source }) => {
  const classes = useStyles()
  return (
    <div>
      <Typography variant="h6" gutterBottom>
        Summary
      </Typography>

      <TableContainer>
        <Table className={classes.table} aria-label="simple table">
          <TableHead>
            <TableRow style={{ background: "#f2f2f2" }}>
              <TableCell className={classes.rowTitle} align="center">
                No.
              </TableCell>
              <TableCell className={classes.rowTitle} align="center">
                Agent ID
              </TableCell>
              <TableCell className={classes.rowTitle} align="center">
                Agent Name
              </TableCell>
              <TableCell className={classes.rowTitle} align="center">
                Answer
              </TableCell>
              <TableCell className={classes.rowTitle} align="center">
                Not Answered
              </TableCell>
              <TableCell className={classes.rowTitle} align="center">
                Total
              </TableCell>
              <TableCell className={classes.rowTitle} align="center">
                Chat Time
              </TableCell>
              <TableCell className={classes.rowTitle} align="center">
                AVG Chat Time
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {data.map((row, i) => {
              if (
                row.stats_total &&
                row.stats_total.messenger &&
                row.stats_total.messenger.answered
              )
                return (
                  <TableRow key={row._id}>
                    <TableCell align="center" component="th" scope="row">
                      {i + 1}
                    </TableCell>
                    <TableCell align="center" component="th" scope="row">
                      {row._id}
                    </TableCell>
                    <TableCell align="center">{row.name}</TableCell>
                    <TableCell align="center">
                      {source === "all"
                        ? row.stats_total.messenger.answered +
                          row.stats_total.line.answered
                        : row.stats_total[source].answered}
                    </TableCell>
                    <TableCell align="center">
                      {source === "all"
                        ? row.stats_total.messenger.notAnswered +
                          row.stats_total.line.notAnswered
                        : row.stats_total[source].notAnswered}
                    </TableCell>
                    <TableCell align="center">
                      {source === "all"
                        ? row.stats_total.messenger.notAnswered +
                          row.stats_total.line.notAnswered +
                          row.stats_total.messenger.answered +
                          row.stats_total.line.answered
                        : row.stats_total[source].notAnswered +
                          row.stats_total[source].answered}
                    </TableCell>
                    <TableCell align="center">
                      {msToTime(
                        source === "all"
                          ? row.stats_total.messenger.chatTime +
                              row.stats_total.line.chatTime
                          : row.stats_total[source].chatTime
                      )}
                    </TableCell>
                    <TableCell align="center">
                      {msToTime(
                        source === "all"
                          ? (row.stats_total.messenger.chatTime +
                              row.stats_total.line.chatTime) /
                              (row.stats_total.messenger.answered +
                                row.stats_total.line.answered)
                          : row.stats_total[source].chatTime /
                              row.stats_total[source].answered
                      )}
                    </TableCell>
                  </TableRow>
                )
            })}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  )
}
