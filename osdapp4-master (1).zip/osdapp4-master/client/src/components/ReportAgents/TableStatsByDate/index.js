import React, { useEffect, useReducer, useState } from "react"
import Typography from "@material-ui/core/Typography"
import { KeyboardDatePicker } from "@material-ui/pickers"
import InputLabel from "@material-ui/core/InputLabel"
import MenuItem from "@material-ui/core/MenuItem"
import { makeStyles } from "@material-ui/core/styles"
import FormControl from "@material-ui/core/FormControl"
import Select from "@material-ui/core/Select"
import Button from "@material-ui/core/Button"
import SearchIcon from "@material-ui/icons/Search"
import SaveAltIcon from "@material-ui/icons/SaveAlt"
import TableStats from "./TableStats"
import { CSVLink, CSVDownload } from "react-csv"
import dateformat from "dateformat"

const useStyles = makeStyles((theme) => ({
  main: {
    background: "white",
    padding: theme.spacing(1),
    borderRadius: 5,
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  btn: {
    margin: theme.spacing(1),
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
  input: { margin: 5 },
}))

function msToTime(duration) {
  if (duration) {
    var milliseconds = parseInt((duration % 1000) / 100),
      seconds = Math.floor((duration / 1000) % 60),
      minutes = Math.floor((duration / (1000 * 60)) % 60),
      hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

    hours = hours < 10 ? "0" + hours : hours
    minutes = minutes < 10 ? "0" + minutes : minutes
    seconds = seconds < 10 ? "0" + seconds : seconds
    return hours + ":" + minutes + ":" + seconds
  } else {
    return "00:00:00"
  }
}

const skillsLit = ["skill1", "skill2", "skill3", "skill4", "skill5"]

export default ({ reducer, _selectDates, datesInput, _searchOneAgent }) => {
  const classes = useStyles()
  const [source, setSource] = React.useState("all")
  const [skillSelect, setSkillSelect] = useState("skill1")
  const [agentSelect, setagentSelect] = useState(null)

  return (
    <div className={classes.formControl}>
      <Typography variant="h4" gutterBottom>
        Agents summary report by date
      </Typography>
      <div style={{ borderBottom: "2px solid rgb(190, 190, 190)" }} />
      <div style={{ paddingTop: 14 }}>
        <KeyboardDatePicker
          className={classes.formControl}
          placeholder="2018/10/10"
          value={datesInput.startDate}
          onChange={(date) => _selectDates("startDate", date)}
          format="yyyy/MM/dd"
          inputVariant="outlined"
          label="Start Date"
          maxDate={new Date()}
        />

        <KeyboardDatePicker
          className={classes.formControl}
          placeholder="2018/10/10"
          value={datesInput.endDate}
          onChange={(date) => _selectDates("endDate", date)}
          format="yyyy/MM/dd"
          inputVariant="outlined"
          label="End Date"
          maxDate={new Date()}
        />
        <FormControl variant="outlined" className={classes.formControl}>
          <InputLabel id="demo-simple-select-outlined-label">Source</InputLabel>
          <Select
            labelId="demo-simple-select-outlined-label"
            id="demo-simple-select-outlined"
            value={source}
            onChange={(e) => setSource(e.target.value)}
            label="Source"
          >
            <MenuItem value="all">All</MenuItem>
            <MenuItem value={"messenger"}>Messenger</MenuItem>
            <MenuItem value={"line"}>Line</MenuItem>
          </Select>
        </FormControl>
        <FormControl variant="outlined" className={classes.formControl}>
          <InputLabel>Skill</InputLabel>
          <Select
            value={skillSelect}
            onChange={(e) => {
              setSkillSelect(e.target.value)
            }}
            label="Skill"
          >
            {skillsLit.map((x) => (
              <MenuItem value={x}>{x}</MenuItem>
            ))}
          </Select>
        </FormControl>
        <FormControl variant="outlined" className={classes.formControl}>
          <InputLabel>Agents</InputLabel>
          <Select
            disabled={
              Object.keys(reducer.listAgents[0]).length === 0 ||
              (
                Object.keys(reducer.listAgents[0]).length !== 0 &&
                reducer.listAgents.filter((x) => x.skills.includes(skillSelect))
              ).length === 0
            }
            value={agentSelect}
            onChange={(e) => {
              setagentSelect(e.target.value)
            }}
            label="Agents"
          >
            {Object.keys(reducer.listAgents[0]).length !== 0 &&
              reducer.listAgents
                .filter((x) => x.skills.includes(skillSelect))
                .map((x) => (
                  <MenuItem key={x._id} value={x._id}>
                    {x.name}
                  </MenuItem>
                ))}
          </Select>
        </FormControl>
      </div>
      <div style={{ display: "flex", wrap: "wrap", justifyContent: "center" }}>
        <Button
          startIcon={<SearchIcon />}
          className={classes.btn}
          variant="contained"
          color="primary"
          disabled={agentSelect === null}
          onClick={() => _searchOneAgent(agentSelect)}
        >
          Search
        </Button>
        <CSVLink
          style={{ textDecoration: "none" }}
          data={
            reducer.oneAgentByDate
              ? reducer.oneAgentByDate.map((x) =>
                  source === "all"
                    ? {
                        date: dateformat(x.date, "yyyy/mm/dd"),
                        answered: x.total.answered,
                        notAnswered: x.total.notAnswered,
                        total: x.total.answered + x.total.notAnswered,
                        chatTime: msToTime(x.total.chatTime),
                        avgWaitingTime: msToTime(
                          x.total.chatTime / x.total.answered
                        ),
                      }
                    : {
                        date: dateformat(x.date, "yyyy/mm/dd"),
                        answered: x[source].answered,
                        notAnswered: x[source].notAnswered,
                        total: x[source].answered + x[source].notAnswered,
                        chatTime: msToTime(x[source].chatTime),
                        avgWaitingTime: msToTime(
                          x[source].chatTime / x[source].answered
                        ),
                      }
                )
              : []
          }
        >
          <Button
            startIcon={<SaveAltIcon />}
            className={classes.btn}
            variant="outlined"
            color="primary"
            disabled={!reducer.oneAgentByDate}
          >
            export
          </Button>
        </CSVLink>
      </div>
      {reducer.oneAgentByDate && (
        <TableStats
          data={reducer.oneAgentByDate.map((x) =>
            source === "all"
              ? { date: dateformat(x.date, "yyyy/mm/dd"), data: x.total }
              : { date: dateformat(x.date, "yyyy/mm/dd"), data: x[source] }
          )}
        />
      )}
    </div>
  )
}
