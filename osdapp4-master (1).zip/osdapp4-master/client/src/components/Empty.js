import React from "react";

const Empty = () => {
  return <div>empty</div>;
};

export default Empty;
