import React from "react"
import TableStatsGlobal from "./TableStatsGlobal"
import TableStatsByDate from "./TableStatsByDate"
import queryString from "query-string"

export default ({ reducer, _selectDates, _search, datesInput }) => {
  if (queryString.parse(window.location.search).tab === "global")
    return (
      <TableStatsGlobal
        _selectDates={_selectDates}
        _search={_search}
        datesInput={datesInput}
        reducer={reducer}
      />
    )
  if (queryString.parse(window.location.search).tab === "bydate")
    return (
      <TableStatsByDate
        _selectDates={_selectDates}
        _search={_search}
        datesInput={datesInput}
        reducer={reducer}
      />
    )
  return <div>empty</div>
}
