import React from "react"
import Typography from "@material-ui/core/Typography"
import { makeStyles } from "@material-ui/core/styles"
import Table from "@material-ui/core/Table"
import TableBody from "@material-ui/core/TableBody"
import TableCell from "@material-ui/core/TableCell"
import TableContainer from "@material-ui/core/TableContainer"
import TableHead from "@material-ui/core/TableHead"
import TableRow from "@material-ui/core/TableRow"

function msToTime(duration) {
  if (duration) {
    var milliseconds = parseInt((duration % 1000) / 100),
      seconds = Math.floor((duration / 1000) % 60),
      minutes = Math.floor((duration / (1000 * 60)) % 60),
      hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

    hours = hours < 10 ? "0" + hours : hours
    minutes = minutes < 10 ? "0" + minutes : minutes
    seconds = seconds < 10 ? "0" + seconds : seconds
    return hours + ":" + minutes + ":" + seconds
  } else {
    return "00:00:00"
  }
}

const useStyles = makeStyles({
  table: {
    minWidth: 650,
  },
  rowTitle: {
    fontWeight: "bold",
  },
})

const rows = [
  {
    date: "28-04-2020",
    totalAnswers: 21000,
    abandonCustomers: 123,
    total: 21188,
    waitingTime: "00:14:32",
    avgWaitingTime: "00:01:08",
  },
  {
    date: "29-04-2020",
    totalAnswers: 21000,
    abandonCustomers: 123,
    total: 21188,
    waitingTime: "00:14:32",
    avgWaitingTime: "00:01:08",
  },
  {
    date: "30-04-2020",
    totalAnswers: 21000,
    abandonCustomers: 123,
    total: 21188,
    waitingTime: "00:14:32",
    avgWaitingTime: "00:01:08",
  },
  {
    date: "01-05-2020",
    totalAnswers: 0,
    abandonCustomers: 0,
    total: 0,
    waitingTime: "0",
    avgWaitingTime: "0",
  },
  {
    date: "02-05-2020",
    totalAnswers: 0,
    abandonCustomers: 0,
    total: 0,
    waitingTime: "0",
    avgWaitingTime: "0",
  },
]

export default ({ data, source, skillSelect }) => {
  const classes = useStyles()
  return (
    <div>
      <Typography variant="h6" gutterBottom>
        Summary by date
      </Typography>
      <TableContainer>
        <Table className={classes.table} aria-label="simple table">
          <TableHead>
            <TableRow style={{ background: "#f2f2f2" }}>
              <TableCell className={classes.rowTitle} align="center">
                No.
              </TableCell>
              <TableCell className={classes.rowTitle} align="center">
                Date
              </TableCell>
              <TableCell className={classes.rowTitle} align="center">
                Total Answers
              </TableCell>
              <TableCell className={classes.rowTitle} align="center">
                Abandon Customers
              </TableCell>
              <TableCell className={classes.rowTitle} align="center">
                Total
              </TableCell>
              <TableCell className={classes.rowTitle} align="center">
                Waiting Time
              </TableCell>
              <TableCell className={classes.rowTitle} align="center">
                AVG Waiting Time
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {data.map((row, i) => {
              return (
                <TableRow key={i}>
                  <TableCell align="center" component="th" scope="row">
                    {i + 1}
                  </TableCell>
                  <TableCell align="center" component="th" scope="row">
                    {row.date}
                  </TableCell>
                  <TableCell align="center">{row.totalAnswers}</TableCell>
                  <TableCell align="center">{row.abandonCustomers}</TableCell>
                  <TableCell align="center">{row.total}</TableCell>
                  <TableCell align="center">
                    {msToTime(row.waitingTime)}
                  </TableCell>
                  <TableCell align="center">
                    {msToTime(row.avgWaitingTime)}
                  </TableCell>
                </TableRow>
              )
            })}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  )
}
