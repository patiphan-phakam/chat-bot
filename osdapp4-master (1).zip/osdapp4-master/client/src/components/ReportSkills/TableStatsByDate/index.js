import React, { useEffect, useReducer, useState } from "react"
import Typography from "@material-ui/core/Typography"
import { KeyboardDatePicker } from "@material-ui/pickers"
import InputLabel from "@material-ui/core/InputLabel"
import MenuItem from "@material-ui/core/MenuItem"
import { makeStyles } from "@material-ui/core/styles"
import FormControl from "@material-ui/core/FormControl"
import Select from "@material-ui/core/Select"
import Button from "@material-ui/core/Button"
import SearchIcon from "@material-ui/icons/Search"
import SaveAltIcon from "@material-ui/icons/SaveAlt"
import TableStats from "./TableStats"
import { CSVLink, CSVDownload } from "react-csv"
import dateformat from "dateformat"

const useStyles = makeStyles((theme) => ({
  main: {
    background: "white",
    padding: theme.spacing(1),
    borderRadius: 5,
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  btn: {
    margin: theme.spacing(1),
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
  input: { margin: 5 },
}))

const skillsLit = ["skill1", "skill2", "skill3", "skill4", "skill5"]

export default ({ reducer, _selectDates, _search, datesInput }) => {
  const classes = useStyles()
  const [selectedDate, handleDateChange] = useState(new Date())
  const [source, setSource] = React.useState("all")
  const [skillSelect, setSkillSelect] = useState("skill1")

  // const data = Object.entries(
  //   reducer.stats[source === "all" ? "total" : source]
  // )
  //   .filter((x) => skillSelect === x[0])
  //   .map((x) => ({
  //     skill: x[0],
  //     abandonCustomers: x[1].abandonCustomers,
  //     total: x[1].totalAnswers + x[1].abandonCustomers,
  //     totalAnswers: x[1].totalAnswers,
  //     waitingTime: x[1].waitingTime,
  //     avgWaitingTime: x[1].waitingTime / x[1].totalAnswers,
  //   }))
  console.log("fuuuuuuuuuuu", reducer.statsByDay)
  const data = reducer.statsByDay.map((x) => {
    if (source === "all")
      return {
        date: dateformat(x.date, "yyyy/mm/dd"),
        totalAnswers:
          x.messenger[skillSelect].totalAnswers +
          x.line[skillSelect].totalAnswers,
        abandonCustomers:
          x.messenger[skillSelect].abandonCustomers +
          x.line[skillSelect].abandonCustomers,
        total: x.messenger[skillSelect].total + x.line[skillSelect].total,
        waitingTime:
          x.messenger[skillSelect].waitingTime +
          x.line[skillSelect].waitingTime,
        avgWaitingTime:
          (x.messenger[skillSelect].waitingTime +
            x.line[skillSelect].waitingTime) /
          (x.messenger[skillSelect].totalAnswers +
            x.line[skillSelect].totalAnswers),
      }
    return {
      date: dateformat(x.date, "yyyy/mm/dd"),
      totalAnswers: x[source][skillSelect].totalAnswers,
      abandonCustomers: x[source][skillSelect].totalAnswers,
      total: x[source][skillSelect].total,
      waitingTime: x[source][skillSelect].waitingTime,
      avgWaitingTime:
        x[source][skillSelect].waitingTime /
        x[source][skillSelect].totalAnswers,
    }
  })

  return (
    <div className={classes.formControl}>
      <Typography variant="h4" gutterBottom>
        Skills summary report by date
      </Typography>
      <div style={{ borderBottom: "2px solid rgb(190, 190, 190)" }} />
      <div style={{ paddingTop: 14 }}>
        <KeyboardDatePicker
          className={classes.formControl}
          placeholder="2018/10/10"
          value={datesInput.startDate}
          onChange={(date) => _selectDates("startDate", date)}
          format="yyyy/MM/dd"
          inputVariant="outlined"
          label="Start Date"
          maxDate={new Date()}
        />

        <KeyboardDatePicker
          className={classes.formControl}
          placeholder="2018/10/10"
          value={datesInput.endDate}
          onChange={(date) => _selectDates("endDate", date)}
          format="yyyy/MM/dd"
          inputVariant="outlined"
          label="End Date"
          maxDate={new Date()}
        />
        <FormControl variant="outlined" className={classes.formControl}>
          <InputLabel id="demo-simple-select-outlined-label">Source</InputLabel>
          <Select
            labelId="demo-simple-select-outlined-label"
            id="demo-simple-select-outlined"
            value={source}
            onChange={(e) => setSource(e.target.value)}
            label="Source"
          >
            <MenuItem value="all">All</MenuItem>
            <MenuItem value={"messenger"}>Messenger</MenuItem>
            <MenuItem value={"line"}>Line</MenuItem>
          </Select>
        </FormControl>
        <FormControl variant="outlined" className={classes.formControl}>
          <InputLabel>Skill</InputLabel>
          <Select
            value={skillSelect}
            onChange={(e) => {
              setSkillSelect(e.target.value)
            }}
            label="Skill"
          >
            {skillsLit.map((x) => (
              <MenuItem value={x}>{x}</MenuItem>
            ))}
          </Select>
        </FormControl>
      </div>
      <div style={{ display: "flex", wrap: "wrap", justifyContent: "center" }}>
        <Button
          startIcon={<SearchIcon />}
          className={classes.btn}
          variant="contained"
          color="primary"
          onClick={_search}
        >
          Search
        </Button>
        <CSVLink data={data} style={{ textDecoration: "none" }}>
          <Button
            startIcon={<SaveAltIcon />}
            className={classes.btn}
            variant="outlined"
            color="primary"
          >
            export
          </Button>
        </CSVLink>
      </div>
      <TableStats data={data} source={source} skillSelect={skillSelect} />
    </div>
  )
}
