import React from "react"
import ChartRadar from "./charts/ChartRadar"
import ChartLine from "./charts/ChartLine"
import ChartMulti from "./charts/ChartMulti"

const TabAnalytics = () => {
  return (
    <div style={{ display: "flex", marginTop: 100 }}>
      <ChartRadar />
      <ChartLine />
      <ChartMulti />
    </div>
  )
}

export default TabAnalytics
