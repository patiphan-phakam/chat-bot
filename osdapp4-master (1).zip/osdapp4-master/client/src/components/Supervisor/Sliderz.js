import React from "react"
import { makeStyles } from "@material-ui/core/styles"
import Typography from "@material-ui/core/Typography"
import Slider from "@material-ui/core/Slider"

const useStyles = makeStyles({
  root: {
    width: 300
  }
})

function valuetext(value) {
  return `${value}°C`
}

export default function RangeSlider({
  rangeGraph,
  _setRangeGraph,
  arrayLength
}) {
  const classes = useStyles()

  return (
    <div className={classes.root}>
      <Typography id="range-slider" gutterBottom>
        chat volume range
      </Typography>
      <Slider
        value={rangeGraph}
        onChange={_setRangeGraph}
        valueLabelDisplay="auto"
        aria-labelledby="range-slider"
        getAriaValueText={valuetext}
        max={arrayLength}
        min={0}
      />
      {arrayLength}
    </div>
  )
}
