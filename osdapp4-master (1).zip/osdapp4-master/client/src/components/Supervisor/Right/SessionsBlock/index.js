import React from "react"
import Paper from "@material-ui/core/Paper"
import Typography from "@material-ui/core/Typography"
import { makeStyles } from "@material-ui/core/styles"

const DBSessions = [
  {
    duration: "0-30",
    sessions: 2250,
    views: 4250
  },
  {
    duration: "31-60",
    sessions: 1501,
    views: 2050
  },
  {
    duration: "61-120",
    sessions: 750,
    views: 1600
  },
  {
    duration: "121-240",
    sessions: 540,
    views: 1040
  }
]

const useStyles = makeStyles(theme => ({
  root: {
    margin: theme.spacing(1),
    flex: 1
  },
  paper: {
    width: "100%",
    padding: theme.spacing(1, 1, 0, 1)
  },
  sessionHeader: {
    display: "flex",
    fontWeight: "bold",
    justifyContent: "space-between",
    background: "#e0e0e0",
    padding: theme.spacing(2, 1),
    borderRadius: 3
  },
  session: {
    padding: theme.spacing(1),
    borderTop: "1px solid #e0e0e0",
    display: "flex"
  }
}))

const SessionsBlock = () => {
  const classes = useStyles()
  return (
    <div className={classes.root}>
      <Typography variant="h5" gutterBottom style={{ color: "#424242" }}>
        Sessions
      </Typography>
      <Paper className={classes.paper}>
        <div>
          <div className={classes.sessionHeader}>
            <div style={{ flex: 1, textAlign: "center" }}>Duration</div>
            <div style={{ flex: 1, textAlign: "center" }}>Sessions</div>
            <div style={{ flex: 1 }}>Views</div>
          </div>
          {DBSessions.map(({ duration, sessions, views }, index) => (
            <div key={index} className={classes.session}>
              <div style={{ width: "35%" }}>{duration}</div>
              <div style={{ width: "33%" }}>{sessions}</div>
              <div>{views}</div>
            </div>
          ))}
        </div>
      </Paper>
    </div>
  )
}

export default SessionsBlock
