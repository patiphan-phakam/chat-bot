import React from "react"
import { makeStyles } from "@material-ui/core/styles"
import Typography from "@material-ui/core/Typography"
import Paper from "@material-ui/core/Paper"

const styles = {
  itemContainer: {
    width: "100%",
    borderBottom: "solid 1px #e0e0e0",
    color: "#424242",
    padding: "3px 5px 3px 5px",
    display: "flex",
    justifyContent: "center",
    flexDirection: "column"
  }
}

const useStyles = makeStyles(theme => ({
  root: {
    padding: theme.spacing(3, 2),
    margin: theme.spacing(1)
  }
}))

const AlertLogger = ({ supervisorReducer, _solvingAlert }) => {
  const classes = useStyles()
  return (
    <Paper className={classes.root}>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <Typography variant="h5" gutterBottom>
          Alert log
        </Typography>
      </div>
      <div style={{ marginBottom: 7 }}>
        <b>{Object.entries(supervisorReducer.alerts).length}</b> tickets
      </div>
      <div
        style={{
          height: 200,
          overflowY: "scroll",
          background: "#fafafa",
          cursor: "pointer"
        }}
      >
        {supervisorReducer.supervisor.skills &&
          Object.entries(supervisorReducer.alerts)
            .map(x => ({
              alertId: x[0],
              ...x[1]
            }))
            .filter(x =>
              supervisorReducer.supervisor.skills.some(y => y === x.skill)
            )
            .sort((a, b) => b.stamp - a.stamp)
            .map(({ alertId, date, agentId, skill, solved }) => {
              return (
                <div
                  key={alertId}
                  onClick={() => {
                    _solvingAlert(alertId, agentId)
                  }}
                >
                  <div
                    style={
                      solved
                        ? {
                            ...styles.itemContainer,
                            textDecoration: "line-through"
                          }
                        : styles.itemContainer
                    }
                  >
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between"
                      }}
                    >
                      <div style={{ fontWeight: "bold" }}>
                        #
                        {agentId === "5ddc93d61c9d440000e2c6ba"
                          ? "agentskill1skill2@gmail.com"
                          : agentId}
                      </div>
                      <div>{skill}</div>
                    </div>
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between"
                      }}
                    >
                      <div>Ticket:{alertId}</div>
                      <div>{date.split(",")[1]}</div>
                    </div>
                  </div>
                </div>
              )
            })}
      </div>
    </Paper>
  )
}

export default AlertLogger
