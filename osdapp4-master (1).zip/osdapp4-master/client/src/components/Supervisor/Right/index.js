import React from "react"
import { makeStyles } from "@material-ui/core/styles"
import AlertLogger from "./AlertLogger"
import SessionsBlock from "./SessionsBlock"
import SourcesBlock from "./SourcesBlock"

const useStyles = makeStyles((theme) => ({
  root: {
    marginTop: 148,
    [theme.breakpoints.down("sm")]: {
      minWidth: 400,
    },
    [theme.breakpoints.up("md")]: {
      minWidth: 400,
    },
    [theme.breakpoints.up("lg")]: {
      minWidth: 500,
    },
    [theme.breakpoints.up("xl")]: {
      minWidth: 700,
    },
  },
  secondBlocks: {
    display: "flex",
    justifyContent: "space-between",
    margin: theme.spacing(3, 0),
  },
}))

const Right = ({ supervisorReducer, _solvingAlert }) => {
  const classes = useStyles()
  return (
    <div className={classes.root}>
      <AlertLogger
        supervisorReducer={supervisorReducer}
        _solvingAlert={_solvingAlert}
      />
      <div className={classes.secondBlocks}>
        {/* <SessionsBlock />
        <SourcesBlock /> */}
      </div>
    </div>
  )
}

export default Right
