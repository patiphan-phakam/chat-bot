import React from "react"
import Paper from "@material-ui/core/Paper"
import Typography from "@material-ui/core/Typography"
import { makeStyles } from "@material-ui/core/styles"

const DBSources = [
  {
    channel: "Facebook",
    visits: 2250
  },
  {
    channel: "Line",
    visits: 1501
  },
  {
    channel: "Webchat",
    visits: 750
  }
]

const useStyles = makeStyles(theme => ({
  root: {
    margin: theme.spacing(1),
    flex: 1
  },
  paper: {
    width: "100%",
    padding: theme.spacing(1, 1, 0, 1)
  },
  sessionHeader: {
    display: "flex",
    fontWeight: "bold",
    background: "#e0e0e0",
    padding: theme.spacing(2, 0),
    borderRadius: 3
  },
  session: {
    padding: theme.spacing(1),
    borderTop: "1px solid #e0e0e0",
    display: "flex"
  }
}))

const SourcesBlock = () => {
  const classes = useStyles()
  return (
    <div className={classes.root}>
      <Typography variant="h5" gutterBottom style={{ color: "#424242" }}>
        Sources
      </Typography>
      <Paper className={classes.paper}>
        <div>
          <div className={classes.sessionHeader}>
            <div style={{ width: "40%", textAlign: "center" }}>Network</div>
            <div>Visits</div>
          </div>
          {DBSources.map(({ channel, visits }, index) => {
            const total = DBSources.reduce((a, b) => ({
              visits: a.visits + b.visits
            })).visits
            return (
              <div key={index} className={classes.session}>
                <div style={{ width: "40%" }}>{channel}</div>
                <div style={{ width: "30%" }}>{visits}</div>
                <div
                  style={{
                    width: "30%",
                    display: "flex",
                    alignItems: "center"
                  }}
                >
                  <div
                    style={{
                      width: "100%",
                      background: "#e0e0e0",
                      display: "flex",
                      height: 10
                    }}
                  >
                    <div
                      style={{
                        background: "#9193db",
                        width: (100 / total) * visits,
                        height: 10
                      }}
                    ></div>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </Paper>
    </div>
  )
}

export default SourcesBlock
