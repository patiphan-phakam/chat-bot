import React from "react"
import { makeStyles } from "@material-ui/core/styles"
import Typography from "@material-ui/core/Typography"
import Paper from "@material-ui/core/Paper"
import MoreVertButton from "@material-ui/icons/MoreVert"
import IconButton from "@material-ui/core/IconButton"
import Task from "./Task"

const useStyles = makeStyles(theme => ({
  root: {
    padding: theme.spacing(3, 2),
    margin: theme.spacing(1)
  }
}))

const DBTasks = [
  {
    title: "Nisi ut aliquip ex ea commodo consequat.",
    due: 3,
    status: "In-progress",
    assigned: "Skill 1",
    totalTime: "3h20"
  },
  {
    title: "Nisi ut aliquip ex ea commodo consequat.",
    due: 27,
    status: "Outdated",
    assigned: "All Team",
    totalTime: "12h21"
  },
  {
    title: "Nisi ut aliquip ex ea commodo consequat.",
    due: 7,
    status: "Completed",
    assigned: "Agent 1,2",
    totalTime: "78h05"
  },
  {
    title: "Nisi ut aliquip ex ea commodo consequat.",
    due: 5,
    status: "In-progress",
    assigned: "Skill 2",
    totalTime: "26h58"
  }
]

const TasksBlock = () => {
  const classes = useStyles()
  return (
    <Paper className={classes.root}>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <Typography variant="h5" gutterBottom>
          TASKS
        </Typography>
        <IconButton aria-label="menu" style={{ marginTop: -12, height: 50 }}>
          <MoreVertButton />
        </IconButton>
      </div>
      <div style={{ marginBottom: 7 }}>
        <b>107</b> Tasks completed out of 195
      </div>
      {DBTasks.map(({ title, due, status, assigned, totalTime }, index) => (
        <Task
          key={index}
          title={title}
          due={due}
          status={status}
          assigned={assigned}
          totalTime={totalTime}
        />
      ))}
    </Paper>
  )
}

export default TasksBlock
