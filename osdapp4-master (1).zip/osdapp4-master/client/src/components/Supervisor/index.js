import React, { useEffect, useState } from "react"
import Left from "./Left"
import Right from "./Right"
import GraphRating from "./GraphRating"
import GraphChatVolum from "./GraphChatVolum"
import GraphWaiting from "./GraphWaiting"
import dateFormat from "dateformat"

export default ({ supervisorReducer, _solvingAlert }) => {
  const [sortArg, setSortArg] = useState("skill1")
  const _setSkillSort = (arg) => setSortArg(arg)

  const calcGlobalStats = () => {
    return supervisorReducer.stats.map((stat) => {
      let result = {
        _id: stat._id,
        day: dateFormat(new Date(stat.day), "dd/mm"),
        ratings: {
          stars1: 0,
          stars2: 0,
          stars3: 0,
          stars4: 0,
          stars5: 0,
          avg: 0,
          total: 0,
        },
        performance: {
          avgSessionDuration: 0,
          avgWaitingDuration: 0,
          totalSessionDuration: 0,
          totalWaitingDuration: 0,
        },
        sessions: {
          sessions: 0,
          timeout: 0,
        },
      }
      supervisorReducer.supervisor.skills.map((skill) => {
        Object.entries(result.ratings).map((stars) => {
          result = {
            ...result,
            ratings: {
              ...result.ratings,
              [stars[0]]: stat.ratings[skill]
                ? result.ratings[stars[0]] + stat.ratings[skill][stars[0]]
                : result.ratings[stars[0]],
              avg:
                (result.ratings.stars1 * 1 +
                  result.ratings.stars2 * 2 +
                  result.ratings.stars3 * 3 +
                  result.ratings.stars4 * 4 +
                  result.ratings.stars5 * 5) /
                result.ratings.total,
            },
            performance: {
              ...result.performance,
              totalSessionDuration: stat.performance[skill]
                ? result.performance.totalSessionDuration +
                  stat.performance[skill].avgSessionDuration
                : result.performance.totalSessionDuration,

              totalWaitingDuration: stat.performance[skill]
                ? result.performance.totalWaitingDuration +
                  stat.performance[skill].avgSessionDuration
                : result.performance.totalWaitingDuration,

              sessions: stat.sessions[skill]
                ? result.sessions.sessions + stat.sessions[skill].sessions
                : result.sessions.sessions,

              avgSessionDuration:
                result.performance.totalSessionDuration /
                supervisorReducer.supervisor.skills.length,

              avgWaitingDuration:
                result.performance.totalWaitingDuration /
                supervisorReducer.supervisor.skills.length,
            },
          }
        })

        //   result.performance.totalSessionDuration =
        //   result.performance.totalSessionDuration +
        //   stat.performance[skill].avgSessionDuration
        // result.performance.totalWaitingDuration =
        //   result.performance.totalWaitingDuration +
        //   stat.performance[skill].avgWaitingDuration

        // result.sessions.sessions =
        //   stat.sessions[skill].sessions + result.sessions.sessions
        // result.sessions.timeout =
        //   stat.sessions[skill].timeout + result.sessions.timeout
      })
      // result.performance.avgSessionDuration =
      //   result.performance.totalSessionDuration /
      //   supervisorReducer.supervisor.skills.length
      // result.performance.avgWaitingDuration =
      //   result.performance.totalWaitingDuration /
      //   supervisorReducer.supervisor.skills.length
      // result.ratings["avg"] =
      //   (result.ratings.stars1 * 1 +
      //     result.ratings.stars2 * 2 +
      //     result.ratings.stars3 * 3 +
      //     result.ratings.stars4 * 4 +
      //     result.ratings.stars5 * 5) /
      //   result.ratings.total
      return result
    })
  }

  return (
    <div>
      <div style={{ display: "flex" }}>
        <Left
          supervisorReducer={supervisorReducer}
          sortArg={sortArg}
          _setSkillSort={_setSkillSort}
        />
        <Right
          supervisorReducer={supervisorReducer}
          _solvingAlert={_solvingAlert}
        />
      </div>
      {supervisorReducer.stats.length > 0 &&
        supervisorReducer.supervisor.skills &&
        supervisorReducer.supervisor.skills.length > 0 && (
          <div style={{ display: "flex", flexWrap: "wrap" }}>
            <GraphChatVolum
              sortArg={sortArg}
              supervisorReducer={supervisorReducer}
              calcGlobalStats={calcGlobalStats()}
            />
            <GraphRating
              sortArg={sortArg}
              supervisorReducer={supervisorReducer}
              calcGlobalStats={calcGlobalStats()}
            />
            <GraphWaiting
              sortArg={sortArg}
              supervisorReducer={supervisorReducer}
              calcGlobalStats={calcGlobalStats()}
            />
          </div>
        )}
    </div>
  )
}
