import React from "react"
import dateFormat from "date-format"
import {
  ComposedChart,
  Line,
  Area,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from "recharts"
import Paper from "@material-ui/core/Paper"
import Typography from "@material-ui/core/Typography"

const data = [
  {
    day: "03/08",
    avgSessionDuration: 360,
    avgWaitingDuration: 30
  },
  {
    day: "03/08",
    avgSessionDuration: 180,
    avgWaitingDuration: 10
  },
  {
    day: "03/08",
    avgSessionDuration: 240,
    avgWaitingDuration: 20
  },
  {
    day: "03/08",
    avgSessionDuration: 100,
    avgWaitingDuration: 0
  },
  {
    day: "03/08",
    avgSessionDuration: 400,
    avgWaitingDuration: 0
  },
  {
    day: "03/08",
    avgSessionDuration: 240,
    avgWaitingDuration: 10
  },
  {
    day: "03/08",
    avgSessionDuration: 240,
    avgWaitingDuration: 0
  }
]

const tickComp = sec => {
  const date = new Date(sec * 1000)

  return dateFormat("mm:ss", date)
}

const GraphWaiting = ({ supervisorReducer, sortArg, calcGlobalStats }) => {
  return (
    <Paper style={{ padding: "24px 16px", margin: 8 }}>
      <Typography variant="h5" gutterBottom>
        Performance
      </Typography>
      <ComposedChart
        width={500}
        height={400}
        data={
          sortArg === "all"
            ? calcGlobalStats.map(x => ({ ...x.performance, day: x.day }))
            : supervisorReducer.stats.map(x => ({
                ...x.performance[sortArg],
                day: x.day
              }))
        }
        margin={{
          top: 20,
          right: 80,
          bottom: 20,
          left: 20
        }}
      >
        <CartesianGrid stroke="#f5f5f5" />
        <XAxis
          dataKey="day"
          //   label={{ value: "Dates", position: "insideBottomRight", offset: 0 }}
        />
        <YAxis
          tickFormatter={tickComp}
          dataKey="avgSessionDuration"
          label={{
            value: "Average chat time",
            angle: -90,
            position: "insideLeft"
          }}
        />
        <YAxis
          tickFormatter={tickComp}
          yAxisId="right"
          type="number"
          dataKey="avgWaitingDuration"
          name="Waiting time"
          orientation="right"
          label={{
            value: "average waiting time",
            angle: 90,
            position: "insideRight"
          }}
        />
        <Tooltip />
        <Legend />
        <Bar dataKey="avgSessionDuration" stackId="a" fill="#ffbf29" />
        <Line
          strokeWidth={4}
          yAxisId={"right"}
          type="monotone"
          dataKey="avgWaitingDuration"
          stroke="#ff546e"
        />
      </ComposedChart>
    </Paper>
  )
}

export default GraphWaiting
