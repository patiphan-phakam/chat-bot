import React, { useState } from "react"
import Sliderz from "./Sliderz"
import {
  ComposedChart,
  Line,
  ResponsiveContainer,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from "recharts"
import Paper from "@material-ui/core/Paper"
import Typography from "@material-ui/core/Typography"

const data = [
  {
    name: "03/08",
    sessions: 60,
    timeout: 20,
    acceptanceRate: 100
  },
  {
    name: "04/08",
    sessions: 90,
    timeout: 40,
    acceptanceRate: 90
  },
  {
    name: "05/08",
    sessions: 190,
    timeout: 50,
    acceptanceRate: 80
  },
  {
    name: "06/08",
    sessions: 190,
    timeout: 10,
    acceptanceRate: 95
  },
  {
    name: "07/08",
    sessions: 120,
    timeout: 0,
    acceptanceRate: 100
  },
  {
    name: "08/08",
    sessions: 120,
    timeout: 20,
    acceptanceRate: 95
  },
  {
    name: "09/08",
    sessions: 90,
    timeout: 5,
    acceptanceRate: 90
  },
  {
    name: "10/08",
    sessions: 90,
    timeout: 5,
    acceptanceRate: 90
  }
]

const GraphChatVolum = ({ supervisorReducer, sortArg, calcGlobalStats }) => {
  return (
    <Paper style={{ padding: "24px 16px", margin: 8 }}>
      <Typography variant="h5" gutterBottom>
        Chat Volum
      </Typography>
      <ComposedChart
        width={500}
        height={400}
        data={
          sortArg === "all"
            ? calcGlobalStats.map(x => ({
                ...x.sessions,
                day: x.day,
                acceptanceRate:
                  (100 / (x.sessions.sessions + x.sessions.timeout)) *
                  x.sessions.sessions
              }))
            : supervisorReducer.stats.map(x => ({
                ...x.sessions[sortArg],
                day: x.day,
                acceptanceRate:
                  (100 /
                    (x.sessions[sortArg].sessions +
                      x.sessions[sortArg].timeout)) *
                  x.sessions[sortArg].sessions
              }))
        }
        margin={{
          top: 20,
          right: 80,
          bottom: 20,
          left: 20
        }}
      >
        <CartesianGrid stroke="#f5f5f5" />
        <XAxis
          dataKey="day"
          //   label={{ value: "Dates", position: "insideBottomRight", offset: 0 }}
        />
        <YAxis
          label={{
            value: "Number sessions",
            angle: -90,
            position: "insideLeft"
          }}
        />
        <YAxis
          unit="%"
          yAxisId="right"
          type="number"
          dataKey="average"
          name="average rating"
          orientation="right"
          label={{
            value: "Acceptance rate",
            angle: 90,
            position: "insideRight"
          }}
          ticks={[0, 25, 50, 75, 100]}
        />
        <Tooltip />
        <Legend />
        <Bar dataKey="sessions" stackId="a" fill="#0c60c2" />
        <Bar dataKey="timeout" stackId="a" fill="#217feb" />
        <Line
          strokeWidth={4}
          yAxisId={"right"}
          type="monotone"
          dataKey="acceptanceRate"
          stroke="#7fc722"
        />
      </ComposedChart>
    </Paper>
  )
}

export default GraphChatVolum
