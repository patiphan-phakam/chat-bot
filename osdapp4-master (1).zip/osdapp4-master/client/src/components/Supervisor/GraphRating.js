import React from "react"
import Paper from "@material-ui/core/Paper"
import Typography from "@material-ui/core/Typography"

import {
  ComposedChart,
  Line,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts"

// const data = [
//   {
//     day: "03/08",
//     stars5: 60,
//     stars4: 20,
//     stars3: 10,
//     stars2: 5,
//     stars1: 5,
//     avg: 3
//   },
//   {
//     day: "04/08",
//     stars5: 130,
//     stars4: 30,
//     stars3: 40,
//     stars2: 12,
//     stars1: 20,
//     avg: 3.5
//   },
//   {
//     day: "05/08",
//     stars5: 140,
//     stars4: 50,
//     stars3: 30,
//     stars2: 15,
//     stars1: 5,
//     avg: 4
//   },
//   {
//     day: "06/08",
//     stars5: 160,
//     stars4: 30,
//     stars3: 10,
//     stars2: 40,
//     stars1: 5,
//     avg: 4.5
//   },
//   {
//     day: "07/08",
//     stars5: 80,
//     stars4: 60,
//     stars3: 40,
//     stars2: 25,
//     stars1: 15,
//     avg: 3.5
//   },
//   {
//     day: "08/08",
//     stars5: 50,
//     stars4: 36,
//     stars3: 10,
//     stars2: 5,
//     stars1: 5,
//     avg: 3
//   },
//   {
//     day: "09/08",
//     stars5: 180,
//     stars4: 90,
//     stars3: 10,
//     stars2: 5,
//     stars1: 5,
//     avg: 4.8
//   }
// ]

export default ({ supervisorReducer, sortArg, calcGlobalStats }) => {
  return (
    <Paper style={{ padding: "24px 16px", margin: 8 }}>
      <Typography variant="h5" gutterBottom>
        Ratings
      </Typography>
      <ComposedChart
        width={500}
        height={400}
        data={
          sortArg === "all"
            ? calcGlobalStats.map((x) => ({ ...x.ratings, day: x.day }))
            : supervisorReducer.stats.map((x) => x.ratings[sortArg])
        }
      >
        <CartesianGrid stroke="#f5f5f5" />
        <XAxis
          dataKey="day"
          //   label={{ value: "Dates", position: "insideBottomRight", offset: 0 }}
        />
        <YAxis
          label={{
            value: "Number ratings",
            angle: -90,
            position: "insideLeft",
          }}
        />
        <YAxis
          yAxisId="right"
          type="number"
          dataKey="avg"
          name="average rating"
          orientation="right"
          ticks={[0, 1, 2, 3, 4, 5]}
          height={50}
          label={{
            value: "Average ratings",
            angle: 90,
            position: "insideRight",
          }}
        />
        <Tooltip />
        <Legend />
        <Bar dataKey="stars5" stackId="a" fill="#eb3434" />
        <Bar dataKey="stars4" stackId="a" fill="#eb6b34" />
        <Bar dataKey="stars3" stackId="a" fill="#eb9f34" />
        <Bar dataKey="stars2" stackId="a" fill="#ebb734" />
        <Bar dataKey="stars1" stackId="a" fill="#f2f218" />
        <Line
          strokeWidth={4}
          yAxisId={"right"}
          type="monotone"
          dataKey="avg"
          stroke="#7fc722"
        />
      </ComposedChart>
    </Paper>
  )
}
