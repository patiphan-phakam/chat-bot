import React from "react"
import { makeStyles } from "@material-ui/core/styles"
import Paper from "@material-ui/core/Paper"
import Typography from "@material-ui/core/Typography"
import Skeleton from "@material-ui/lab/Skeleton"

const useStyles = makeStyles((theme) => ({
  blockStats: {
    padding: theme.spacing(2),
    margin: theme.spacing(0, 1, 1, 1),
    width: 220,
    color: "#424242",
  },
  blockLoading: {
    margin: 8,
    width: 220,
    height: 90,
  },
}))

const data = (a, sortArg) => {
  if (Object.entries(a).filter((x) => x[0] === sortArg)[0])
    return Object.entries(a).filter((x) => x[0] === sortArg)[0][1].length
}

export default ({ sortArg, supervisorReducer }) => {
  const classes = useStyles()

  if (!supervisorReducer.totalSessions[sortArg])
    return (
      <div style={{ display: "flex", flexWrap: "wrap", marginTop: "-8px" }}>
        {[0, 1, 2, 3, 4, 5, 6, 7].map((x) => (
          <Skeleton
            variant="rect"
            animation="pulse"
            className={classes.blockLoading}
            component={"div"}
          />
        ))}
      </div>
    )
  if (supervisorReducer.totalSessions[sortArg])
    return (
      <div style={{ display: "flex", flexWrap: "wrap" }}>
        <Paper
          className={classes.blockStats}
          style={{ background: "#6bd17f", color: "white" }}
        >
          <Typography variant="subtitle2" component="div" gutterBottom>
            READY
          </Typography>
          <Typography variant="h5" component="div">
            {data(supervisorReducer.queueAgents, sortArg)}
          </Typography>
        </Paper>
        <Paper
          className={classes.blockStats}
          style={{ background: "#ff7598", color: "white" }}
        >
          <Typography variant="subtitle2" component="div" gutterBottom>
            NOT READY
          </Typography>
          <Typography variant="h5" component="div">
            {supervisorReducer.agents.filter((x) => x.skills.includes(sortArg))
              .length - data(supervisorReducer.queueAgents, sortArg)}
          </Typography>
        </Paper>
        <Paper className={classes.blockStats}>
          <Typography variant="subtitle2" component="div" gutterBottom>
            TOTAL AGENTS
          </Typography>
          <Typography variant="h5" component="div">
            {
              supervisorReducer.agents.filter((x) => x.skills.includes(sortArg))
                .length
            }
          </Typography>
        </Paper>
        <Paper className={classes.blockStats}>
          <Typography variant="subtitle2" component="div" gutterBottom>
            QUEUE
          </Typography>
          <Typography variant="h5" component="div">
            {data(supervisorReducer.queueCustomers, sortArg)}
          </Typography>
        </Paper>
        <Paper
          className={classes.blockStats}
          // style={{ background: "#00bfa5", color: "white" }}
        >
          <Typography variant="subtitle2" gutterBottom>
            CUSTOMER
          </Typography>
          <Typography variant="h5" component="div">
            {supervisorReducer.totalSessions[sortArg] &&
              supervisorReducer.totalSessions[sortArg]}
          </Typography>
        </Paper>
        <Paper
          className={classes.blockStats}
          // style={{ background: "#00bfa5", color: "white" }}
        >
          <Typography variant="subtitle2" gutterBottom>
            TOTAL ANSWER
          </Typography>
          <Typography variant="h5" component="div">
            {supervisorReducer.totalSessions[sortArg] &&
            supervisorReducer.timeoutCustomers[sortArg]
              ? supervisorReducer.totalSessions[sortArg] -
                supervisorReducer.timeoutCustomers[sortArg]
              : 0}
          </Typography>
        </Paper>
        <Paper
          className={classes.blockStats}
          // style={{ background: "#00bfa5", color: "white" }}
        >
          <Typography variant="subtitle2" gutterBottom>
            ABANDON CUSTOMER
          </Typography>
          <Typography variant="h5" component="div">
            {supervisorReducer.timeoutCustomers[sortArg]
              ? supervisorReducer.timeoutCustomers[sortArg]
              : 0}
          </Typography>
        </Paper>
        <Paper
          className={classes.blockStats}
          // style={{ background: "#00bfa5", color: "white" }}
        >
          <Typography variant="subtitle2" gutterBottom>
            SPEED ANSWER
          </Typography>
          <Typography variant="h5" component="div">
            {supervisorReducer.totalDuration[sortArg] &&
              supervisorReducer.totalDuration[sortArg] / 1000 + " sec"}
          </Typography>
        </Paper>
        <Paper
          className={classes.blockStats}
          // style={{ background: "#00bfa5", color: "white" }}
        >
          <Typography variant="subtitle2" gutterBottom>
            ONLINE
          </Typography>
          <Typography variant="h5" component="div" gutterBottom>
            {
              supervisorReducer.agents.filter(
                (x) =>
                  x.status === "available" ||
                  x.status === "wrapup" ||
                  x.status === "busy"
              ).length
            }
          </Typography>
        </Paper>
      </div>
    )
}
