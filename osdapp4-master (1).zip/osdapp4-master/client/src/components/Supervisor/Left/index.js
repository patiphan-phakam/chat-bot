import React, { useState } from "react"
import { makeStyles } from "@material-ui/core/styles"
import Paper from "@material-ui/core/Paper"
import Typography from "@material-ui/core/Typography"
import DropDownAgents from "./DropDownAgents"
import Card from "./Card"
import Stats from "./Stats"
import Skeleton from "@material-ui/lab/Skeleton"
import IconButton from "@material-ui/core/IconButton"
import Remove from "@material-ui/icons/Remove"
import Add from "@material-ui/icons/Add"
import Collapse from "@material-ui/core/Collapse"

const useStyles = makeStyles((theme) => ({
  blockStats: {
    padding: theme.spacing(2),
    margin: theme.spacing(0, 1, 1, 1),
    width: 220,
    color: "#424242",
  },
  title: {
    padding: theme.spacing(2),
    margin: theme.spacing(0, 1, 1, 1),
  },
  blockLoadingAgent: {
    margin: 8,
    width: 220,
  },
}))

const Left = ({ supervisorReducer, sortArg, _setSkillSort }) => {
  const [open, setOpen] = useState(true)
  const classes = useStyles()

  return (
    <div>
      <div>
        <div style={{ marginLeft: 6 }}>
          <Typography variant="h6" gutterBottom>
            Supervisor
          </Typography>
          <Typography variant="h4" gutterBottom>
            Name supervisor
          </Typography>
        </div>

        <DropDownAgents
          list={supervisorReducer.supervisor.skills}
          title="Skills"
          _setSkillSort={_setSkillSort}
        />
      </div>
      <Stats sortArg={sortArg} supervisorReducer={supervisorReducer} />
      <div
        style={{
          width: "calc(100% - 24px)",
          borderBottom: "2px solid #BEBEBE",
          margin: "45px 8px 15px 8px",
          textAlign: "right",
        }}
      >
        <IconButton onClick={() => setOpen(!open)}>
          {open ? <Remove /> : <Add />}
        </IconButton>
      </div>
      <Collapse in={open}>
        <div style={{ display: "flex", flexWrap: "wrap" }}>
          {supervisorReducer.agents.filter((x) =>
            x.skills.some((e) => sortArg.includes(e))
          ).length > 0 ? (
            supervisorReducer.agents
              .filter((x) => x.skills.some((e) => sortArg.includes(e)))
              .map((x) => <Card agent={x} key={x._id} />)
          ) : (
            <div style={{ display: "flex", flexWrap: "wrap" }}>
              {[0, 1, 2, 3, 4, 5, 6, 7].map((x, i) => (
                <Skeleton
                  variant="rect"
                  animation="pulse"
                  className={classes.blockLoadingAgent}
                  component={"div"}
                  height={200}
                  key={i}
                />
              ))}
            </div>
          )}
        </div>
      </Collapse>
    </div>
  )
}

export default Left

// old
// import React, { useState } from "react"
// import { makeStyles } from "@material-ui/core/styles"
// import Paper from "@material-ui/core/Paper"
// import Typography from "@material-ui/core/Typography"
// import DropDownAgents from "./DropDownAgents"
// import Card from "./Card"

// const useStyles = makeStyles(theme => ({
//   blockStats: {
//     padding: theme.spacing(2),
//     margin: theme.spacing(0, 1, 1, 1),
//     width: 220
//   }
// }))

// function compare(a, b) {
//   let comparison = 0
//   if (a[0].toUpperCase() > b[0].toUpperCase()) {
//     comparison = 1
//   } else if (a[0].toUpperCase() < b[0].toUpperCase()) {
//     comparison = -1
//   }
//   return comparison
// }

// const Left = ({ supervisorReducer, sortArg, _setSkillSort }) => {
//   const classes = useStyles()

//   return (
//     <div>
//       <div style={{ display: "flex", flexWrap: "wrap" }}>
//         <Paper className={classes.blockStats}>
//           <Typography variant="subtitle2" component="div" gutterBottom>
//             QUEUE AGENTS
//           </Typography>

//           {Object.entries(supervisorReducer.queueAgents)
//             .sort(compare)
//             .map((x, index) => {
//               return (
//                 <div key={index}>
//                   {x[0]}: {x[1].length}
//                 </div>
//               )
//             })}
//         </Paper>
//         <Paper
//           className={classes.blockStats}
//           // style={{ background: "#00bfa5", color: "white" }}
//         >
//           <Typography variant="subtitle2" gutterBottom>
//             QUEUE CUSTOMERS
//           </Typography>
//           {Object.entries(supervisorReducer.queueCustomers)
//             .sort(compare)
//             .map((x, index) => {
//               return (
//                 <div key={index}>
//                   {x[0]}: {x[1].length}
//                 </div>
//               )
//             })}
//           {/* <Typography variant="h5" component="div" gutterBottom>
//             36 254
//           </Typography> */}
//         </Paper>
//         <Paper
//           className={classes.blockStats}
//           // style={{ background: "#00bfa5", color: "white" }}
//         >
//           <Typography variant="subtitle2" gutterBottom>
//             CUSTOMERS TIMEOUT
//           </Typography>
//           {Object.entries(supervisorReducer.timeoutCustomers) &&
//           Object.entries(supervisorReducer.timeoutCustomers).length > 0 &&
//           supervisorReducer.supervisor.skills.length > 0 ? (
//             <div>
//               {Object.entries(supervisorReducer.timeoutCustomers)
//                 .filter(x =>
//                   supervisorReducer.supervisor.skills.some(r =>
//                     x[0].includes(r)
//                   )
//                 )
//                 .map((x, index) => {
//                   return (
//                     <div key={index}>
//                       {x[0]}: {x[1]}
//                     </div>
//                   )
//                 })}
//             </div>
//           ) : (
//             <div>
//               {supervisorReducer.supervisor.skills.map(x => (
//                 <div key={x}>{x}: 0</div>
//               ))}
//             </div>
//           )}
//         </Paper>
//         <Paper
//           className={classes.blockStats}
//           // style={{ background: "#00bfa5", color: "white" }}
//         >
//           <Typography variant="subtitle2" gutterBottom>
//             TOTAL SESSIONS
//           </Typography>
//           {Object.entries(supervisorReducer.totalSessions) &&
//           Object.entries(supervisorReducer.totalSessions).length > 0 &&
//           supervisorReducer.supervisor.skills.length > 0 ? (
//             <div>
//               {Object.entries(supervisorReducer.totalSessions)
//                 .filter(x =>
//                   supervisorReducer.supervisor.skills.some(r =>
//                     x[0].includes(r)
//                   )
//                 )
//                 .map((x, index) => {
//                   return (
//                     <div key={index}>
//                       {x[0]}: {x[1]}
//                     </div>
//                   )
//                 })}
//             </div>
//           ) : (
//             <div>
//               {supervisorReducer.supervisor.skills.map(x => (
//                 <div key={x}>{x}: 0</div>
//               ))}
//             </div>
//           )}
//         </Paper>
//         <Paper
//           className={classes.blockStats}
//           // style={{ background: "#00bfa5", color: "white" }}
//         >
//           <Typography variant="subtitle2" gutterBottom>
//             TOTAL CUSTOMER WAITING (sec)
//           </Typography>
//           {Object.entries(supervisorReducer.totalDuration) &&
//           Object.entries(supervisorReducer.totalDuration).length > 0 &&
//           supervisorReducer.supervisor.skills.length > 0 ? (
//             <div>
//               {Object.entries(supervisorReducer.totalDuration)
//                 .filter(x =>
//                   supervisorReducer.supervisor.skills.some(r =>
//                     x[0].includes(r)
//                   )
//                 )
//                 .map((x, index) => {
//                   return (
//                     <div key={index}>
//                       {x[0]}: {x[1] / 1000}
//                     </div>
//                   )
//                 })}
//             </div>
//           ) : (
//             <div>
//               {supervisorReducer.supervisor.skills.map(x => (
//                 <div key={x}>{x}: 0</div>
//               ))}
//             </div>
//           )}
//         </Paper>
//         <Paper
//           className={classes.blockStats}
//           // style={{ background: "#00bfa5", color: "white" }}
//         >
//           <Typography variant="subtitle2" gutterBottom>
//             AVG CUSTOMER WAITING (sec)
//           </Typography>
//           {Object.entries(supervisorReducer.totalDuration) &&
//           Object.entries(supervisorReducer.totalDuration).length > 0 &&
//           Object.entries(supervisorReducer.totalSessions).length > 0 &&
//           supervisorReducer.supervisor.skills.length > 0 ? (
//             <div>
//               {Object.entries(supervisorReducer.totalDuration)
//                 .filter(x =>
//                   supervisorReducer.supervisor.skills.some(r =>
//                     x[0].includes(r)
//                   )
//                 )
//                 .map((x, index) => {
//                   return (
//                     <div key={index}>
//                       {x[0]}: {x[1] / supervisorReducer.totalSessions[x[0]]}
//                     </div>
//                   )
//                 })}
//             </div>
//           ) : (
//             <div>
//               {supervisorReducer.supervisor.skills.map(x => (
//                 <div key={x}>{x}: 0</div>
//               ))}
//             </div>
//           )}
//         </Paper>
//       </div>
//       <div style={{ marginLeft: 8 }}>
//         <DropDownAgents
//           list={supervisorReducer.supervisor.skills}
//           title="Skills"
//           _setSkillSort={_setSkillSort}
//         />
//       </div>
//       <div style={{ display: "flex", flexWrap: "wrap" }}>
//         {supervisorReducer.agents
//           .filter(x =>
//             sortArg.toUpperCase() === "ALL"
//               ? x
//               : x.skills.some(e => sortArg.includes(e))
//           )
//           .map(x => (
//             <Card agent={x} key={x._id} />
//           ))}
//       </div>
//     </div>
//   )
// }

// export default Left
