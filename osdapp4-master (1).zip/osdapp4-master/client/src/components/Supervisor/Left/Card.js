import React from "react"
import { makeStyles } from "@material-ui/core/styles"
import Paper from "@material-ui/core/Paper"
import Avatar from "@material-ui/core/Avatar"
import Typography from "@material-ui/core/Typography"
import Rating from "@material-ui/lab/Rating"
import FormatListBulletedIcon from "@material-ui/icons/FormatListBulleted"
import CommentIcon from "@material-ui/icons/Comment"
import { Link } from "react-router-dom"
import Done from "@material-ui/icons/Done"
import Clear from "@material-ui/icons/Clear"
import Chip from "@material-ui/core/Chip"

const useStyles = makeStyles((theme) => ({
  root: {
    padding: theme.spacing(3, 2),
    margin: theme.spacing(1),
    width: 220,
    display: "flex",
    flexDirection: "column",
    flexWrap: "wrap",
    justifyContent: "center",
    alignItems: "center",
    cursor: "pointer",
    "&:hover": {
      opacity: 0.7,
    },
  },
  picProfile: {
    width: theme.spacing(8),
    height: theme.spacing(8),
  },
}))

const calculation = (agent) => ({
  ratings: {
    toTable: function () {
      const averageCalculate = (arr) => {
        let total = 0
        let counter = 0
        Object.entries(arr).map((x) => {
          const extractKey = Number(x[0].slice(5))
          if (!isNaN(extractKey)) {
            total = total + x[1] * extractKey
            counter = counter + x[1]
          }
        })
        if (!isNaN(total / counter)) {
          return total / counter
        } else {
          return 0
        }
      }
      return Object.entries(agent.ratings).map((x) => {
        return {
          name: `${x[0]}h`,
          ...x[1],
          average: averageCalculate(x[1]),
        }
      })
    },
  },
  status: {
    groupBy: function (xs, key) {
      return xs.reduce((rv, x) => {
        ;(rv[x[key]] = rv[x[key]] || []).push(x)
        return rv
      }, {})
    },
    totalDuration: function (arr) {
      return arr.reduce(function (acc, obj) {
        return acc + obj.duration
      }, 0)
    },
    keyFilter: function (key) {
      return agent.statusHistory.filter((x) => x.status === key)
    },
    timeAccu: function (key, subkey) {
      return this.keyFilter(key).reduce(function (acc, obj) {
        return acc + obj[subkey]
      }, 0)
    },
    timePerc: function (key) {
      // statusTimePerc("available") => 18%
      return Math.round(
        (100 / this.totalDuration(agent.statusHistory)) *
          this.timeAccu(key, "duration")
      )
    },
    totalWorkTime: function () {
      // workTimePerc("busy", "duration") => 18%
      return Math.round(
        (100 / this.totalDuration(agent.statusHistory)) *
          (this.timeAccu("busy", "duration") +
            this.timeAccu("wrapup", "duration"))
      )
    },
  },
})

const starsTotal = (ratings, star) =>
  Object.entries(ratings)
    .filter((x) => x[1].hasOwnProperty(star))
    .reduce(
      (accumulator, currentValue) => accumulator + currentValue[1][star],
      0
    )

const Card = ({ agent }) => {
  const avgStars = () => {
    const totalstar1 = starsTotal(agent.ratings, "stars1")
    const totalstar2 = starsTotal(agent.ratings, "stars2")
    const totalstar3 = starsTotal(agent.ratings, "stars3")
    const totalstar4 = starsTotal(agent.ratings, "stars4")
    const totalstar5 = starsTotal(agent.ratings, "stars5")
    const sumStars =
      totalstar1 * 1 +
      totalstar2 * 2 +
      totalstar3 * 3 +
      totalstar4 * 4 +
      totalstar5 * 5
    const countingStar =
      totalstar1 + totalstar2 + totalstar3 + totalstar4 + totalstar5

    return {
      count: countingStar,
      avg: sumStars / countingStar,
    }
  }

  const classes = useStyles()
  return (
    <a href={`/supervisor/${agent._id}`} style={{ textDecoration: "none" }}>
      <Paper
        className={classes.root}
        style={{ background: agent.status ? "white" : "#f5f5ff" }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            width: "100%",
          }}
        >
          <Avatar
            alt="Remy Sharp"
            src="https://www.pikerepublican.com/application/files/1515/5166/5566/avatarno.jpg"
            className={classes.picProfile}
          />
          <Chip
            icon={agent.status ? <Done /> : <Clear />}
            label={agent.status ? agent.status : "not active"}
            color={agent.status && "primary"}
            disabled={!agent.status}
            variant="outlined"
            style={{ textTransform: "capitalize", margin: "14px 0px" }}
          />
        </div>

        <div style={{ margin: "7px 0px" }}>{agent.email}</div>

        <div
          style={{
            color: "#aeaeae",
          }}
        ></div>
        <div style={{ display: "flex", flexWrap: "wrap" }}>
          {agent.skills.map((x, index) => (
            <div
              key={index}
              style={{
                margin: 3,
                border: "1px solid black",
                padding: 2,
                borderRadius: 3,
              }}
            >
              {x}
            </div>
          ))}
        </div>
        <div
          style={{
            width: "100%",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            margin: "7px 0px",
          }}
        >
          <div style={{ display: "flex", alignItems: "center" }}>
            <CommentIcon />{" "}
            {agent.status
              ? agent.statusHistory.filter((x) => x.status === "busy").length
              : 0}{" "}
            sessions
          </div>
        </div>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            width: "100%",
          }}
        >
          Rating:{" "}
          <Rating
            name="size-small"
            value={agent.ratings ? avgStars().avg : 0}
            size="small"
            readOnly
            precision={0.1}
          />
          ({agent.ratings ? avgStars().count : 0})
        </div>
        {agent.ratings && agent.statusHistory && (
          <div>
            Total:
            <div>
              Busy:
              {agent.statusHistory
                .filter((x) => x.status === "busy")
                .reduce((accumulator, currentValue) => {
                  return accumulator + currentValue.duration
                }, 0) / 1000}
              /sec
            </div>
            <div>
              Wrapup:
              {agent.statusHistory
                .filter((x) => x.status === "wrapup")
                .reduce((accumulator, currentValue) => {
                  return accumulator + currentValue.duration
                }, 0) / 1000}
              /sec
            </div>
            <div>
              In queue:
              {agent.statusHistory
                .filter((x) => x.status === "available")
                .reduce((accumulator, currentValue) => {
                  return accumulator + currentValue.duration
                }, 0) / 1000}
              /sec
            </div>
            <div>
              Disconnect:
              {agent.statusHistory
                .filter((x) => x.status === "disconnect")
                .reduce((accumulator, currentValue) => {
                  return accumulator + currentValue.duration
                }, 0) / 1000}
              /sec
            </div>
            <div>
              Break:
              {agent.statusHistory
                .filter((x) => x.status === "break")
                .reduce((accumulator, currentValue) => {
                  return accumulator + currentValue.duration
                }, 0) / 1000}
              /sec
            </div>
          </div>
        )}
        {/* <div
          style={{
            display: "flex",
            alignItems: "center",
            width: "100%",
            justifyContent: "space-between",
            margin: "7px 0px"
          }}
        >
          <div>Working Time:</div>
          <div>65%</div>
        </div>
        <div
          style={{
            width: "100%",
            background: "#e0e0e0",
            borderRadius: 7,
            height: 12,
            display: "flex",
            flexDirection: "row"
          }}
        >
          <div
            style={{
              width: "10%",
              height: 12,
              backgroundColor: "#00bfa5",
              borderTopLeftRadius: 7,
              borderBottomLeftRadius: 7
            }}
          />
          <div
            style={{ width: "15%", height: 12, backgroundColor: "#e072a4" }}
          />
          <div
            style={{ width: "3%", height: 12, backgroundColor: "#ffb74d" }}
          />
          <div
            style={{ width: "5%", height: 12, backgroundColor: "#e072a4" }}
          />
          <div
            style={{ width: "30%", height: 12, backgroundColor: "#00bfa5" }}
          />
        </div> */}
      </Paper>
    </a>
  )
}

export default Card
