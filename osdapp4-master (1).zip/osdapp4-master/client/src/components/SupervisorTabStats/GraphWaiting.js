import React from "react"
import dateFormat from "date-format"
import {
  ComposedChart,
  Line,
  Area,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from "recharts"

const data = [
  {
    name: "03/08",
    averageChatTime: 360,
    averageWaitingTime: 30
  },
  {
    name: "03/08",
    averageChatTime: 180,
    averageWaitingTime: 10
  },
  {
    name: "03/08",
    averageChatTime: 240,
    averageWaitingTime: 20
  },
  {
    name: "03/08",
    averageChatTime: 100,
    averageWaitingTime: 0
  },
  {
    name: "03/08",
    averageChatTime: 400,
    averageWaitingTime: 0
  },
  {
    name: "03/08",
    averageChatTime: 240,
    averageWaitingTime: 10
  },
  {
    name: "03/08",
    averageChatTime: 240,
    averageWaitingTime: 0
  },
  {
    name: "03/08",
    averageChatTime: 360,
    averageWaitingTime: 30
  },
  {
    name: "03/08",
    averageChatTime: 180,
    averageWaitingTime: 20
  },
  {
    name: "03/08",
    averageChatTime: 240,
    averageWaitingTime: 20
  },
  {
    name: "03/08",
    averageChatTime: 100,
    averageWaitingTime: 0
  },
  {
    name: "03/08",
    averageChatTime: 400,
    averageWaitingTime: 0
  },
  {
    name: "03/08",
    averageChatTime: 240,
    averageWaitingTime: 10
  },
  {
    name: "03/08",
    averageChatTime: 240,
    averageWaitingTime: 0
  },
  {
    name: "03/08",
    averageChatTime: 100,
    averageWaitingTime: 0
  },
  {
    name: "03/08",
    averageChatTime: 400,
    averageWaitingTime: 0
  },
  {
    name: "03/08",
    averageChatTime: 240,
    averageWaitingTime: 10
  },
  {
    name: "03/08",
    averageChatTime: 240,
    averageWaitingTime: 0
  },
  {
    name: "03/08",
    averageChatTime: 360,
    averageWaitingTime: 30
  },
  {
    name: "03/08",
    averageChatTime: 180,
    averageWaitingTime: 40
  },
  {
    name: "03/08",
    averageChatTime: 240,
    averageWaitingTime: 20
  },
  {
    name: "03/08",
    averageChatTime: 100,
    averageWaitingTime: 0
  },
  {
    name: "03/08",
    averageChatTime: 20,
    averageWaitingTime: 0
  },
  {
    name: "03/08",
    averageChatTime: 240,
    averageWaitingTime: 10
  },
  {
    name: "03/08",
    averageChatTime: 240,
    averageWaitingTime: 0
  }
]

const tickComp = sec => {
  const date = new Date(sec * 1000)

  return dateFormat("mm:ss", date)
}

const GraphWaiting = () => {
  return (
    <ComposedChart
      width={1000}
      height={400}
      data={data}
      margin={{
        top: 20,
        right: 80,
        bottom: 20,
        left: 20
      }}
    >
      <CartesianGrid stroke="#f5f5f5" />
      <XAxis
        dataKey="name"
        //   label={{ value: "Dates", position: "insideBottomRight", offset: 0 }}
      />
      <YAxis
        tickFormatter={tickComp}
        dataKey="averageChatTime"
        label={{
          value: "average chat time",
          angle: -90,
          position: "insideLeft"
        }}
      />
      <YAxis
        tickFormatter={tickComp}
        yAxisId="right"
        type="number"
        dataKey="averageWaitingTime"
        name="waiting time"
        orientation="right"
        label={{
          value: "average waiting time",
          angle: 90,
          position: "insideRight"
        }}
      />
      <Tooltip />
      <Legend />
      <Bar dataKey="averageChatTime" stackId="a" fill="#ffbf29" />
      <Line
        strokeWidth={4}
        yAxisId={"right"}
        type="monotone"
        dataKey="averageWaitingTime"
        stroke="#ff546e"
      />
    </ComposedChart>
  )
}

export default GraphWaiting
