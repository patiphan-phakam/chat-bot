import React from "react"
import Avatar from "@material-ui/core/Avatar"

const MsgAgent = ({ message, time }) => {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "flex-end",
        width: "100%",
        margin: "10px 0px"
      }}
    >
      <div
        style={{
          marginRight: 5,
          borderRadius: 5,
          background: "#78afd6",
          padding: 5,
          color: "black",
          maxWidth: "73%"
        }}
      >
        <div style={{ fontWeight: "bold" }}>Agent</div>
        {message}
      </div>
      <div>
        <Avatar>A</Avatar>
        <div>{time}</div>
      </div>
    </div>
  )
}

const MsgSupervisor = ({ message, time }) => {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "flex-start",
        width: "100%",
        margin: "10px 0px"
      }}
    >
      <div>
        <Avatar>S</Avatar>
        <div>{time}</div>
      </div>

      <div
        style={{
          marginLeft: 5,
          borderRadius: 5,
          background: "#faff69",
          padding: 5,
          color: "black",
          maxWidth: "73%"
        }}
      >
        <div style={{ fontWeight: "bold" }}>Supervisor</div>
        {message}
      </div>
    </div>
  )
}

const Content = () => {
  return (
    <div
      style={{
        overflowY: "scroll",
        height: "calc(100vh - 335px)",
        paddingRight: "15px"
      }}
    >
      <MsgAgent message="hi" time="10:20" />
      <MsgSupervisor message="hi" time="10:21" />
      <MsgSupervisor message="123 dsfsdf sdvds" time="10:21" />
      <MsgAgent message="hi ok" time="10:22" />
      <MsgAgent
        message="Thisis long message avsfd fdsjf sdfj shdfkjsdh fksdjfh skdjfhdsjf dsfhsdjk"
        time="10:22"
      />
      <MsgSupervisor message="blablabalba ablalba llaba labla" time="10:21" />
      <MsgAgent message="hi ok" time="10:22" />
      <MsgAgent message="hi ok" time="10:22" />
      <MsgAgent message="hi" time="10:20" />
      <MsgSupervisor message="hi" time="10:21" />
      <MsgSupervisor message="123 dsfsdf sdvds" time="10:21" />
      <MsgAgent message="hi ok" time="10:22" />
      <MsgAgent
        message="Thisis long message avsfd fdsjf sdfj shdfkjsdh fksdjfh skdjfhdsjf dsfhsdjk"
        time="10:22"
      />
      <MsgSupervisor message="blablabalba ablalba llaba labla" time="10:21" />
      <MsgAgent message="hi ok" time="10:22" />
      <MsgAgent message="hi ok" time="10:22" />
    </div>
  )
}

export default Content
