import React from "react"
import Button from "@material-ui/core/Button"
import TextField from "@material-ui/core/TextField"
import SendIcon from "@material-ui/icons/Send"

const InputChat = () => {
  return (
    <div style={{ height: 51, display: "flex", marginTop: 10 }}>
      <TextField
        id="outlined-textarea"
        label="To supervisor"
        placeholder="To supervisor"
        multiline
        variant="outlined"
        fullWidth
      />
      <Button variant="contained" color="primary" style={{ marginLeft: 10 }}>
        <SendIcon />
      </Button>
    </div>
  )
}

export default InputChat
