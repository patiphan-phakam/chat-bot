import React from "react"
import Paper from "@material-ui/core/Paper"
import InputChat from "./InputChat"
import HeaderChat from "./HeaderChat"
import Content from "./Content"

const ChatContent = () => {
  return (
    <Paper
      style={{
        color: "#757575",
        padding: 15,
        display: "flex",
        flexDirection: "column",
        width: 400,
        margin: 15
      }}
    >
      <HeaderChat />
      <Content />
      <InputChat />
    </Paper>
  )
}

export default ChatContent
