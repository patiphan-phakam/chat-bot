import React, { useState } from "react"
import Sliderz from "./Sliderz"
import {
  ComposedChart,
  Line,
  ResponsiveContainer,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from "recharts"

const data = [
  {
    name: "03/08",
    chats: 60,
    missedChats: 20,
    refusedChats: 10,
    acceptanceRate: 100
  },
  {
    name: "04/08",
    chats: 90,
    missedChats: 40,
    refusedChats: 10,
    acceptanceRate: 90
  },
  {
    name: "05/08",
    chats: 190,
    missedChats: 50,
    refusedChats: 70,
    acceptanceRate: 80
  },
  {
    name: "06/08",
    chats: 190,
    missedChats: 10,
    refusedChats: 10,
    acceptanceRate: 95
  },
  {
    name: "07/08",
    chats: 120,
    missedChats: 0,
    refusedChats: 0,
    acceptanceRate: 100
  },
  {
    name: "08/08",
    chats: 120,
    missedChats: 20,
    refusedChats: 40,
    acceptanceRate: 95
  },
  {
    name: "09/08",
    chats: 90,
    missedChats: 5,
    refusedChats: 5,
    acceptanceRate: 90
  },
  {
    name: "10/08",
    chats: 95,
    missedChats: 2,
    refusedChats: 8,
    acceptanceRate: 92
  },
  {
    name: "03/08",
    chats: 60,
    missedChats: 20,
    refusedChats: 10,
    acceptanceRate: 100
  },
  {
    name: "04/08",
    chats: 90,
    missedChats: 40,
    refusedChats: 10,
    acceptanceRate: 90
  },
  {
    name: "05/08",
    chats: 190,
    missedChats: 50,
    refusedChats: 70,
    acceptanceRate: 80
  },
  {
    name: "06/08",
    chats: 190,
    missedChats: 10,
    refusedChats: 10,
    acceptanceRate: 95
  },
  {
    name: "07/08",
    chats: 120,
    missedChats: 0,
    refusedChats: 0,
    acceptanceRate: 100
  },
  {
    name: "08/08",
    chats: 120,
    missedChats: 20,
    refusedChats: 40,
    acceptanceRate: 95
  },
  {
    name: "09/08",
    chats: 90,
    missedChats: 5,
    refusedChats: 5,
    acceptanceRate: 90
  },
  {
    name: "10/08",
    chats: 95,
    missedChats: 2,
    refusedChats: 8,
    acceptanceRate: 92
  },
  {
    name: "04/08",
    chats: 90,
    missedChats: 40,
    refusedChats: 10,
    acceptanceRate: 90
  },
  {
    name: "05/08",
    chats: 190,
    missedChats: 50,
    refusedChats: 70,
    acceptanceRate: 80
  },
  {
    name: "06/08",
    chats: 190,
    missedChats: 10,
    refusedChats: 10,
    acceptanceRate: 95
  },
  {
    name: "07/08",
    chats: 120,
    missedChats: 0,
    refusedChats: 0,
    acceptanceRate: 100
  },
  {
    name: "08/08",
    chats: 120,
    missedChats: 20,
    refusedChats: 40,
    acceptanceRate: 95
  },
  {
    name: "09/08",
    chats: 90,
    missedChats: 5,
    refusedChats: 5,
    acceptanceRate: 90
  },
  {
    name: "10/08",
    chats: 95,
    missedChats: 2,
    refusedChats: 8,
    acceptanceRate: 92
  }
]

const GraphChatVolum = () => {
  const [rangeGraph, setrangeGraph] = useState([0, data.length - 1])

  const _setRangeGraph = (e, newValue) => {
    setrangeGraph(newValue)
  }

  const data2 = data.slice(rangeGraph[0], rangeGraph[1])

  return (
    <div>
      <ComposedChart
        width={1000}
        height={400}
        data={data2}
        margin={{
          top: 20,
          right: 80,
          bottom: 20,
          left: 20
        }}
      >
        <CartesianGrid stroke="#f5f5f5" />
        <XAxis
          dataKey="name"
          //   label={{ value: "Dates", position: "insideBottomRight", offset: 0 }}
        />
        <YAxis label={{ value: "Index", angle: -90, position: "insideLeft" }} />
        <YAxis
          unit="%"
          yAxisId="right"
          type="number"
          dataKey="average"
          name="average rating"
          orientation="right"
          label={{
            value: "acceptance rate",
            angle: 90,
            position: "insideRight"
          }}
          ticks={[0, 25, 50, 75, 100]}
        />
        <Tooltip />
        <Legend />
        <Bar dataKey="chats" stackId="a" fill="#0c60c2" />
        <Bar dataKey="missedChats" stackId="a" fill="#217feb" />
        <Bar dataKey="refusedChats" stackId="a" fill="#8fc3ff" />
        <Line
          strokeWidth={4}
          yAxisId={"right"}
          type="monotone"
          dataKey="acceptanceRate"
          stroke="#7fc722"
        />
      </ComposedChart>
      <div style={{ width: "100%", display: "flex", justifyContent: "center" }}>
        <Sliderz
          rangeGraph={rangeGraph}
          _setRangeGraph={_setRangeGraph}
          arrayLength={data.length - 1}
        />
      </div>
    </div>
  )
}

export default GraphChatVolum
