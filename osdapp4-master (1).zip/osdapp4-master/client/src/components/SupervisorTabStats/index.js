import React from "react"
import GraphRating from "./GraphRating"
import GraphChatVolum from "./GraphChatVolum"
import GraphWaiting from "./GraphWaiting"
import ChatSupervisorAgent from "./ChatSupervisorAgent"
import ChatCustomerAgent from "./ChatCustomerAgent"

const SupervisorTabStats = () => {
  return (
    <div>
      <GraphRating />
      <GraphChatVolum />
      <GraphWaiting />
    </div>
  )
}

export default SupervisorTabStats
