import React, { PureComponent } from "react"
import Sliderz from "./Sliderz"
import {
  ComposedChart,
  Line,
  Area,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from "recharts"

const data = [
  {
    name: "03/08",
    stars5: 60,
    stars4: 20,
    stars3: 10,
    stars2: 5,
    stars1: 5,
    average: 3
  },
  {
    name: "04/08",
    stars5: 130,
    stars4: 30,
    stars3: 40,
    stars2: 12,
    stars1: 20,
    average: 3.5
  },
  {
    name: "05/08",
    stars5: 140,
    stars4: 50,
    stars3: 30,
    stars2: 15,
    stars1: 5,
    average: 4
  },
  {
    name: "06/08",
    stars5: 160,
    stars4: 30,
    stars3: 10,
    stars2: 40,
    stars1: 5,
    average: 4.5
  },
  {
    name: "07/08",
    stars5: 80,
    stars4: 60,
    stars3: 40,
    stars2: 25,
    stars1: 15,
    average: 3.5
  },
  {
    name: "08/08",
    stars5: 50,
    stars4: 36,
    stars3: 10,
    stars2: 5,
    stars1: 5,
    average: 3
  },
  {
    name: "09/08",
    stars5: 180,
    stars4: 90,
    stars3: 10,
    stars2: 5,
    stars1: 5,
    average: 4.8
  },
  {
    name: "10/08",
    stars5: 60,
    stars4: 20,
    stars3: 10,
    stars2: 5,
    stars1: 30,
    average: 3
  }
]

export default class Graph1 extends PureComponent {
  static jsfiddleUrl = "https://jsfiddle.net/alidingling/q5atk5jr/"

  render() {
    return (
      <div>
        <ComposedChart
          width={500}
          height={400}
          data={data}
          margin={{
            top: 20,
            right: 80,
            bottom: 20,
            left: 20
          }}
        >
          <CartesianGrid stroke="#f5f5f5" />
          <XAxis
            dataKey="name"
            //   label={{ value: "Dates", position: "insideBottomRight", offset: 0 }}
          />
          <YAxis
            label={{ value: "Index", angle: -90, position: "insideLeft" }}
          />
          <YAxis
            yAxisId="right"
            type="number"
            dataKey="average"
            name="average rating"
            orientation="right"
            label={{
              value: "average rating",
              angle: 90,
              position: "insideRight"
            }}
            ticks={[0, 1, 2, 3, 4, 5]}
            height={50}
          />
          <Tooltip />
          <Legend />
          <Bar dataKey="stars5" stackId="a" fill="#eb3434" />
          <Bar dataKey="stars4" stackId="a" fill="#eb6b34" />
          <Bar dataKey="stars3" stackId="a" fill="#eb9f34" />
          <Bar dataKey="stars2" stackId="a" fill="#ebb734" />
          <Bar dataKey="stars1" stackId="a" fill="#f2f218" />
          <Line
            strokeWidth={4}
            yAxisId={"right"}
            type="monotone"
            dataKey="average"
            stroke="#7fc722"
          />
        </ComposedChart>
      </div>
    )
  }
}
