import React, { useEffect, useState } from "react"
import { makeStyles } from "@material-ui/core/styles"
import ListItem from "@material-ui/core/ListItem"
import Avatar from "@material-ui/core/Avatar"
import Checkbox from "@material-ui/core/Checkbox"
import Paper from "@material-ui/core/Paper"
import Button from "@material-ui/core/Button"
import ChevronLeft from "@material-ui/icons/ChevronLeft"
import ChevronRight from "@material-ui/icons/ChevronRight"

const useStyles = makeStyles((theme) => ({
  list: {
    display: "flex",
    justifyContent: "space-between",
    minWidth: 280,
  },
}))

const compare = (a, b) => {
  if (a._id > b._id) return 1
  if (b._id > a._id) return -1
}

export default ({
  adminReducer,
  selectedSkill,
  _checkAgentBox,
  _assignSkillAgent,
}) => {
  const classes = useStyles()

  const listLeft = (
    <div style={{ position: "relative" }}>
      <div
        style={{
          position: "absolute",
          top: -25,
          left: 0,
          right: 0,
          textAlign: "center",
        }}
      >
        Agents available
      </div>
      <Paper style={{ padding: 6 }}>
        {adminReducer.agents
          .filter((x) => !x.skills.includes(selectedSkill))
          .sort(compare)
          .map((x, i) => (
            <ListItem
              key={i}
              button
              className={classes.list}
              onClick={() => _checkAgentBox(!x.checked, x)}
            >
              <div style={{ display: "flex" }}>
                <Avatar style={{ marginRight: 15 }}>H</Avatar>
                <div>
                  <div style={{ fontWeight: "bold" }}>{x._id}</div>
                  <div style={{ color: " gray" }}>{x.email}</div>
                </div>
              </div>
              <div>
                <Checkbox
                  checked={x.checked}
                  inputProps={{ "aria-label": "primary checkbox" }}
                />
              </div>
            </ListItem>
          ))}
      </Paper>
    </div>
  )

  const listRight = (
    <div style={{ position: "relative" }}>
      <div
        style={{
          position: "absolute",
          top: -25,
          left: 0,
          right: 0,
          textAlign: "center",
        }}
      >
        Agents Assigned
      </div>
      <Paper style={{ padding: 6 }}>
        {adminReducer.agents
          .filter((x) => x.skills.includes(selectedSkill))
          .sort(compare)
          .map((x, i) => (
            <ListItem
              key={i}
              button
              className={classes.list}
              onClick={() => _checkAgentBox(!x.checked, x)}
            >
              <div style={{ display: "flex" }}>
                <Avatar style={{ marginRight: 15 }}>H</Avatar>
                <div>
                  <div style={{ fontWeight: "bold" }}>{x._id}</div>
                  <div style={{ color: " gray" }}>{x.email}</div>
                </div>
              </div>
              <div>
                <Checkbox
                  checked={x.checked}
                  inputProps={{ "aria-label": "primary checkbox" }}
                />
              </div>
            </ListItem>
          ))}
      </Paper>
    </div>
  )

  return (
    <div style={{ display: "flex" }}>
      <div style={{ margin: 6 }}>{listLeft}</div>
      <div style={{ marginTop: 50 }}>
        <Button
          onClick={() =>
            adminReducer.agents.filter((x) => x.checked).length > 0 &&
            _assignSkillAgent(false)
          }
          variant="contained"
          style={{ margin: 3 }}
        >
          <ChevronLeft />
        </Button>
        <Button
          style={{ margin: 3 }}
          onClick={() =>
            adminReducer.agents.filter((x) => x.checked).length > 0 &&
            _assignSkillAgent(true)
          }
          variant="contained"
        >
          <ChevronRight />
        </Button>
      </div>
      <div style={{ margin: 6 }}>{listRight}</div>
    </div>
  )
}
