import React from "react"
import PropTypes from "prop-types"
import { makeStyles } from "@material-ui/core/styles"
import Tabs from "@material-ui/core/Tabs"
import Tab from "@material-ui/core/Tab"
import Typography from "@material-ui/core/Typography"
import Box from "@material-ui/core/Box"
import TrasnfrList from "./TrasnfrList"
import Paper from "@material-ui/core/Paper"
import Button from "@material-ui/core/Button"

function TabPanel(props) {
  const { children, value, index, ...other } = props

  return (
    <Typography
      component="div"
      role="tabpanel"
      hidden={value !== index}
      id={`vertical-tabpanel-${index}`}
      aria-labelledby={`vertical-tab-${index}`}
      {...other}
    >
      {value === index && <Box p={3}>{children}</Box>}
    </Typography>
  )
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired,
}

function a11yProps(index) {
  return {
    id: `vertical-tab-${index}`,
    "aria-controls": `vertical-tabpanel-${index}`,
  }
}

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
    display: "flex",
    height: "100%",
  },
  tabs: {
    borderRight: `1px solid ${theme.palette.divider}`,
  },
}))

export default function VerticalTabs({
  adminReducer,
  _selectedSkill,
  selectedSkill,
  _checkAgentBox,
  _resetAgentBox,
  _assignSkillAgent,
  trsfrIsLocked,
  _trsfrIsLocked,
  _readAgents,
  _confirmSkill,
}) {
  const classes = useStyles()
  const [value, setValue] = React.useState(0)

  const handleChange = (event, newValue) => {
    setValue(newValue)
  }

  return (
    <Paper style={{ padding: 15, position: "relative" }}>
      {trsfrIsLocked && (
        <Lock
          _readAgents={_readAgents}
          _trsfrIsLocked={_trsfrIsLocked}
          _confirmSkill={_confirmSkill}
        />
      )}
      <div className={classes.root}>
        <div>
          <div
            style={{
              width: "100%",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <Typography variant="h5" className={classes.title} gutterBottom>
              SKILLS
            </Typography>
          </div>
          <Tabs
            orientation="vertical"
            variant="scrollable"
            value={value}
            onChange={handleChange}
            aria-label="Vertical tabs example"
            className={classes.tabs}
          >
            {adminReducer.settings.skills.map((x, index) => (
              <Tab
                label={x}
                key={index}
                {...a11yProps({ index })}
                onClick={() => {
                  _selectedSkill(x)
                  _resetAgentBox()
                }}
              />
            ))}
          </Tabs>
        </div>
        {adminReducer.settings.skills.map((x, index) => (
          <TabPanel value={value} index={index}>
            <TrasnfrList
              adminReducer={adminReducer}
              selectedSkill={selectedSkill}
              _checkAgentBox={_checkAgentBox}
              _assignSkillAgent={_assignSkillAgent}
            />
          </TabPanel>
        ))}
      </div>
    </Paper>
  )
}

const Lock = ({ _readAgents, _trsfrIsLocked, _confirmSkill }) => {
  return (
    <div
      style={{
        position: "absolute",
        top: 0,
        bottom: 0,
        left: 0,
        right: 0,
        background: "rgba(0, 0, 0, 0.5)",
        zIndex: 3,
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <Paper style={{ padding: 20 }}>
        <Typography style={{ textAlign: "center" }} variant="h5" gutterBottom>
          Confirm
        </Typography>
        <Button
          onClick={() => _confirmSkill()}
          style={{ margin: 5 }}
          variant="contained"
          color="primary"
        >
          Save
        </Button>
        <Button
          onClick={() => {
            _readAgents()
            _trsfrIsLocked()
          }}
          style={{ margin: 5 }}
          variant="contained"
        >
          Cancel
        </Button>
      </Paper>
    </div>
  )
}
