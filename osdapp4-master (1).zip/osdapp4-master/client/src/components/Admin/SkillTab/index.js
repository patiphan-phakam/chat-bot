import React, { useEffect, useState } from "react"
import Tabs from "./Tabs"

export default ({
  _readSettings,
  adminReducer,
  _readAgents,
  _checkAgentBox,
  _resetAgentBox,
  _assignSkillAgent,
  _selectedSkill,
  selectedSkill,
  trsfrIsLocked,
  _trsfrIsLocked,
  _confirmSkill
}) => {
  useEffect(() => {
    _readAgents()
    _readSettings()
  }, [])

  return (
    <div>
      <Tabs
        adminReducer={adminReducer}
        _selectedSkill={_selectedSkill}
        selectedSkill={selectedSkill}
        _checkAgentBox={_checkAgentBox}
        _resetAgentBox={_resetAgentBox}
        _assignSkillAgent={_assignSkillAgent}
        trsfrIsLocked={trsfrIsLocked}
        _trsfrIsLocked={_trsfrIsLocked}
        _readAgents={_readAgents}
        _confirmSkill={_confirmSkill}
      />
    </div>
  )
}
