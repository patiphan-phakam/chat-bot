import React from "react"
import ListContact from "./ListContact"
import SearchInput from "./SearchInput"

const History = ({
  agentReducer,
  _inputSearch,
  inputSearch,
  _sortHistory,
  _selectHistoryProfile,
}) => {
  return (
    <div
      style={{
        width: 180,
        borderRight: "1px solid #e0e0e0",
      }}
    >
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: 60,
          borderBottom: "1px solid #e0e0e0",
          color: "#3d6376",
          fontWeight: "bold",
        }}
      >
        <SearchInput
          _inputSearch={_inputSearch}
          inputSearch={inputSearch}
          _sortHistory={_sortHistory}
        />
      </div>
      <div>
        <ListContact
          agentReducer={agentReducer}
          _selectHistoryProfile={_selectHistoryProfile}
        />
      </div>
    </div>
  )
}

export default History
