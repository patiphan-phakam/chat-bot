import React from "react"
import { makeStyles } from "@material-ui/core/styles"
import List from "@material-ui/core/List"
import ListItem from "@material-ui/core/ListItem"
import ListItemText from "@material-ui/core/ListItemText"
import ListItemAvatar from "@material-ui/core/ListItemAvatar"
import Avatar from "@material-ui/core/Avatar"

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    maxWidth: 360,
    backgroundColor: theme.palette.background.paper,
    height: "calc(100vh - 124px)",
  },
}))

export default function ListContact({ agentReducer, _selectHistoryProfile }) {
  const classes = useStyles()
  const [checked, setChecked] = React.useState([1])

  const handleToggle = (value) => () => {
    const currentIndex = checked.indexOf(value)
    const newChecked = [...checked]

    if (currentIndex === -1) {
      newChecked.push(value)
    } else {
      newChecked.splice(currentIndex, 1)
    }

    setChecked(newChecked)
  }

  return (
    <List dense className={classes.root}>
      {agentReducer &&
        agentReducer.customers &&
        agentReducer.customers.length > 0 &&
        agentReducer.customers.map((x) => {
          const labelId = `${x.id + x.firstname}`
          return (
            <ListItem
              key={x.id}
              button
              onClick={() =>
                _selectHistoryProfile({
                  agentId: agentReducer._id,
                  channel: x.channel,
                  skill: x.skill,
                  userId: x._id,
                  first_name: x.firstname,
                  timezone: 0,
                  last_name: x.lastname,
                  gender: x.gender,
                  profile_pic: "",
                  notes: x.notes,
                  address: x.address,
                  email: x.email,
                  mobile: x.mobile,
                  flow: x.chat,
                })
              }
            >
              <ListItemAvatar>
                <Avatar>
                  {x.firstname
                    ? x.firstname.charAt(0).toUpperCase()
                    : "no name"}
                </Avatar>
              </ListItemAvatar>
              <ListItemText
                id={labelId}
                primary={
                  <div>
                    <div
                      style={{ fontWeight: "bold" }}
                    >{`${x.firstname} ${x.lastname}`}</div>
                    <div
                      style={{
                        color: "#8f8f8f",
                        fontSize: 12,
                      }}
                    >
                      {/* {x.timestamps} */}
                    </div>
                  </div>
                }
              />
            </ListItem>
          )
        })}
    </List>
  )
}
