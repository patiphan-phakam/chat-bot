import React from "react"
import { makeStyles } from "@material-ui/core/styles"
import TextField from "@material-ui/core/TextField"
import SwapVertIcon from "@material-ui/icons/SwapVert"
import IconButton from "@material-ui/core/IconButton"

const useStyles = makeStyles({
  root: {
    fontSize: 18,
    marginBottom: 10
  },
  button: {
    height: 50,
    marginTop: 19
  },
  underline: {
    "&&&:before": {
      borderBottom: "none"
    },
    "&&:after": {
      borderBottom: "none"
    }
  }
})

export default function SearchInput({
  _inputSearch,
  inputSearch,
  _sortHistory
}) {
  const classes = useStyles()

  return (
    <div style={{ display: "flex" }}>
      <IconButton
        className={classes.button}
        aria-label="delete"
        onClick={_sortHistory}
      >
        <SwapVertIcon />
      </IconButton>
      <TextField
        onChange={e => _inputSearch(e.target.value)}
        value={inputSearch}
        id="standard-basic"
        InputProps={{ classes }}
        label="Search"
        margin="normal"
      />
    </div>
  )
}
