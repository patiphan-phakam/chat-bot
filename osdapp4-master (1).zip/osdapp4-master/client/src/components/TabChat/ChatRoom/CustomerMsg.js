import React from "react"
import Avatar from "@material-ui/core/Avatar"
import dateFormat from "dateformat"

const CustomerMsg = ({ text = "customer default msg", date }) => {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "flex-start",
        padding: "15px 15px 0px 15px",
      }}
    >
      <Avatar>C</Avatar>
      <div style={{ margin: "0px 20px 0px 15px" }}>
        {date && (
          <div style={{ color: "#D2D7D3", fontSize: 9 }}>
            {dateFormat(date, "dd/mm HH:MM")}
          </div>
        )}
        <div
          style={{
            position: "relative",
            backgroundColor: "#f50057",
            margin: "0px 15px 0px 0px",
            padding: 10,
            color: "white",
            borderRadius: 5,
          }}
        >
          <div
            style={{
              position: "absolute",
              left: -15,
              top: 0,
              width: 0,
              height: 0,
              borderStyle: "solid",
              borderWidth: "0px 10px 20px",
              borderColor: "transparent#f50057 transparent transparent",
            }}
          ></div>
          <div>{text}</div>
        </div>
      </div>
    </div>
  )
}

export default CustomerMsg
