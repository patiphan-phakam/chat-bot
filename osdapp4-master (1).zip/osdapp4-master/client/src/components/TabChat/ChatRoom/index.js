import React from "react"
import TextField from "@material-ui/core/TextField"
import CustomerMsg from "./CustomerMsg"
import AgentMsg from "./AgentMsg"
import BtnSubmit from "./BtnSubmit"
import HeaderChat from "./HeaderChat"

const ChatRoom = ({
  inputText,
  state,
  _inputTextSubmit,
  _inputText,
  countSec,
  countMin,
  deciSec,
  counterMsg,
  newMsgLoading,
  _break,
  _resume,
}) => {
  return (
    <div
      style={{
        flexGrow: 1,
        minWidth: 500,
        backgroundColor: "white",
        borderRight: "1px solid #e0e0e0",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <HeaderChat
        countSec={countSec}
        countMin={countMin}
        deciSec={deciSec}
        counterMsg={counterMsg}
        state={state}
        _break={_break}
        _resume={_resume}
      />
      {state.userInfo.userId === "" ? (
        <div>waiting for customer to connect</div>
      ) : (
        <>
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              backgroundColor: "white",
              width: "100%",
              height: "calc(100vh - 240px)",
              overflowY: "scroll",
              paddingBottom: 15,
            }}
          >
            {state.flow
              .sort((a, b) => new Date(a.date) - new Date(b.date))
              .map(({ msg, author, type, date }) => {
                return author === "agent" ? (
                  <AgentMsg text={msg} date={date} />
                ) : (
                  <CustomerMsg text={msg} date={date} />
                )
              })}
            {newMsgLoading && <AgentMsg text={"sending..."} />}
          </div>
          {state.agentStatus.status === "busy" && (
            <div
              style={{
                minHeight: 100,
                borderTop: "1px solid #e0e0e0",
              }}
            >
              <div style={{ margin: 20, display: "flex" }}>
                <TextField
                  value={inputText}
                  onChange={_inputText}
                  fullWidth
                  id="outlined-multiline-static"
                  label="To customer"
                  multiline
                  rows="2"
                  defaultValue="Default Value"
                  variant="outlined"
                />
                <div
                  style={{ display: "flex", alignItems: "center" }}
                  onClick={_inputTextSubmit}
                >
                  <BtnSubmit />
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}

export default ChatRoom
