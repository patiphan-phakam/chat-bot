import React, { useEffect } from "react"
import Switch from "@material-ui/core/Switch"

const styles = {
  label: {
    textAlign: "center",
    marginTop: -10,
  },
}

export default function Switches({ state, _break, _resume }) {
  //[start, wrapup, break]
  const [stateBtn, setStateBtn] = React.useState(null)

  useEffect(() => {
    const { status } = state.agentStatus
    if (status !== "") {
      console.log(status)
    }
    if (status === "available" || status === "busy") {
      setStateBtn("start")
    }
    if (status === "wrapup") {
      setStateBtn("wrapup")
    }
    if (status === "break") {
      setStateBtn("break")
    }
  }, [state.agentStatus.status])

  return (
    <div style={{ display: "flex", fontSize: 14 }}>
      {/* {state.agentStatus.status} */}
      {(state.agentStatus.status === "break" ||
        state.agentStatus.status === "wrapup") && (
        <div
          style={{
            padding: "0px 10px 0px 10px",
          }}
        >
          <Switch
            checked={stateBtn === "start"}
            onChange={() => {
              setStateBtn("start")
              _resume()
            }}
            value="start"
            color="primary"
            inputProps={{ "aria-label": "primary checkbox" }}
          />
          <div style={styles.label}>Start</div>
        </div>
      )}

      {state.agentStatus.status === "wrapup" && (
        <div
          style={{
            borderRight: "1px solid #ccc",
            borderLeft: "1px solid #ccc",
            padding: "0px 10px 0px 10px",
          }}
        >
          <Switch
            checked={stateBtn === "wrapup"}
            onChange={() => setStateBtn("wrapup")}
            value="wrapup"
            color="primary"
            inputProps={{ "aria-label": "primary checkbox" }}
          />
          <div style={styles.label}>Take notes</div>
        </div>
      )}

      {(state.agentStatus.status === "wrapup" ||
        state.agentStatus.status === "break") && (
        <div
          style={{
            padding: "0px 10px 0px 10px",
          }}
        >
          <Switch
            checked={stateBtn === "break"}
            onChange={() => {
              setStateBtn("break")
              _break()
            }}
            value="break"
            color="primary"
            inputProps={{ "aria-label": "primary checkbox" }}
          />
          <div style={styles.label}>Break</div>
        </div>
      )}
    </div>
  )
}
