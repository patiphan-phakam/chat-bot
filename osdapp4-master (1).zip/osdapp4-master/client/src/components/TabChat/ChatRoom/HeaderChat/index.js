import React from "react"
import Counter from "../../Counter"
import SwitchButtons from "./SwitchButtons"
import ForumIcon from "@material-ui/icons/Forum"

const HeaderChat = ({
  countSec,
  countMin,
  deciSec,
  counterMsg,
  state,
  _break,
  _resume
}) => {
  return (
    <div
      style={{
        backgroundColor: "#f6f6f6",
        height: 60,
        borderBottom: "1px solid #e0e0e0",
        fontSize: 25,
        padding: "0px 0px 0px 15px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between"
      }}
    >
      <div
        style={{
          paddingLeft: 10,
          display: "flex",
          alignItems: "center"
        }}
      >
        <div
          style={{
            marginRight: 5,
            height: "100%",
            display: "flex",
            alignItems: "center"
          }}
        >
          <ForumIcon />
        </div>

        <Counter
          countSec={countSec}
          countMin={countMin}
          counterMsg={counterMsg}
        />
      </div>
      <div>
        <SwitchButtons state={state} _break={_break} _resume={_resume} />
      </div>
    </div>
  )
}

export default HeaderChat
