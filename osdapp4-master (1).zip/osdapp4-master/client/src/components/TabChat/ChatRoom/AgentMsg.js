import React from "react"
import dateFormat from "dateformat"

const AgentMsg = ({ text = "agent default msg", date }) => {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "flex-end",
      }}
    >
      <div style={{ margin: "15px 20px 0px 15px" }}>
        {date && (
          <div style={{ color: "gray", fontSize: 9 }}>
            {dateFormat(date, "dd/mm HH:MM")}
          </div>
        )}
        <div
          style={{
            position: "relative",
            backgroundColor: "#3f51b5",

            padding: 10,
            color: "white",
            borderRadius: 5,
          }}
        >
          <div
            style={{
              position: "absolute",
              right: -5,
              top: 0,
              width: 0,
              height: 0,
              borderStyle: "solid",
              borderWidth: "0px 0 20px 10px",
              borderColor: "transparent transparent transparent #3f51b5",
            }}
          ></div>
          <div>{text}</div>
        </div>
      </div>
    </div>
  )
}

export default AgentMsg
