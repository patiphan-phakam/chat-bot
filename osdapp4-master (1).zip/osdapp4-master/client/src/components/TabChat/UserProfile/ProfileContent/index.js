import React, { useState, useEffect } from "react"
import { makeStyles } from "@material-ui/core/styles"
import TextField from "@material-ui/core/TextField"
import Checkbox from "@material-ui/core/Checkbox"
import FormControlLabel from "@material-ui/core/FormControlLabel"
import Button from "@material-ui/core/Button"
import InputLabel from "@material-ui/core/InputLabel"
import MenuItem from "@material-ui/core/MenuItem"
import FormHelperText from "@material-ui/core/FormHelperText"
import FormControl from "@material-ui/core/FormControl"
import Select from "@material-ui/core/Select"
import SnackBr from "../../../SnackBr"

const styles = {
  inputContainer: {
    display: "flex",
    alignItems: "center",
    width: "100%"
  },
  inputSubContainer: {
    width: "100%"
  },
  inputTitle: {
    fontWeight: "bold",
    width: 105
  }
}

const useStyles = makeStyles(theme => ({
  formControl: {
    marginTop: theme.spacing(1),
    minWidth: 120
  },
  selectEmpty: {
    marginTop: theme.spacing(2)
  }
}))

const ProfileContent = ({ userInfo, _submitForm }) => {
  const classes = useStyles()
  const [customerType, setcustomerType] = useState("")
  const [product, setproduct] = useState("")
  const [snackOpen, setSnackOpen] = useState(false)
  const [form, setform] = useState({
    first_name: "",
    last_name: "",
    gender: "",
    notes: "",
    address: "",
    mobile: "",
    email: ""
  })
  const {
    channel,
    skill,
    userId,
    first_name,
    timezone,
    last_name,
    gender,
    profile_pic,
    notes,
    mobile,
    address
  } = userInfo

  const _handleClose = () => setSnackOpen(false)

  useEffect(() => {
    setform({
      first_name,
      last_name,
      gender,
      notes,
      address,
      mobile
    })
  }, [userInfo])

  if (userId === "")
    return (
      <div style={{ padding: 15, color: "#757575" }}>
        Waiting for customer...
      </div>
    )
  return (
    <div style={{ color: "#757575" }}>
      <div style={{ padding: 15, background: "#f6f6f6" }}>
        <div
          style={{
            display: "flex",
            width: "100%",
            marginBottom: 5
          }}
        >
          <div style={{ width: "50%" }}>
            <b>ID:</b> {userId}
          </div>
          <div style={{ width: "50%" }}>
            <b>Skill:</b> {skill}
          </div>
        </div>
        <div
          style={{
            display: "flex",
            width: "100%"
          }}
        >
          <div style={{ width: "50%" }}>
            <b>Firstname:</b> {first_name}
          </div>
          <div style={{ width: "50%" }}>
            <b>Channel:</b> {channel}
          </div>
        </div>
      </div>

      <div
        style={{
          padding: 15,
          overflowY: "scroll",
          height: "calc(100vh - 271px)"
        }}
      >
        <div style={styles.inputContainer}>
          <div style={styles.inputTitle}>First name:</div>
          <TextField
            fullWidth
            value={form.first_name}
            onChange={e => setform({ ...form, first_name: e.target.value })}
            margin="dense"
            variant="outlined"
            size="small"
          />
        </div>
        <div style={styles.inputContainer}>
          <div style={styles.inputTitle}>Last name:</div>

          <div style={styles.inputSubContainer}>
            <TextField
              fullWidth
              value={form.last_name}
              onChange={e => setform({ ...form, last_name: e.target.value })}
              margin="dense"
              variant="outlined"
              size="small"
            />
          </div>
        </div>
        <div style={styles.inputContainer}>
          <div style={styles.inputTitle}>Gender:</div>
          <div style={styles.inputSubContainer}>
            <TextField
              fullWidth
              value={form.gender}
              onChange={e => setform({ ...form, gender: e.target.value })}
              margin="dense"
              variant="outlined"
              size="small"
            />
          </div>
        </div>
        <div style={styles.inputContainer}>
          <div style={styles.inputTitle}>Address:</div>
          <div style={styles.inputSubContainer}>
            <TextField
              fullWidth
              value={form.address}
              onChange={e => setform({ ...form, address: e.target.value })}
              margin="dense"
              variant="outlined"
              size="small"
              rows="2"
              multiline
            />
          </div>
        </div>
        <div style={styles.inputContainer}>
          <div style={styles.inputTitle}>Mobile:</div>
          <div style={styles.inputSubContainer}>
            <TextField
              type="tel"
              fullWidth
              margin="dense"
              variant="outlined"
              size="small"
              value={form.mobile}
              onChange={e => setform({ ...form, mobile: e.target.value })}
            />
          </div>
        </div>
        <div style={styles.inputContainer}>
          <div style={styles.inputTitle}>Email:</div>
          <div style={styles.inputSubContainer}>
            <TextField
              type="email"
              fullWidth
              margin="dense"
              variant="outlined"
              size="small"
              value={form.email}
              onChange={e => setform({ ...form, email: e.target.value })}
            />
          </div>
        </div>
        <div style={styles.inputContainer}>
          <div style={styles.inputTitle}>Type:</div>
          <div style={styles.inputSubContainer}>
            <FormControl className={classes.formControl} variant="outlined">
              <Select
                labelId="demo-simple-select-outlined-label"
                id="demo-simple-select-outlined"
                value={customerType}
                onChange={e => setcustomerType(e.target.value)}
              >
                <MenuItem value={"Interested"}>Interested</MenuItem>
                <MenuItem value={"Complain"}>Complain</MenuItem>
                <MenuItem value={"Another type"}>Another type</MenuItem>
              </Select>
            </FormControl>
          </div>
        </div>

        {customerType === "Interested" && (
          <div style={styles.inputContainer}>
            <div style={styles.inputTitle}>Products:</div>
            <div style={styles.inputSubContainer}>
              <FormControl className={classes.formControl} variant="outlined">
                <Select
                  labelId="demo-simple-select-outlined-label"
                  id="demo-simple-select-outlined"
                  value={product}
                  onChange={e => setproduct(e.target.value)}
                >
                  <MenuItem value={"Product 1"}>Product 1</MenuItem>
                  <MenuItem value={"Product 2"}>Product 2</MenuItem>
                  <MenuItem value={"Product 3"}>Product 3</MenuItem>
                  <MenuItem value={"Product 4"}>Product 4</MenuItem>
                </Select>
              </FormControl>
            </div>
          </div>
        )}

        <div style={styles.inputTitle}>Notes:</div>
        <TextField
          rows="2"
          multiline
          fullWidth
          margin="dense"
          variant="outlined"
          size="small"
          value={form.notes}
          onChange={e => setform({ ...form, notes: e.target.value })}
        />
        <div style={{ width: "100%", textAlign: "center", margin: "15px 0px" }}>
          <Button
            onClick={() => {
              _submitForm(form)
              setSnackOpen(true)
            }}
            variant="contained"
            color="primary"
          >
            Submit
          </Button>
        </div>
        <SnackBr
          handleClose={_handleClose}
          isOpen={snackOpen}
          msg="form saved!"
        />
      </div>
    </div>
  )
}

export default ProfileContent
