import React from "react"
import Avatar from "@material-ui/core/Avatar"
import dateFormat from "dateformat"

const MsgAgent = ({ message, time }) => {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "flex-end",
        width: "100%",
        margin: "10px 0px",
      }}
    >
      <div
        style={{
          marginRight: 5,
          borderRadius: 5,
          background: "#78afd6",
          padding: 5,
          color: "black",
          maxWidth: "73%",
        }}
      >
        <div style={{ fontWeight: "bold" }}>Me</div>
        {message}
      </div>
      <div>
        <Avatar>A</Avatar>
        <div>{time}</div>
      </div>
    </div>
  )
}

const MsgSupervisor = ({ message, time }) => {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "flex-start",
        width: "100%",
        margin: "10px 0px",
      }}
    >
      <div>
        <Avatar>S</Avatar>
        <div>{time}</div>
      </div>

      <div
        style={{
          marginLeft: 5,
          borderRadius: 5,
          background: "#faff69",
          padding: 5,
          color: "black",
          maxWidth: "73%",
        }}
      >
        <div style={{ fontWeight: "bold" }}>Supervisor</div>
        {message}
      </div>
    </div>
  )
}

const Content = ({ state }) => {
  return (
    <div
      style={{
        overflowY: "scroll",
        height: "calc(100vh - 335px)",
        paddingRight: "15px",
      }}
    >
      {state.chatFlowSupervisor &&
        state.chatFlowSupervisor.map(({ author, msg, type, date }) => {
          if (msg.length !== 0) {
            if (author !== "me")
              return (
                <MsgSupervisor message={msg} time={dateFormat(date, "HH:MM")} />
              )
            return (
              <MsgAgent
                message={msg}
                author={author}
                time={dateFormat(date, "HH:MM")}
              />
            )
          }
        })}
    </div>
  )
}

export default Content
