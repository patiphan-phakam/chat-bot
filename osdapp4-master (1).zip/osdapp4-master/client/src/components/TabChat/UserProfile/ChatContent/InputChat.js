import React, { useState } from "react"
import Button from "@material-ui/core/Button"
import TextField from "@material-ui/core/TextField"
import SendIcon from "@material-ui/icons/Send"

const InputChat = ({ _msgToSupervisor }) => {
  const [value, setvalue] = useState("")
  return (
    <form
      onSubmit={e => {
        e.preventDefault()
        _msgToSupervisor(value)
        setvalue("")
      }}
      style={{ height: 51, display: "flex", marginTop: 10 }}
    >
      <TextField
        id="outlined-textarea"
        label="To supervisor"
        placeholder="To supervisor"
        variant="outlined"
        fullWidth
        value={value}
        onChange={e => setvalue(e.target.value)}
      />
      <Button
        type="submit"
        variant="contained"
        color="primary"
        style={{ marginLeft: 10 }}
      >
        <SendIcon />
      </Button>
    </form>
  )
}

export default InputChat
