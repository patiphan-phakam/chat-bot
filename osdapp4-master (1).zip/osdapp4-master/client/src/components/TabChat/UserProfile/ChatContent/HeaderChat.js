import React, { useState } from "react"
import Typography from "@material-ui/core/Typography"
import Button from "@material-ui/core/Button"

const HeaderChat = ({ _newAlert }) => {
  const [openMenu, setopenMenu] = useState(false)
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center"
      }}
    >
      <Typography variant="h6" gutterBottom>
        Chat with supervisor
      </Typography>
      <div style={{ position: "relative" }}>
        <div style={{ margin: "0px 15px 5px 0px" }}>
          <Button
            onClick={() => _newAlert("yo")}
            variant="contained"
            color="secondary"
          >
            Help !
          </Button>
        </div>
      </div>
    </div>
  )
}

export default HeaderChat
