import React from "react"
import InputChat from "./InputChat"
import HeaderChat from "./HeaderChat"
import Content from "./Content"

const ChatContent = ({ _msgToSupervisor, state, _newAlert }) => {
  return (
    <div
      style={{
        color: "#757575",
        padding: 15,
        display: "flex",
        flexDirection: "column"
      }}
    >
      <HeaderChat _newAlert={_newAlert} />
      <Content state={state} />
      <InputChat _msgToSupervisor={_msgToSupervisor} />
    </div>
  )
}

export default ChatContent
