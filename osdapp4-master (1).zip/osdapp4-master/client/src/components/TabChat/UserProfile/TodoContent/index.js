import React, { useState } from "react"
import { makeStyles } from "@material-ui/core/styles"
import List from "@material-ui/core/List"
import ListItem from "@material-ui/core/ListItem"
import ListItemSecondaryAction from "@material-ui/core/ListItemSecondaryAction"
import ListItemText from "@material-ui/core/ListItemText"
import Checkbox from "@material-ui/core/Checkbox"
import Divider from "@material-ui/core/Divider"
import DeleteIcon from "@material-ui/icons/Delete"
import IconButton from "@material-ui/core/IconButton"

import TodoInput from "./TodoInput"

const useStyles = makeStyles(theme => ({
  root: {
    width: "100%",
    maxWidth: 360,
    backgroundColor: theme.palette.background.paper
  }
}))

const styles = {
  checked: {
    textDecoration: "line-through",
    fontWeight: "bold"
  },
  unChecked: {}
}

export default function TodoContent() {
  const classes = useStyles()
  const [checked, setChecked] = useState([1])
  const [customTodo, setcustomTodo] = useState([]) //[{_id:'', title: '', checked: false}]

  const _customTodo = e =>
    setcustomTodo([
      ...customTodo,
      { title: e, checked: false, _id: customTodo.length }
    ])

  const _checkCustomTodo = _id => {
    const without = customTodo.filter((x, i) => _id !== x._id)
    const selected = customTodo.filter((x, i) => _id === x._id)[0]

    return setcustomTodo(
      [
        ...without,
        { title: selected.title, checked: !selected.checked, _id: selected._id }
      ].sort(function(a, b) {
        return a._id - b._id
      })
    )
  }

  const _deleteCustomTodo = _id => {
    const without = customTodo.filter((x, i) => _id !== x._id)
    return setcustomTodo(
      without.sort(function(a, b) {
        return a._id - b._id
      })
    )
  }

  const handleToggle = value => () => {
    const currentIndex = checked.indexOf(value)
    const newChecked = [...checked]

    if (currentIndex === -1) {
      newChecked.push(value)
    } else {
      newChecked.splice(currentIndex, 1)
    }

    setChecked(newChecked)
  }

  return (
    <div>
      <List dense className={classes.root}>
        {[0, 1, 2, 3].map(value => {
          const labelId = `checkbox-list-secondary-label-${value}`
          return (
            <ListItem key={value}>
              <ListItemText
                id={labelId}
                primary={
                  <div
                    style={
                      checked.indexOf(value) !== -1
                        ? styles.checked
                        : styles.unChecked
                    }
                  >{`Line item ${value + 1}`}</div>
                }
              />
              <ListItemSecondaryAction>
                <Checkbox
                  edge="end"
                  onChange={handleToggle(value)}
                  checked={checked.indexOf(value) !== -1}
                  inputProps={{ "aria-labelledby": labelId }}
                />
              </ListItemSecondaryAction>
            </ListItem>
          )
        })}
      </List>
      <Divider />
      <TodoInput _customTodo={_customTodo} />
      <List dense className={classes.root}>
        {customTodo.map(x => {
          const labelId = `checkbox-list-secondary-label-${x.title}`
          return (
            <ListItem key={x._id}>
              <ListItemText
                id={x.title}
                primary={
                  <div style={x.checked ? styles.checked : styles.unChecked}>
                    {x.title}
                  </div>
                }
              />
              <ListItemSecondaryAction>
                <Checkbox
                  edge="end"
                  onChange={() => _checkCustomTodo(x._id)}
                  checked={x.checked}
                  inputProps={{ "aria-labelledby": labelId }}
                />
                <IconButton
                  aria-label="delete"
                  className={classes.margin}
                  onClick={() => _deleteCustomTodo(x._id)} //TODO
                >
                  <DeleteIcon fontSize="small" />
                </IconButton>
              </ListItemSecondaryAction>
            </ListItem>
          )
        })}
      </List>
    </div>
  )
}
