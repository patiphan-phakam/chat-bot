import React, { useState, useEffect } from "react"
import Button from "@material-ui/core/Button"
import MenuProfile from "./MenuProfile"
import Typography from "@material-ui/core/Typography"
import ProfileContent from "./ProfileContent"
import TodoContent from "./TodoContent"
import ToolsContent from "./ToolsContent"
import ChatContent from "./ChatContent"

const UserProfile = ({
  _msgToSupervisor,
  _inputMsg,
  inputMsg,
  userInfo,
  _closeConversation,
  _carousel,
  _txt,
  state,
  _submitForm,
  _newAlert,
}) => {
  const [selectedMenu, setSelectedMenu] = useState(0)
  const [counterNewMsg, setcounterNewMsg] = useState(0)
  const _selectMenu = (numb) => setSelectedMenu(numb)

  useEffect(() => {
    const { author } = state.chatFlowSupervisor[
      state.chatFlowSupervisor.length - 1
    ]

    selectedMenu !== 3 &&
      state.chatFlowSupervisor &&
      author &&
      author !== "me" &&
      setcounterNewMsg(counterNewMsg + 1)
  }, [state.chatFlowSupervisor])

  useEffect(() => {
    selectedMenu === 3 && setcounterNewMsg(0)
  }, [selectedMenu])

  return (
    <div
      style={{
        backgroundColor: "white",
        display: "flex",
        flexDirection: "column",
        maxWidth: 400,
        flexGrow: 1,
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          height: 60,
        }}
      >
        <Typography variant="h5">Agent tools</Typography>
      </div>
      <MenuProfile
        _selectMenu={_selectMenu}
        selectedMenu={selectedMenu}
        state={state}
        counterNewMsg={counterNewMsg}
      />

      {selectedMenu === 0 ? (
        <ProfileContent userInfo={userInfo} _submitForm={_submitForm} />
      ) : selectedMenu === 1 ? (
        <TodoContent />
      ) : selectedMenu === 2 ? (
        <ToolsContent
          _inputMsg={_inputMsg}
          inputMsg={inputMsg}
          _closeConversation={_closeConversation}
          _carousel={_carousel}
          _txt={_txt}
          state={state}
        />
      ) : (
        <ChatContent
          _msgToSupervisor={_msgToSupervisor}
          state={state}
          _newAlert={_newAlert}
        />
      )}
    </div>
  )
}

export default UserProfile
