import React from "react"
import Paper from "@material-ui/core/Paper"
import { makeStyles } from "@material-ui/core/styles"
import Tabs from "@material-ui/core/Tabs"
import Tab from "@material-ui/core/Tab"
import PlaylistAddCheckRoundedIcon from "@material-ui/icons/PlaylistAddCheckRounded"
import BuildRoundedIcon from "@material-ui/icons/BuildRounded"
import PersonPinIcon from "@material-ui/icons/PersonPin"
import FeedbackIcon from "@material-ui/icons/Feedback"
import Badge from "@material-ui/core/Badge"

const useStyles = makeStyles({
  root: {
    flexGrow: 1,
    maxWidth: 500,
  },
  tabsContainer: {
    minWidth: 100,
  },
})

export default function IconLabelTabs({
  _selectMenu,
  selectedMenu,
  counterNewMsg,
}) {
  const classes = useStyles()
  const [value, setValue] = React.useState(0)

  const handleChange = (event, newValue) => {
    setValue(newValue)
  }

  return (
    <div style={{ backgroundColor: "white" }}>
      <Tabs
        value={selectedMenu}
        onChange={(e, f) => _selectMenu(f)}
        variant="fullWidth"
        indicatorColor="secondary"
        textColor="secondary"
        aria-label="icon label tabs example"
      >
        <Tab
          classes={{ root: classes.tabsContainer }}
          icon={<PersonPinIcon />}
          label="Profile"
        />
        <Tab
          classes={{ root: classes.tabsContainer }}
          icon={<PlaylistAddCheckRoundedIcon />}
          label="Todo"
        />
        <Tab
          classes={{ root: classes.tabsContainer }}
          icon={<BuildRoundedIcon />}
          label="tools"
        />
        <Tab
          classes={{ root: classes.tabsContainer }}
          icon={
            <Badge badgeContent={counterNewMsg} color="secondary">
              <FeedbackIcon />
            </Badge>
          }
          label="chat"
        />
      </Tabs>
    </div>
  )
}
