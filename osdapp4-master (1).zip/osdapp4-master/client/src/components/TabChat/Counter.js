import React from "react"

const Counter = ({ countSec, countMin, counterMsg }) => {
  if (counterMsg) return <div style={{ color: "red" }}>{counterMsg}</div>
  return (
    <div>
      {countMin < 10 ? `0${countMin}` : countMin}:
      {countSec < 10 ? `0${countSec}` : countSec}
      <span>(x100)</span>
    </div>
  )
}

export default Counter
