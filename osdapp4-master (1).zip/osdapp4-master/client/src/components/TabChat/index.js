import React, { useState, useEffect } from "react"

import ChatRoom from "./ChatRoom"
import UserProfile from "./UserProfile"
import History from "./History"

const styles = {
  container: {
    display: "flex",
    width: "100%",
    marginTop: 64,
    paddingLeft: 60,
    height: "100%",
    flex: 1,
  },
}

const TabChat = ({
  _selectHistoryProfile,
  _msgToSupervisor,
  agentReducer,
  state,
  inputText,
  _carousel,
  _txt,
  _closeConversation,
  _inputTextSubmit,
  _inputText,
  deciSec,
  countSec,
  countMin,
  counterMsg,
  newMsgLoading,
  _break,
  _resume,
  _submitForm,
  _newAlert,
}) => {
  const [inputMsg, setinputMsg] = useState("")
  const [inputSearch, setinputSearch] = useState("")
  const [sortHistory, setsortHistory] = useState("asc")

  const _inputMsg = (e) => setinputMsg(e)
  const _inputSearch = (e) => setinputSearch(e)
  const _sortHistory = () =>
    setsortHistory(sortHistory === "asc" ? "desc" : "asc")

  return (
    <div style={{ display: "flex" }}>
      <div style={styles.container}>
        {state.agentStatus.status !== "busy" && (
          <History
            _selectHistoryProfile={_selectHistoryProfile}
            _inputSearch={_inputSearch}
            inputSearch={inputSearch}
            _sortHistory={_sortHistory}
            agentReducer={agentReducer}
          />
        )}

        <div style={{ flexGrow: 1 }}>
          <div style={{ display: "flex", minHeight: "calc(100vh - 124px)" }}>
            <ChatRoom
              deciSec={deciSec}
              countSec={countSec}
              countMin={countMin}
              counterMsg={counterMsg}
              inputText={inputText}
              state={state}
              _inputTextSubmit={_inputTextSubmit}
              _inputText={_inputText}
              newMsgLoading={newMsgLoading}
              _break={_break}
              _resume={_resume}
            />
            <UserProfile
              _msgToSupervisor={_msgToSupervisor}
              _inputMsg={_inputMsg}
              inputText={inputText}
              userInfo={state.userInfo}
              _closeConversation={_closeConversation}
              _carousel={_carousel}
              _txt={_txt}
              state={state}
              _submitForm={_submitForm}
              _newAlert={_newAlert}
            />
          </div>
        </div>
      </div>
    </div>
  )
}

export default TabChat
