colors:

darkGray: #757575

darkergray: #424242

"customers" : [
{
"id" : "2807938259293308",
"channel" : "facebook",
"chat" : [
{
"author" : "user",
"msg" : "I have error problem!",
"type" : "text",
"date" : ISODate("2020-03-20T04:07:24.000Z")
},
{
"author" : "me",
"msg" : "Hello, welcome!",
"type" : "text",
"date" : ISODate("2020-03-20T07:27:25.202Z")
},
{
"author" : "me",
"msg" : "Sure.",
"type" : "text",
"date" : ISODate("2020-03-20T07:27:25.222Z")
},
{
"author" : "me",
"msg" : "Please wait a moment, I am asking IT team.",
"type" : "text",
"date" : ISODate("2020-03-20T07:27:25.232Z")
},
{
"author" : "me",
"msg" : "Server is updating.",
"type" : "text",
"date" : ISODate("2020-03-20T07:27:25.232Z")
},
{
"author" : "me",
"msg" : "Any other question?",
"type" : "text",
"date" : ISODate("2020-03-20T07:27:25.252Z")
}
],
"firstname" : "Francois",
"lastname" : "Pierre",
"gender" : "male",
"date" : ISODate("2020-03-20T07:27:24.202Z"),
"address" : "hi",
"email" : null,
"mobile" : "4324234",
"notes" : "hdghgfh"
},
{
"id" : "1807938259293308",
"channel" : "facebook",
"chat" : [
{
"author" : "user",
"msg" : "Hello, I need help",
"type" : "text",
"date" : ISODate("2020-03-20T04:07:24.000Z")
},
{
"author" : "me",
"msg" : "Sure, how can I help?",
"type" : "text",
"date" : ISODate("2020-03-20T07:27:25.202Z")
}
],
"firstname" : "George",
"lastname" : "Psartek",
"gender" : "male",
"date" : ISODate("2020-03-20T04:07:24.514Z"),
"address" : "hi",
"email" : null,
"mobile" : "4324234",
"notes" : "hdghgfh"
},
{
"id" : "3807938259293308",
"channel" : "facebook",
"chat" : [
{
"author" : "user",
"msg" : "Hello, I need help",
"type" : "text",
"date" : ISODate("2020-03-20T04:07:24.000Z")
},
{
"author" : "me",
"msg" : "Sure, how can I help?",
"type" : "text",
"date" : ISODate("2020-03-20T07:27:25.202Z")
},
{
"author" : "user",
"msg" : "I did not get invoice",
"type" : "text",
"date" : ISODate("2020-03-20T07:27:25.202Z")
},
{
"author" : "me",
"msg" : "Ok, could you tell me the order id please? thank you.",
"type" : "text",
"date" : ISODate("2020-03-20T04:09:25.514Z")
}
],
"firstname" : "Philipe",
"lastname" : "Claude",
"gender" : "male",
"date" : ISODate("2020-03-20T04:07:24.514Z"),
"address" : "hi",
"email" : null,
"mobile" : "4324234",
"notes" : "hdghgfh"
},
{
"id" : "4807938259293308",
"channel" : "facebook",
"chat" : [
{
"author" : "user",
"msg" : "Hello, I need help",
"type" : "text",
"date" : ISODate("2020-03-20T04:07:24.000Z")
},
{
"author" : "me",
"msg" : "Sure, how can I help?",
"type" : "text",
"date" : ISODate("2020-03-20T07:27:25.202Z")
},
{
"author" : "user",
"msg" : "I did not get invoice",
"type" : "text",
"date" : ISODate("2020-03-20T07:27:25.202Z")
},
{
"author" : "me",
"msg" : "Ok, could you tell me the order id please? thank you.",
"type" : "text",
"date" : ISODate("2020-03-20T04:10:25.514Z")
}
],
"firstname" : "Jean",
"lastname" : "Edouard",
"gender" : "male",
"date" : ISODate("2020-03-20T04:07:24.514Z"),
"address" : "hi",
"email" : null,
"mobile" : "4324234",
"notes" : "hdghgfh"
}
]

        "channel" : "facebook",
    "chat" : [],
    "firstname" : "Nielseee",
    "lastname" : "Dominguez",
    "gender" : "male",
    "createdAt" : ISODate("2020-03-20T04:07:24.514Z"),
    "updatedAt" : ISODate("2020-04-15T07:55:14.756Z"),
    "__v" : 0,
    "address" : "hi",
    "email" : null,
    "mobile" : "4324234",
    "notes" : "hdghgfh"
